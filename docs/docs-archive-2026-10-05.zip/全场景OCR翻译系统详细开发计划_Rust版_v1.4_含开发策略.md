# 全场景OCR翻译系统 — 详细开发计划（Rust架构版 v1.5）

> **v1.5 更新**：原文档聚焦"做什么、怎么设计、用哪些开源方案"，缺少工程落地与产品交付视角。本次新增第十四~十八章：工程落地基线（范围/排期/RACI/CI）、质量工程与测试策略、安装分发与运维运营、用户使用视角与第一性原理、Rust 壳完整 GUI 设计。

## 一、项目概述

### 1.1 项目背景

本项目旨在构建一个**全场景、全链路**的翻译系统，整合四种开源方案的核心能力：

- **WinLens**：系统级屏幕OCR翻译（任意界面）
- **沉浸式翻译**：浏览器内全页双语翻译
- **Microsoft Edge Translator API**：浏览器内置本地离线翻译
- **MouseTooltipTranslator**：浏览器悬停翻译+图片OCR

通过整合，用户只需**一个浏览器插件 + 一个轻量本地壳程序**，即可实现浏览器内/外全场景覆盖的翻译能力。

### 1.2 核心目标

| 目标 | 指标 |
|------|------|
| 全场景覆盖 | 浏览器内 + 浏览器外 + 视频 + 语音 |
| 空间最小 | 插件 < 1MB + 本地壳 ~100-200KB，总计 < 2MB |
| 传输最快 | Native Messaging IPC直连，延迟 < 1ms |
| 多引擎调度 | 本地离线 + 云端高质量，智能路由 |
| 隐私安全 | OCR本地运行，翻译可完全离线 |
| 毫秒级响应 | Rust零GC停顿 + PP-OCRv6本地推理，截图→译文 < 100ms |

### 1.3 技术架构总览

```
+------------------------------------------------------------------+
|                    用户交互层（统一入口）                           |
|  浏览器内：悬停翻译 / 划词翻译 / 一键全页翻译                       |
|  浏览器外：全局快捷键截图翻译 / 任意窗口覆盖翻译                    |
|  视频：实时双语字幕                                                |
|  语音：TTS朗读 / 语音输入翻译                                      |
+----------------------------------+-------------------------------+
                                   |
+----------------------------------+-------------------------------+
|                    内容采集层（多源输入）                           |
|  1) DOM文本捕获 ---- 沉浸式翻译的DOM遍历 + MutationObserver        |
|  2) 鼠标悬停捕获 -- MouseTooltipTranslator的getSelection()         |
|  3) 屏幕截图OCR --- Rust壳 + PP-OCRv6 ONNX Runtime                |
|  4) 图像OCR ------- Tesseract.js（浏览器端）                       |
|  5) 视频字幕提取 -- YouTube/Netflix Player API                     |
|  6) PDF解析 ------- PDF.js 文本层 + 扫描件OCR                      |
|  7) 语音输入 ------ Web Speech API                                 |
+----------------------------------+-------------------------------+
                                   |
+----------------------------------+-------------------------------+
|                    翻译处理层（多引擎调度）                         |
|  本地离线：Edge Translator API（设备端ONNX推理，零延迟）            |
|  本地大模型：Ollama / LM Studio / text-generation-webui            |
|    （Qwen / Llama / ChatGLM 等，HTTP REST API 调用）               |
|  云端高质量：SiliconFlow / OpenAI GPT / Claude / Gemini / DeepL    |
|  云端通用：Google Translate / Bing Translate                       |
|  云端免费：MyMemory（免Key，国内直连）                              |
|  智能路由：根据文本类型/长度/网络状况/成本自动选最优引擎             |
|  术语库：专业术语库 + 用户自定义术语                                 |
+----------------------------------+-------------------------------+
                                   |
+----------------------------------+-------------------------------+
|                    AI 对话界面层（新增 v1.3）                      |
|  多轮对话 / 上下文管理 / 引擎切换 / 文件上传 / 对话历史管理         |
|  与学习模块集成（对话生词自动入本） / 对话导出（MD/PDF/文本）        |
+----------------------------------+-------------------------------+
                                   |
+----------------------------------+-------------------------------+
|                    结果展示层（多模态输出）                         |
|  浏览器内：双语对照行内嵌入 / 悬停Tooltip弹窗 / 输入框实时翻译       |
|  浏览器外（Native Messaging）：Rust浮窗原位覆盖绘制 / 浮动翻译窗口   |
|  特殊场景：视频双语字幕叠加 / PDF保留排版翻译 / TTS语音朗读          |
+------------------------------------------------------------------+
```

---

## 二、模块划分

### 2.1 模块总览

| 模块编号 | 模块名称 | 所属层 | 职责 |
|---------|---------|--------|------|
| M1 | 用户交互管理器 | 用户交互层 | 统一快捷键、弹窗、设置界面 |
| M2 | DOM内容采集器 | 内容采集层 | 网页文本捕获、MutationObserver监听 |
| M3 | 悬停翻译器 | 内容采集层 | 鼠标悬停文本捕获与翻译 |
| M4 | 屏幕截图OCR引擎 | 内容采集层 | 浏览器内Canvas截图+Tesseract.js |
| M5 | Native Messaging通信桥 | 传输层 | 插件与本地壳的IPC管道通信 |
| M6 | 本地壳程序（Rust） | 系统层 | 全局截图、PP-OCRv6 OCR、Rust浮窗绘制 |
| M7 | 翻译引擎路由器 | 翻译处理层 | 多引擎调度、智能路由、缓存 |
| M8 | 结果渲染引擎 | 结果展示层 | DOM注入、CSS覆盖、Tooltip渲染 |
| M9 | 视频字幕模块 | 内容采集+展示 | YouTube/Netflix字幕提取与叠加 |
| M10 | PDF翻译模块 | 内容采集+展示 | PDF.js解析+排版保留翻译 |
| M11 | 术语库管理器 | 翻译处理层 | 术语加载、匹配、用户自定义 |
| M12 | 设置与配置中心 | 用户交互层 | 用户偏好、引擎密钥、快捷键配置 |
| M13 | 历史记录服务（学习模块） | 学习层 | 翻译记录、掌握度追踪、复习调度 |
| M14 | 生词本服务（学习模块） | 学习层 | 生词采集、间隔重复、掌握度管理 |
| M15 | 复习引擎（学习模块） | 学习层 | SM-2算法、复习队列、掌握度衰减 |
| M16 | 导出服务（学习模块） | 学习层 | 多格式导出、跨设备迁移 |
| M17 | 本地大模型引擎接口 | 翻译处理层 | 本地部署大模型（Ollama/LM Studio）作为翻译引擎，支持Qwen/Llama/ChatGLM等 |
| M18 | AI对话界面 | 用户交互层 | 类ChatGPT对话式UI，多轮对话、引擎切换、文件上传、对话历史管理、与学习模块集成 |

### 2.2 各模块详细设计

#### M1 — 用户交互管理器

- **职责**：统一管理所有用户交互入口
- **功能**：
  - 全局快捷键注册与分发（见第四章快捷键系统详述）
  - Popup页面（插件图标点击弹出的设置面板）
  - 选项页面（长期设置存储）
  - 通知推送（翻译完成提示、错误提示）
- **技术**：Chrome Extension API `chrome.commands`、`chrome.storage`

#### M2 — DOM内容采集器

- **职责**：从网页DOM中提取可翻译文本
- **功能**：
  - DOM树遍历，智能识别正文区域（过滤导航、广告、代码块）
  - MutationObserver监听SPA动态内容变化
  - 文本清洗（去HTML标签、合并碎片TextNode、段落识别）
  - 长文本分块（避免API超时）
- **技术**：Content Script、DOM API、DOMParser

#### M3 — 悬停翻译器

- **职责**：鼠标悬停时实时翻译选中文本
- **功能**：
  - 监听 `mousemove` / `mouseup` 事件
  - 使用 `window.getSelection()` 捕获文本
  - 防抖处理（避免频繁请求）
  - 显示Tooltip浮动层
- **技术**：Content Script、DOM事件监听、CSS定位

#### M4 — 屏幕截图OCR引擎

- **职责**：浏览器内图片/漫画OCR识别
- **功能**：
  - Canvas API捕获页面指定区域
  - 调用Tesseract.js进行OCR识别
  - 语言包懒加载（首次使用时从CDN下载）
  - 识别结果缓存（相同图片不重复OCR）
- **技术**：Tesseract.js、Web Worker、Canvas API

#### M5 — Native Messaging通信桥

- **职责**：浏览器插件与本地壳程序之间的IPC通信
- **功能**：
  - 插件端：`chrome.runtime.connectNative()` 建立持久连接
  - 插件端：`port.postMessage()` 发送翻译请求
  - 插件端：`port.onMessage` 接收翻译结果
  - 本地壳端（Rust）：stdin写入/读取（4字节长度前缀 + UTF-8 JSON）
- **消息协议**：
  - 请求格式：`{4字节小端序长度}[UTF-8 JSON]`
  - 响应格式：`{4字节小端序长度}[UTF-8 JSON]`
- **JSON schema（请求）**：
  ```json
  {
    "type": "translate",
    "text": "原文内容",
    "source_lang": "en",
    "target_lang": "zh",
    "task": "ocr_translate",
    "timestamp": 1726963200000
  }
  ```
- **JSON schema（响应）**：
  ```json
  {
    "type": "translate_result",
    "translation": "翻译结果",
    "original_text": "原文内容",
    "source_lang": "en",
    "target_lang": "zh",
    "engine": "siliconflow",
    "ok": true,
    "error": null
  }
  ```

#### M6 — 本地壳程序（Rust版）

- **职责**：浏览器外的屏幕截图、OCR、译文绘制（Rust实现，毫秒级响应）
- **功能**：
  - **全局快捷键监听**：Win32 `RegisterHotKey`（Rust `winapi` crate 绑定）
  - **区域画框截图**：DXGI Desktop Duplication 优先 + GDI BitBlt 兜底
  - **OCR引擎调度**：PP-OCRv6 ONNX Runtime（本地离线，零key）/ SiliconFlow云端（兜底）
  - **三档模型切换**：Tiny（6MB，~100ms）/ Small（30MB，~500ms）/ Medium（133MB，~1.4s）
  - **Native Messaging通信**：通过 stdin/stdout 与浏览器插件通信
  - **Rust浮窗绘制**：tkinter替代方案 — 使用 `tao` + `winit` 创建置顶透明窗口进行GDI+绘制
  - **窗口句柄枚举**：GetForegroundWindow + EnumWindows 识别前景窗口
  - **单实例保护**：命名互斥量防止多实例冲突
- **技术栈**：
  - 语言：Rust 2021 Edition
  - 构建：Cargo + cargo-clippy + cargo-test
  - OCR推理：`onnxruntime` crate（Microsoft官方Rust绑定）
  - 截图：`d3d12` + `dxgi`（DXGI Desktop Duplication）
  - 窗口/热键：`winapi` / `windows` crate
  - JSON序列化：`serde` + `serde_json`
  - 浮窗绘制：`winit` + `wgpu`（GPU加速）或 `gdi32`（CPU兜底）
  - 配置管理：`serde` 序列化 JSON 配置文件
- **体积目标**：< 200KB（静态链接ONNX Runtime动态库约5-10MB可选项）
- **启动时间**：< 50ms（对比Python版1-2秒）
- **内存占用**：< 30MB（对比Python版~200MB）

**PP-OCRv6 三档模型选型策略**：

| 档位 | 模型体积 | 推理速度 | 适用场景 | 默认推荐 |
|------|---------|---------|---------|---------|
| Tiny | ~6MB | ~100ms/图 | 划词翻译、快速预览、屏幕截图 | 默认（平衡速度/精度） |
| Small | ~30MB | ~500ms/图 | 日常截图翻译、文档OCR | 用户可选 |
| Medium | ~133MB | ~1.4s/图 | 病历/医学文档、复杂版面、手写体 | 高精度场景 |

**OCR引擎降级策略**：

```
用户选择OCR引擎
    |
    v
+-----------+     不可用      +---------------+
|  本地PP-OCRv6  | ---------> | SiliconFlow   |
|  (onnxruntime)|  自动降级   |  云端OCR      |
+-----------+                 +---------------+
    |                                |
    v                                v
 Tiny/Small/Medium              PaddleOCR-VL-1.5
 100ms/500ms/1.4s               103-121s
 置信度0.98                     有前导幻觉
```

#### M7 — 翻译引擎路由器

- **职责**：统一管理所有翻译引擎（含本地大模型），智能选择最优引擎
- **功能**：
  - 引擎注册与发现（插件启动时扫描可用引擎）
  - 可用性检测（网络状态、API密钥有效性、本地服务可达性）
  - **全引擎列表**：
    - 本地离线：Edge Translator API（设备端ONNX推理）
    - **本地大模型：Ollama / LM Studio（Qwen/Llama/ChatGLM等）**
    - 云端高质量：SiliconFlow / OpenAI GPT-4o / Claude / Gemini / DeepL
    - 云端通用：Google Translate / Bing Translate
    - 云端免费：MyMemory（免Key，国内直连）
  - **智能路由策略表**：

| 场景 | 首选引擎 | 备选引擎 | 路由理由 |
|------|---------|---------|---------|
| 日常划词翻译（短文本） | Edge内置 / MyMemory | SiliconFlow | 免费快速，无需key |
| 专业文档翻译 | OpenAI GPT-4o / SiliconFlow | Claude | 高质量专业翻译 |
| 医学/法律等专业领域 | SiliconFlow / DeepL | OpenAI GPT-4o | 专业术语准确 |
| 隐私敏感内容 | 本地Ollama / Edge内置 | — | 数据不出本机 |
| 长文本（>4000字符） | Claude / OpenAI GPT-4o | SiliconFlow | 长上下文处理能力强 |
| 中日韩翻译 | Google / 百度 / 有道 | SiliconFlow | 东亚语言优化 |
| 离线环境 | Edge内置 / 本地Ollama | 无备选，提示联网 | 无云端可用 |
| 用户指定引擎 | 用户选择 | 降级到默认 | 尊重用户偏好 |

  - 请求缓存（相同文本相同语言对不重复请求）
  - 失败自动降级（主引擎失败 → 备选引擎 → 提示用户）
  - 并发请求与结果优先返回（多引擎并行请求，最快响应优先）
  - **成本优化**：短文本优先用免费引擎，长文本/专业文本自动切换高质量引擎
- **技术**：Service Worker、Fetch API、IndexedDB（缓存）、reqwest（Rust壳端HTTP客户端）

#### M8 — 结果渲染引擎

- **职责**：将翻译结果以多种方式展示给用户
- **功能**：
  - **双语对照模式**：译文以不同样式嵌入原文下方
  - **仅译文模式**：原文替换为译文
  - **Tooltip模式**：悬停时弹出浮动翻译层
  - **CSS变量控制**：背景色、字体、透明度、圆角等可配置
  - **原位覆盖**：通过绝对定位将译文覆盖在原文上
  - **动画过渡**：淡入淡出效果
- **技术**：Content Script、DOM操作、CSS注入、Shadow DOM

#### M9 — 视频字幕模块

- **职责**：视频平台双语字幕支持
- **功能**：
  - YouTube Player API集成
  - Netflix字幕轨道提取
  - 字幕时间轴对齐
  - 双语字幕轨道叠加
  - 字幕样式自定义
- **技术**：YouTube Player API、Content Script

#### M10 — PDF翻译模块

- **职责**：PDF文档双语翻译（保留原始排版）
- **功能**：
  - PDF.js文本层解析
  - 扫描件OCR（Tesseract.js）
  - 原文/译文双栏并排显示
  - 公式/表格保留
  - 页面级翻译缓存
- **技术**：PDF.js、Tesseract.js、Content Script

#### M11 — 术语库管理器

- **职责**：专业术语管理与翻译一致性
- **功能**：
  - 内置术语库（法律/医学/技术/金融等）
  - 用户自定义术语（关键词→翻译映射）
  - 术语匹配（正则匹配、模糊匹配）
  - 术语优先级（自定义术语 > 内置术语 > 引擎默认）
  - 术语库版本更新
- **技术**：IndexedDB、RegExp

#### M12 — 设置与配置中心

- **职责**：用户偏好统一管理
- **功能**：
  - 翻译引擎选择（默认引擎、备选引擎）
  - 源语言/目标语言设置
  - **快捷键自定义系统**（见第四章详述）
  - 显示样式配置（字体、颜色、大小、透明度）
  - **OCR引擎选择**：本地PP-OCRv6（Tiny/Small/Medium）/ SiliconFlow云端
  - 术语库管理
  - 隐私设置（是否允许云端翻译）
  - 设置导入/导出
- **技术**：`chrome.storage.sync`、Options Page

#### M13 — 历史记录服务（学习模块）

- **职责**：管理用户翻译历史记录，作为学习资产的基础数据源
- **功能**：
  - 翻译行为自动入池（每次翻译自动记录，无需手动操作）
  - 掌握度追踪（基于 SM-2 间隔重复算法，0~1 浮点数表示掌握程度）
  - 复习调度（自动计算下次复习时间，支持延迟/提前复习）
  - 来源溯源（记录翻译时的页面 URL 和上下文段落，复习时一键跳回原文）
  - 领域标签（自动或手动打标签：医学/法律/日常/技术，支持按领域筛选复习）
  - 去重合并（相同原文+相同语言对自动去重，合并复习记录）
- **技术**：IndexedDB（浏览器端）、chrome.storage.local（扩展设置端）

#### M14 — 生词本服务（学习模块）

- **职责**：管理用户生词库，提供主动学习系统
- **功能**：
  - **自动采集**：翻译行为自动入池；用户可设置过滤规则；支持手动添加
  - **间隔重复调度**：基于 SM-2 算法自动安排复习时间
  - **复习模式**：英→中、中→英、填空、听写四种模式
  - **掌握度追踪与毕业**：掌握度达到0.95且连续3次正确→毕业归档；衰减到0.3以下→回退待学习
- **技术**：IndexedDB、Web Worker（批量计算复习队列）

#### M15 — 复习引擎（学习模块）

- **职责**：实现 SM-2 间隔重复算法，管理复习调度与掌握度计算
- **功能**：
  - SM-2 算法实现（计算下次复习时间、更新 ease factor）
  - 掌握度衰减机制（长期未复习自动衰减）
  - 复习队列管理（获取到期复习列表、优先级排序）
  - 复习结果提交（用户反馈"忘了"/"有点印象"/"记住了"→更新掌握度）
  - 学习统计（每日/每周复习趋势、领域分布、掌握度分布）
- **技术**：纯 TypeScript 实现（无外部依赖），可运行在 Service Worker 中

#### M16 — 导出服务（学习模块）

- **职责**：将学习数据（历史记录+生词本）导出为多种格式
- **功能**：
  - JSON / CSV / Anki .apkg / Markdown / TSV / SRT 六种格式导出
  - 增量同步（上次导出以来的增量变更）
  - 版本兼容（导出文件包含版本号）
- **技术**：纯 TypeScript 实现，浏览器端 Blob API 下载

#### M17 — 本地大模型引擎接口

- **职责**：将本地部署的大语言模型作为翻译引擎接入系统，提供高质量离线翻译能力
- **功能**：
  - **本地模型服务发现**：自动探测本地运行的 Ollama / LM Studio / text-generation-webui 服务
  - **模型列表获取**：列出本地可用模型（Qwen2.5-7B / Llama-3-8B / ChatGLM3-6B 等）
  - **模型切换**：用户选择使用哪个本地模型进行翻译
  - **翻译Prompt模板**：预置多种翻译prompt模板（直译/意译/专业领域/文学翻译），支持用户自定义
  - **流式响应**：支持 SSE (Server-Sent Events) 流式输出，实时显示翻译进度
  - **上下文窗口管理**：自动处理长文本的上下文窗口分割与拼接
  - **批量翻译**：支持批量文本提交，提高吞吐量
  - **健康检查**：检测本地服务是否可用、模型是否加载
  - **降级策略**：本地模型不可用时自动降级到云端引擎（SiliconFlow/OpenAI等）
- **通信协议**：HTTP REST API（Ollama兼容接口）
  - 模型列表：`GET http://localhost:11434/api/tags`
  - 生成翻译：`POST http://localhost:11434/api/generate`
  - 聊天翻译：`POST http://localhost:11434/api/chat`
- **Rust壳集成**：通过 `reqwest` crate 调用本地HTTP接口，`tokio` 异步运行时处理并发请求
- **技术栈**：
  - 浏览器端：TypeScript + Fetch API / XMLHttpRequest
  - Rust壳：reqwest + tokio + serde
  - 本地服务：Ollama (默认) / LM Studio / text-generation-webui (可选)
- **优势**：
  - 完全离线运行，隐私安全，数据不出本机
  - 无API费用，可无限使用
  - 可定制翻译风格（通过prompt工程）
  - 支持多种开源模型，灵活选择质量/速度平衡
- **限制**：
  - 依赖用户自行安装和运行本地大模型服务
  - 推理速度取决于本地硬件（GPU加速显著优于CPU）
  - 首次加载模型可能需要等待（冷启动5-30秒）

#### M18 — AI对话界面

- **职责**：提供一个类ChatGPT的对话式AI界面，让用户可以通过自然语言与翻译系统交互
- **功能**：
  - **多轮对话**：保留完整对话上下文，支持多轮追问和澄清
  - **引擎切换**：在对话中随时切换翻译引擎/大模型（云端SF/OpenAI/Claude/本地Ollama等）
  - **对话历史管理**：保存、搜索、加载、删除对话历史
  - **文件上传**：支持上传图片/PDF/文档，AI可分析并翻译文件内容
  - **代码/公式渲染**：对话中嵌入的代码块和数学公式正确渲染
  - **对话导出**：导出为 Markdown / PDF / 纯文本格式
  - **学习模块集成**：对话中用户标记的词汇/句子自动加入生词本
  - **消息操作**：复制、重新生成、点赞/踩反馈、删除单条消息
  - **多会话管理**：同时维护多个独立对话会话
  - **快捷指令**：预设快捷指令（"翻译这段话"、"用更地道的表达"、"解释这个语法"等）
- **UI规格**：
  - 聊天消息气泡式布局（用户消息右对齐，AI消息左对齐）
  - 深色/浅色主题自动切换 + 手动切换
  - 响应式设计，适配不同屏幕尺寸
  - 打字机效果（流式输出时的逐字显示）
  - 加载状态指示器（三点跳动动画）
- **技术实现**：
  - 浏览器端：TypeScript + Content Script 注入
  - 状态管理：IndexedDB 存储对话历史
  - 文件处理：FileReader API + Canvas (图片) / PDF.js (PDF)
  - 流式响应：EventSource / fetch + ReadableStream
- **位置**：浏览器扩展侧栏（Side Panel）或 Popup 面板内嵌iframe
- **技术栈**：
  - 前端：TypeScript + CSS Variables (Design Tokens)
  - 状态管理：IndexedDB (store) + 内存缓存
  - 文件解析：PDF.js / Tesseract.js (图片OCR)
  - 代码高亮：Highlight.js (轻量级)

---

## 三、数据流设计

### 3.1 浏览器内翻译数据流

```
用户操作（悬停/划词/全页翻译）
        |
        v
+----------------------+
|   M1 交互管理器      |  获取用户操作类型和目标语言
+----------+-----------+
           |
           v
+----------------------+
|   M2/M3 内容采集     |  DOM遍历或getSelection获取文本
+----------+-----------+
           | text + lang_pair
           v
+----------------------+
|   M7 引擎路由器      |  智能选择最优翻译引擎
+----------+-----------+
           |
    +------+------+
    |             |
    v             v
+--------+  +------------+
|本地引擎|  |  云端引擎   |
|Edge    |  | SiliconFlow/|
|Translator| | Google/    |
|API      |  | MyMemory    |
+---+----+  +----+-------+
    |             |
    +-----+------+
          | translation
          v
+----------------------+
|   M8 结果渲染        |  DOM注入/CSS覆盖/Tooltip显示
+----------------------+
```

### 3.2 浏览器外（任意界面）翻译数据流（Rust壳）

```
用户触发全局快捷键（可配置，默认Ctrl+Shift+M）
        |
        v
+----------------------+
|   M6 Rust壳程序      |  DXGI Desktop Duplication截图
+----------+-----------+
           | 屏幕像素数据
           v
+----------------------+
|   M6 Rust壳程序      |  PP-OCRv6 ONNX Runtime OCR识别
|   (Tiny/Small/Medium)|  (本地离线，零key，~100ms)
+----------+-----------+
           | 识别文本 + 坐标
           v
+----------------------+
|   M6 Rust壳程序      |  打包JSON -> stdin写入(NM协议)
+----------+-----------+
           | Native Messaging (IPC管道)
           v
+----------------------+
|   M5 通信桥(插件端)   |  connectNative接收消息
+----------+-----------+
           | text + lang_pair
           v
+----------------------+
|   M7 引擎路由器      |  智能选择最优翻译引擎
+----------+-----------+
           | translation
           v
+----------------------+
|   M5 通信桥(插件端)   |  port.postMessage -> stdout返回
+----------+-----------+
           | Native Messaging (IPC管道)
           v
+----------------------+
|   M6 Rust壳程序      |  stdout读取JSON
+----------+-----------+
           | 译文 + 坐标
           v
+----------------------+
|   M6 Rust壳程序      |  winit浮窗/GDI+原位覆盖绘制译文
+----------------------+
```

### 3.3 视频字幕翻译数据流

```
用户打开视频页面
        |
        v
+----------------------+
|   M9 视频字幕模块    |  Player API监听字幕事件
+----------+-----------+
           | 字幕文本 + 时间轴
           v
+----------------------+
|   M7 引擎路由器      |  批量翻译字幕
+----------+-----------+
           | 翻译字幕 + 时间轴
           v
+----------------------+
|   M9 视频字幕模块    |  创建双语字幕轨道
+----------+-----------+
           |
           v
+----------------------+
|  视频播放器          |  叠加显示双语字幕
+----------------------+
```

### 3.4 学习数据流（历史记录 + 生词本 + 复习）

```
用户翻译行为（悬停/划词/全页/截图）
        |
        v
+----------------------+
|   M7 引擎路由器      |  执行翻译
+----------+-----------+
           | translation result
           v
+----------------------+
|   M8 结果渲染        |  展示翻译结果
+----------+-----------+
           |
           v
+----------------------+
|   M13 历史记录服务   |  自动入池（含来源溯源+领域标签）
+----------+-----------+
           | HistoryRecord
           v
+----------------------+
|   M14 生词本服务     |  自动采集/手动添加 → 进入待学习池
+----------+-----------+
           | VocabularyWord
           v
+----------------------+
|   M15 复习引擎       |  SM-2 计算下次复习时间
+----------+-----------+
           | ReviewSchedule
           v
+----------------------+
|   浏览器通知/侧栏    |  提醒用户复习
|   复习面板（闪卡）   |  四种复习模式
+----------+-----------+
           |
           v
+----------------------+
|   M16 导出服务       |  JSON/CSV/Anki/Markdown/TSV/SRT
+----------------------+
```

**收集闭环**：

```
翻译行为 → 自动入生词本 → 间隔重复复习 → 掌握度更新 → 毕业归档
    ↑                                                    │
    └────────── 导出/备份 ← 学习报告 ←──────────────────┘
```

### 3.5 AI对话数据流（v1.3新增）

```
用户在AI对话界面输入消息
        |
        v
+----------------------+
|   M18 AI对话界面     |  消息输入/渲染/上下文管理
+----------+-----------+
           | 消息文本 + 上下文ID
           v
+----------------------+
|   M18 AI对话界面     |  判断消息类型（翻译请求/闲聊/文件分析）
+----------+-----------+
           |
    +------+------+
    | 翻译请求     | 文件上传
    v             v
+--------+  +------------+
| M7引擎 |  | 文件处理器  |
| 路由器 |  | (PDF.js/    |
|        |  | Tesseract)  |
+---+----+  +----+-------+
    |             |
    v             v
+--------+  +------------+
|云端/   |  | 提取文本/   |
|本地LLM |  | OCR识别     |
|翻译    |  | 结果        |
+---+----+  +----+-------+
    |             |
    +-----+------+
          | 翻译/分析结果
          v
+----------------------+
|   M18 AI对话界面     |  流式渲染AI回复（打字机效果）
+----------+-----------+
           |
           v
+----------------------+
|   M13历史记录        |  自动保存对话到历史记录
+----------+-----------+
           |
           v
+----------------------+
|   M14生词本          |  用户标记的词汇自动入生词本
+----------+-----------+
           |
           v
+----------------------+
|   M16导出服务        |  对话导出（MD/PDF/文本）
+----------------------+
```

**对话上下文管理流**：

```
新对话开始
    |
    v
+----------------------+
| 创建对话会话          |  生成sessionID，初始化空上下文
+----------+-----------+
           |
           v
<用户发送消息>
           |
           v
+----------------------+
| 追加消息到上下文      |  用户消息 + AI回复成对存储
+----------+-----------+
           |
           v
+----------------------+
| 检查上下文窗口        |  超出窗口限制时裁剪最早消息
+----------+-----------+
           |
           v
+----------------------+
| 发送请求到引擎        |  带完整上下文发送
+----------+-----------+
           |
           v
+----------------------+
| 接收并渲染AI回复      |  流式显示 + 保存到上下文
+----------------------+
```

---

## 四、快捷键自定义系统（详细设计）

### 4.1 设计原则

快捷键系统遵循**第一性原理**：用户应该能完全控制如何触发翻译行为，且系统应智能处理冲突。

**核心原则**：
1. **自由录入**：用户通过界面直接按下目标组合键即可录入，无需手动输入键码
2. **冲突检测与自动回退**：检测到快捷键被占用时，自动尝试备选方案并提示用户
3. **即时生效**：修改后无需重启浏览器或壳程序，热键即时重新注册
4. **持久化**：设置保存到 `chrome.storage.sync`（浏览器端）+ `winocr_config.json`（Rust壳端）
5. **多端同步**：浏览器端设置通过 Native Messaging 同步到 Rust 壳

### 4.2 快捷键定义表

| 快捷键ID | 功能描述 | 默认值 | 作用域 | 说明 |
|---------|---------|--------|--------|------|
| `screenshot_area` | 区域截图翻译 | `Ctrl+Shift+M` | Rust壳 | 触发全局画框截图→OCR→翻译→浮窗显示 |
| `screenshot_full` | 全屏截图翻译 | `Ctrl+Shift+F` | Rust壳 | 触发全屏截图翻译（无需画框） |
| `quit_host` | 退出Rust壳程序 | `Ctrl+Alt+Q` | Rust壳 | 优雅退出宿主进程 |
| `open_panel` | 打开插件面板 | `Alt+Shift+W` | 浏览器 | 打开扩展Popup/侧栏 |
| `translate_selection` | 翻译选中文字 | `Alt+Shift+Z` | 浏览器 | 翻译当前页面选中文字 |
| `toggle_overlay` | 切换原位覆盖 | `Ctrl+O` | 浏览器 | 切换译文原位覆盖显示 |
| `start_review` | 开始复习 | `Ctrl+Shift+R` | 浏览器 | 打开复习面板 |
| `quick_add_word` | 快速添加生词 | `Ctrl+Shift+A` | 浏览器 | 将当前选中词添加到生词本 |
| `custom_1` | 用户自定义1 | 未设置 | 浏览器/壳 | 用户自由绑定 |
| `custom_2` | 用户自定义2 | 未设置 | 浏览器/壳 | 用户自由绑定 |

### 4.3 快捷键录入流程

```
用户进入设置页 → 点击"录入快捷键"输入框
        |
        v
+----------------------+
|  浏览器端录制        |  监听keydown事件，捕获组合键
+----------+-----------+
           | 组合键信息(Ctrl+Shift+M)
           v
+----------------------+
|  冲突检测            |  检查是否被其他扩展/系统占用
+----------+-----------+
        |
    +---+---+
    | 有冲突 |  无冲突
    v        v
+------+ +------------------+
|自动   | | 保存到chrome.    |
|尝试   | | storage.sync     |
|备选键 | +--------+---------+
|       |          |
|提示用户|          v
|选择    |    通过NM同步到Rust壳
+------+          |
                  v
          +----------------------+
          | Rust壳重新注册热键     |
          | PostThreadMessageW    |
          | (即时生效，不需重启)   |
          +----------------------+
```

### 4.4 冲突自动回退策略

当用户设置的快捷键已被占用时，系统按以下优先级尝试备选键：

```
用户设置: Ctrl+Shift+M (被WinOCR 3.4蒙版翻译占用)
        |
        v
+----------------------+
|  备选1: Ctrl+Alt+M   |  可用 → 提示用户"已自动切换为Ctrl+Alt+M"
+----------+-----------+
        | 仍被占用
        v
+----------------------+
|  备选2: Ctrl+Shift+F |  可用 → 提示用户
+----------+-----------+
        | 仍被占用
        v
+----------------------+
|  备选3: Alt+Shift+M  |  可用 → 提示用户
+----------+-----------+
        | 仍被占用
        v
+----------------------+
|  备选4: Ctrl+Alt+Z   |  可用 → 提示用户
+----------+-----------+
        | 全被占用
        v
+----------------------+
|  报错：请手动设置     |  指向配置项 winocr_config.json
+----------------------+
```

### 4.5 Rust壳端热键管理

Rust壳程序使用 `winapi` crate 管理全局热键：

```rust
// 热键注册核心逻辑（伪代码）
use winapi::um::winuser::{RegisterHotKey, UnregisterHotKey, MOD_ALT, MOD_CONTROL, MOD_SHIFT};

struct HotKeyManager {
    hotkeys: HashMap<String, HotKey>,
    window_handle: HWND,
}

impl HotKeyManager {
    fn register(&mut self, id: &str, modifiers: u32, vk: u32) -> Result<(), HotKeyError> {
        unsafe {
            let success = RegisterHotKey(self.window_handle, id as i32, modifiers, vk);
            if success == 0 {
                Err(HotKeyError::RegistrationFailed)
            } else {
                Ok(())
            }
        }
    }

    fn unregister_all(&mut self) {
        for hotkey in self.hotkeys.values() {
            unsafe { UnregisterHotKey(self.window_handle, hotkey.id as i32); }
        }
    }

    fn reload_from_config(&mut self, config: &HotKeyConfig) {
        self.unregister_all();
        for (name, key_def) in config.hotkeys.iter() {
            self.register(name, key_def.modifiers, key_def.vk);
        }
    }
}
```

### 4.6 快捷键配置文件格式

```json
{
  "hotkeys": {
    "screenshot_area": {
      "key": "m",
      "modifiers": ["ctrl", "shift"],
      "description": "区域截图翻译"
    },
    "screenshot_full": {
      "key": "f",
      "modifiers": ["ctrl", "shift"],
      "description": "全屏截图翻译"
    },
    "quit_host": {
      "key": "q",
      "modifiers": ["ctrl", "alt"],
      "description": "退出宿主程序"
    },
    "custom_1": null,
    "custom_2": null
  },
  "hotkeyConflictStrategy": "autoFallback",
  "lastConflictResult": "screenshot_area: auto-fallback to Ctrl+Alt+M"
}
```

---

## 五、界面设计与UI规范

### 5.1 设计哲学

**核心原则：工具是从属表面，绝不违反阅读焦点。**

UI设计服务于翻译这个核心行为，不喧宾夺主。采用**工业实用**风格——信息密度高、层级清晰、操作路径最短。

### 5.2 设计令牌（Design Tokens）

#### 色彩体系

| 令牌 | 色值 | 用途 |
|------|------|------|
| `--color-primary` | `#1677ff` | 主色调（按钮、链接、激活态） |
| `--color-primary-hover` | `#4096ff` | 悬停态 |
| `--color-primary-active` | `#0958d9` | 按下态 |
| `--color-success` | `#52c41a` | 成功状态 |
| `--color-warning` | `#faad14` | 警告状态 |
| `--color-error` | `#ff4d4f` | 错误状态 |
| `--color-text-primary` | `rgba(0,0,0,0.88)` | 主文本 |
| `--color-text-secondary` | `rgba(0,0,0,0.65)` | 次要文本 |
| `--color-text-disabled` | `rgba(0,0,0,0.25)` | 禁用态文本 |
| `--color-bg-container` | `#ffffff` | 容器背景 |
| `--color-bg-layout` | `#f5f5f5` | 布局背景 |
| `--color-border` | `#d9d9d9` | 边框色 |
| `--color-shadow` | `rgba(0,0,0,0.15)` | 阴影色 |

#### 暗色模式令牌

| 令牌 | 色值 | 用途 |
|------|------|------|
| `--color-primary` | `#4096ff` | 主色调（暗色适配） |
| `--color-text-primary` | `rgba(255,255,255,0.85)` | 主文本 |
| `--color-bg-container` | `#141414` | 容器背景 |
| `--color-bg-layout` | `#000000` | 布局背景 |
| `--color-border` | `#303030` | 边框色 |

#### 字体体系

| 用途 | 字体栈 | 字号 |
|------|--------|------|
| 中文标题 | `PingFang SC, Microsoft YaHei UI, -apple-system, BlinkMacSystemFont, sans-serif` | 16px/14px/12px |
| 中文正文 | `PingFang SC, Microsoft YaHei UI, -apple-system, BlinkMacSystemFont, sans-serif` | 14px |
| 等宽数字 | `SF Mono, Monaco, Consolas, 'Liberation Mono', monospace` | 12px |
| 英文/代码 | `SF Mono, Monaco, Consolas, 'Liberation Mono', monospace` | 13px |

#### 间距体系

| 令牌 | 值 | 用途 |
|------|------|------|
| `--spacing-xs` | `4px` | 紧凑间距 |
| `--spacing-sm` | `8px` | 小间距 |
| `--spacing-md` | `12px` | 中等间距 |
| `--spacing-lg` | `16px` | 大间距 |
| `--spacing-xl` | `24px` | 超大间距 |

#### 圆角与阴影

| 令牌 | 值 | 用途 |
|------|------|------|
| `--radius-sm` | `4px` | 小圆角（标签、输入框） |
| `--radius-md` | `6px` | 中圆角（按钮、卡片） |
| `--radius-lg` | `8px` | 大圆角（弹窗、面板） |
| `--shadow-sm` | `0 2px 4px rgba(0,0,0,0.1)` | 小阴影 |
| `--shadow-md` | `0 4px 12px rgba(0,0,0,0.15)` | 中阴影 |
| `--shadow-lg` | `0 8px 24px rgba(0,0,0,0.2)` | 大阴影 |

### 5.3 按钮设计规范

#### 按钮类型

| 按钮类型 | 样式 | 使用场景 |
|---------|------|---------|
| **主按钮** | 实心填充 `#1677ff`，白色文字，圆角6px | 主要操作（翻译、保存、提交） |
| **次按钮** | 边框 `#1677ff`，文字 `#1677ff`，圆角6px | 次要操作（取消、重置） |
| **文本按钮** | 无背景无边框，文字 `#1677ff` | 链接式操作（了解更多、查看详情） |
| **危险按钮** | 实心填充 `#ff4d4f`，白色文字 | 删除、重置等危险操作 |
| **图标按钮** | 圆形/方形，仅图标无文字 | 工具栏图标（设置、关闭、最小化） |
| **胶囊按钮** | 圆角16px（pill形状），小字号 | 标签切换、引擎选择 |

#### 按钮尺寸

| 尺寸 | 高度 | 字号 | 内边距 | 适用场景 |
|------|------|------|--------|---------|
| **大** | `44px` | `14px` | `8px 16px` | 面板主操作按钮 |
| **中** | `32px` | `14px` | `6px 12px` | 常规操作按钮 |
| **小** | `24px` | `12px` | `4px 8px` | 工具栏、紧凑布局 |
| **迷你** | `20px` | `12px` | `2px 6px` | 标签、状态指示 |

#### 按钮交互状态

```css
/* 主按钮状态变化 */
.btn-primary {
  background: #1677ff;
  color: white;
  border: none;
  transition: all 160ms ease;
}

.btn-primary:hover {
  background: #4096ff;
  box-shadow: 0 2px 8px rgba(22, 119, 255, 0.35);
  transform: translateY(-1px);
}

.btn-primary:active {
  background: #0958d9;
  transform: translateY(0);
  box-shadow: none;
}

.btn-primary:disabled {
  background: #d9d9d9;
  color: rgba(0,0,0,0.25);
  cursor: not-allowed;
  transform: none;
  box-shadow: none;
}
```

### 5.4 面板/弹窗设计规范

#### 面板结构

```
+--------------------------------------------------+
|  [Logo]  WinOCR           [引擎徽标]  [设置图标] |  ← 粘性页头（高度48px）
+--------------------------------------------------+
|                                                  |
|  [翻译输入区 - 多行文本框，带占位符提示]           |  ← 间距16px
|                                                  |
|  [源语言 ▼]  [目标语言 ▼]    [翻译按钮(主)]      |  ← 间距12px
|                                                  |
+--------------------------------------------------+
|  译文结果区                                      |
|  +--------------------------------------------+ |
|  | The patient presented with acute...        | |  ← 卡片样式
|  | 患者出现急性尿潴留。                         | |    圆角8px+阴影
|  | [复制] [朗读] [加入生词本] [复习]           | |
|  +--------------------------------------------+ |
|                                                  |
+--------------------------------------------------+
|  [历史记录] [生词本] [复习] [导出]                |  ← 底部导航栏
+--------------------------------------------------+
```

#### 卡片组件规范

| 属性 | 值 | 说明 |
|------|------|------|
| 圆角 | `8px` | 统一圆角 |
| 阴影 | `0 2px 8px rgba(0,0,0,0.09)` | 默认阴影 |
| 悬停阴影 | `0 4px 12px rgba(0,0,0,0.12)` | 悬停增强 |
| 内边距 | `12px 16px` | 内容间距 |
| 背景 | `#ffffff`（亮色）/ `#1f1f1f`（暗色） | 容器色 |
| 边框 | `1px solid #f0f0f0` | 细分隔线 |

#### 输入框规范

| 属性 | 值 | 说明 |
|------|------|------|
| 高度 | `32px`（中）/ `44px`（大） | 与按钮对齐 |
| 圆角 | `6px` | 统一圆角 |
| 边框 | `1px solid #d9d9d9` | 默认边框 |
| 聚焦边框 | `2px solid #1677ff` | 聚焦高亮 |
| 内边距 | `6px 12px` | 输入间距 |
| 过渡 | `all 160ms ease` | 平滑状态变化 |

### 5.5 动画与动效规范

| 动效 | 时长 | 缓动函数 | 用途 |
|------|------|---------|------|
| 淡入/淡出 | `160ms` | `ease` | 面板开关、结果出现 |
| 滑入/滑出 | `200ms` | `cubic-bezier(0.4, 0, 0.2, 1)` | 侧栏展开/收起 |
| 按钮悬停 | `160ms` | `ease` | 按钮交互反馈 |
| 卡片悬浮 | `200ms` | `cubic-bezier(0.4, 0, 0.2, 1)` | 卡片悬停上浮 |
| 加载旋转 | `1s` | `linear` 无限 | 翻译加载中 |

**无障碍**：所有动效必须尊重 `prefers-reduced-motion: reduce` 媒体查询，用户偏好减少动效时全部关闭。

### 5.6 浮窗（Rust壳译文显示）设计规范

Rust壳的译文浮窗采用**置顶透明窗口**实现：

| 属性 | 值 | 说明 |
|------|------|------|
| 窗口类型 | 顶层置顶 + 透明背景 + 点击穿透 | 不遮挡用户操作 |
| 圆角 | `6px` | 现代感 |
| 阴影 | `0 4px 16px rgba(0,0,0,0.2)` | 浮出感 |
| 字体 | 系统默认无衬线字体 | 与系统融合 |
| 文字颜色 | `#1a1a1a`（亮背景）/ `#f0f0f0`（暗背景） | 自适应 |
| 动画 | 出现时 `scale(0.95) → scale(1)` + 淡入，`200ms` | 平滑出现 |
| 关闭方式 | 点击外部区域 / `Esc` / 自动消失（可配置超时） | 灵活 |

### 5.7 图标规范

| 图标 | 尺寸 | 线宽 | 圆角 | 用途 |
|------|------|------|------|------|
| 常规图标 | `16px` / `20px` / `24px` | `1.5px` | `2px` | 工具栏、列表项 |
| 大图标 | `32px` / `40px` | `2px` | `3px` | 空状态、引导页 |
| 加载图标 | `20px` | `2px` | `-` | 加载中旋转 |

**图标风格**：线性图标（Outline），统一线宽，圆角端点，保持视觉一致性。

### 5.8 AI对话界面设计规范（v1.3新增）

#### 布局结构

```
+--------------------------------------------------+
|  [WinOCR Logo]  AI对话        [引擎徽标] [设置]  |  ← 顶部导航栏 (48px)
+--------------------------------------------------+
|                                                  |
|  +--------------------------------------------+ |
|  | 📄 对话标题：英文学习会话                    | |  ← 会话标题栏
|  | [切换引擎: Qwen-7B ▼] [清空] [导出]         | |
|  +--------------------------------------------+ |
|                                                  |
|  +--------------------------------------------+ |
|  | 用户：翻译下面这段话                          | |  ← 消息气泡区(可滚动)
|  | [右对齐/蓝色背景]                             | |
|  |                                              | |
|  | AI：当然可以！请提供您需要翻译的内容...       | |  ← AI消息
|  | [左对齐/灰色背景]                             | |
|  | (打字机效果：逐字显示)                        | |
|  +--------------------------------------------+ |
|                                                  |
|  +--------------------------------------------+ |
|  | [📎附件] [输入消息...]            [发送▲]   | |  ← 输入区
|  +--------------------------------------------+ |
|  [上传图片] [上传PDF] [快捷指令: 翻译/解释/改写]|
+--------------------------------------------------+
```

#### 消息气泡样式

| 属性 | 用户消息 | AI消息 |
|------|---------|--------|
| 对齐 | 右对齐 | 左对齐 |
| 背景色 | `#1677ff` (主色) | `#f5f5f5` (浅灰) |
| 文字颜色 | `#ffffff` (白) | `#1a1a1a` (深色) |
| 圆角 | `12px 12px 4px 12px` | `12px 12px 12px 4px` |
| 最大宽度 | 70% | 70% |
| 内边距 | `10px 14px` | `10px 14px` |
| 阴影 | `0 2px 8px rgba(22,119,255,0.15)` | `0 2px 8px rgba(0,0,0,0.06)` |

#### 输入区设计

| 属性 | 值 | 说明 |
|------|------|------|
| 高度 | `44px`（单行）/ 自适应（多行） | 与按钮对齐 |
| 圆角 | `22px`（胶囊形） | 现代感 |
| 边框 | `1px solid #d9d9d9` | 默认边框 |
| 聚焦边框 | `2px solid #1677ff` | 聚焦高亮 |
| 内边距 | `12px 16px` | 输入间距 |
| 发送按钮 | 圆形图标按钮，主色填充 | 右对齐 |
| 附件按钮 | 图标按钮，边框样式 | 左对齐 |

#### 引擎选择器

- 位置：对话栏顶部，显示当前使用的引擎/模型
- 样式：胶囊按钮（`border-radius: 16px`），点击展开下拉菜单
- 选项列表：显示所有可用引擎，标注状态（在线/离线/本地/云端）
- 切换动画：平滑过渡，切换时显示加载指示器

#### 快捷指令栏

- 位置：输入框下方，水平滚动标签栏
- 样式：胶囊标签，默认灰色边框
- 激活态：主色填充 + 白色文字
- 预设指令：`翻译这段话` `用更地道的表达` `解释语法` `举例说明` `缩写展开` `同义词替换`

#### 加载状态

- 打字机效果：AI回复逐字显示（每字50ms延迟）
- 加载指示器：三个跳动圆点（`#1677ff`主色）
- 流式输出：使用 ReadableStream 实时接收并渲染

#### 文件上传处理

- 支持格式：图片(JPG/PNG/GIF/WebP)、PDF、TXT、DOCX
- 上传反馈：显示文件名 + 进度条 + 处理状态
- OCR处理：图片/PDF扫描件 → Tesseract.js/PP-OCRv6 → 提取文本 → 送入AI

#### 深色模式适配

| 元素 | 浅色模式 | 深色模式 |
|------|---------|---------|
| 页面背景 | `#ffffff` | `#141414` |
| 用户气泡 | `#1677ff` | `#4096ff` |
| AI气泡 | `#f5f5f5` | `#2a2a2a` |
| 输入框背景 | `#ffffff` | `#1f1f1f` |
| 输入框边框 | `#d9d9d9` | `#303030` |
| 文字主色 | `#1a1a1a` | `#f0f0f0` |
| 文字次要 | `#888888` | `#888888` |

---

## 六、接口定义

### 6.1 Native Messaging 接口（插件 <-> Rust壳）

#### 请求消息（Rust壳 -> 插件）

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| type | string | 是 | 消息类型："translate"/"ping"/"screenshot"/"ocr_result" |
| text | string | 条件 | 需要翻译的文本（OCR识别结果） |
| source_lang | string | 是 | 源语言代码（如 "en", "ja", "ko"） |
| target_lang | string | 是 | 目标语言代码（如 "zh", "en"） |
| task | string | 是 | 任务类型："ocr_translate"/"text_translate"/"screenshot" |
| timestamp | number | 是 | 请求时间戳（毫秒），用于去重 |
| screenshot | string | 条件 | Base64编码的截图（screenshot任务时） |
| ocr_model | string | 条件 | 使用的OCR模型档位："tiny"/"small"/"medium" |
| ocr_confidence | number | 条件 | OCR置信度（0-1） |

#### 响应消息（插件 -> Rust壳）

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| type | string | 是 | 消息类型："translate_result"/"pong"/"error" |
| translation | string | 条件 | 翻译结果文本 |
| original_text | string | 条件 | 原文内容 |
| source_lang | string | 是 | 源语言代码 |
| target_lang | string | 是 | 目标语言代码 |
| engine | string | 是 | 使用的翻译引擎名称 |
| ok | boolean | 是 | 是否成功 |
| error | string | 条件 | 错误信息 |
| boxes | array | 条件 | 文字位置坐标数组（OCR场景） |

### 6.2 浏览器插件内部接口

#### TranslationEngine 接口（翻译引擎抽象）

```typescript
interface TranslationEngine {
  name: string;                    // 引擎名称
  available: boolean;               // 是否可用
  supportsLanguagePair(src: string, tgt: string): boolean;
  translate(text: string, src: string, tgt: string): Promise<TranslateResult>;
  translateBatch(texts: TextItem[], tgt: string): Promise<TranslateResult[]>;
  healthCheck(): Promise<boolean>;
}

interface TranslateResult {
  text: string;                     // 翻译结果
  confidence?: number;              // 置信度
  engine: string;                   // 使用引擎
  cached?: boolean;                 // 是否来自缓存
}
```

#### ContentService 接口（内容采集抽象）

```typescript
interface ContentService {
  type: 'dom' | 'selection' | 'ocr' | 'video' | 'pdf';
  capture(): Promise<ContentCapture>;
}

interface ContentCapture {
  text: string;                     // 捕获的文本
  lang: string;                     // 检测到的语言
  metadata: Record<string, any>;    // 附加元数据（坐标、时间戳等）
}
```

#### RenderingService 接口（结果渲染抽象）

```typescript
interface RenderingService {
  mode: 'bilingual' | 'translation_only' | 'tooltip' | 'overlay';
  render(result: TranslateResult, metadata: Record<string, any>): void;
  destroy(): void;
}
```

### 6.3 配置接口

```typescript
interface AppConfig {
  // 翻译配置
  defaultSourceLang: string;
  defaultTargetLang: string;
  preferredEngine: string;
  fallbackEngines: string[];
  enableOffline: boolean;

  // OCR配置
  ocrEngine: 'ppocr_tiny' | 'ppocr_small' | 'ppocr_medium' | 'siliconflow';
  ocrLang: string[];
  enhanceImage: boolean;

  // 显示配置
  translationStyle: TranslationStyle;
  tooltipPosition: TooltipPosition;
  overlayOpacity: number;

  // 快捷键配置
  hotkeys: Record<string, HotKeyConfig>;

  // 术语库配置
  enabledTermBases: string[];
  customTerms: CustomTerm[];

  // 隐私配置
  allowCloudTranslation: boolean;
  cacheTranslations: boolean;
}

interface HotKeyConfig {
  key: string;                     // 键帽字符
  modifiers: ('ctrl' | 'alt' | 'shift' | 'meta')[];  // 修饰键
  description: string;             // 功能描述
  isConflict: boolean;             // 是否有冲突
  fallbackKey?: string;            // 回退键（冲突时自动切换）
}
```

### 6.4 学习模块接口

#### HistoryService 接口（历史记录服务抽象）

```typescript
interface HistoryService {
  addRecord(record: Omit<HistoryRecord, 'id' | 'mastery' | 'reviewCount'>): Promise<HistoryRecord>;
  getRecord(id: string): Promise<HistoryRecord | null>;
  getRecords(filter?: RecordFilter): Promise<HistoryRecord[]>;
  deleteRecord(id: string): Promise<void>;
  updateRecord(id: string, updates: Partial<HistoryRecord>): Promise<HistoryRecord>;
  exportRecords(config: ExportConfig): Promise<ExportResult>;
  importRecords(data: HistoryRecord[]): Promise<number>;
  getStats(): Promise<ReviewStats>;
}
```

#### VocabularyService 接口（生词本服务抽象）

```typescript
interface VocabularyService {
  addWord(word: Omit<VocabularyWord, 'wordId' | 'mastery' | 'reviewCount'>): Promise<VocabularyWord>;
  getWord(id: string): Promise<VocabularyWord | null>;
  getWords(filter?: WordFilter): Promise<VocabularyWord[]>;
  updateWord(id: string, updates: Partial<VocabularyWord>): Promise<VocabularyWord>;
  deleteWord(id: string): Promise<void>;
  importWords(data: VocabularyWord[]): Promise<number>;
  exportWords(config: ExportConfig): Promise<ExportResult>;
  mergeDuplicates(): Promise<number>;
}
```

#### ReviewEngine 接口（复习引擎抽象）

```typescript
interface ReviewEngine {
  calculateNextReview(word: VocabularyWord, quality: ReviewQuality): ReviewSchedule;
  getDueReviews(): Promise<VocabularyWord[]>;
  submitReview(wordId: string, quality: ReviewQuality): Promise<VocabularyWord>;
  submitReviews(reviews: ReviewSubmission[]): Promise<VocabularyWord[]>;
  getStats(): Promise<ReviewStats>;
  getDailyTrend(days: number): Promise<DailyStat[]>;
  decayMastery(cutoffDays: number): Promise<string[]>;
  checkGraduation(): Promise<string[]>;
}

type ReviewQuality = 0 | 1 | 2 | 3;
// 0 = 完全忘记  1 = 困难  2 = 一般  3 = 容易
```

#### ExportService 接口（导出服务抽象）

```typescript
interface ExportService {
  exportToJSON(records: HistoryRecord[], words: VocabularyWord[], config: ExportConfig): Promise<ExportResult>;
  exportToCSV(records: HistoryRecord[], words: VocabularyWord[], config: ExportConfig): Promise<ExportResult>;
  exportToAnki(records: HistoryRecord[], words: VocabularyWord[], config: ExportConfig): Promise<ExportResult>;
  exportToMarkdown(records: HistoryRecord[], words: VocabularyWord[], config: ExportConfig): Promise<ExportResult>;
  exportToTSV(records: HistoryRecord[], words: VocabularyWord[], config: ExportConfig): Promise<ExportResult>;
  exportToSRT(words: VocabularyWord[], config: ExportConfig): Promise<ExportResult>;
  importFromJSON(data: string): Promise<ImportResult>;
  validateExport(data: string, format: ExportFormat): Promise<ValidationResult>;
}
```

### 6.5 LocalLLMService 接口（本地大模型引擎抽象，v1.3新增）

```typescript
interface LocalLLMService {
  // 服务发现
  discoverServices(): Promise<LocalServiceInfo[]>;
  healthCheck(serviceUrl: string): Promise<boolean>;

  // 模型管理
  getModelList(serviceUrl?: string): Promise<LLMModel[]>;
  switchModel(modelName: string): Promise<void>;
  getActiveModel(): Promise<LLMModel | null>;

  // 翻译功能
  translate(text: string, params?: LLMTranslateParams): Promise<TranslationResult>;
  translateStream(text: string, params?: LLMTranslateParams): AsyncIterable<string>;
  batchTranslate(texts: string[], params?: LLMTranslateParams): Promise<TranslationResult[]>;

  // 聊天功能（多轮对话）
  chat(messages: ChatMessage[], params?: LLMChatParams): Promise<ChatResponse>;
  chatStream(messages: ChatMessage[], params?: LLMChatParams): AsyncIterable<ChatChunk>;

  // 配置
  updateConfig(config: LocalLLMConfig): Promise<void>;
  getConfig(): Promise<LocalLLMConfig>;
}

interface LocalServiceInfo {
  name: string;               // 服务名称: "Ollama" / "LM Studio" / "text-generation-webui"
  url: string;                // 服务地址
  version?: string;           // 服务版本
  available: boolean;         // 是否可达
}

interface LLMModel {
  id: string;                 // 模型ID (如 "qwen2.5:7b")
  name: string;               // 模型名称
  size: string;               // 模型大小
  parameters: string;         // 参数量
  quantization?: string;      // 量化方式
}

interface LLMTranslateParams {
  model?: string;             // 指定模型
  temperature?: number;       // 随机性 (0-2)
  maxTokens?: number;         // 最大生成token数
  promptTemplate?: string;    // 自定义prompt模板
  systemPrompt?: string;      // 系统提示词
}

interface LLMChatParams {
  model?: string;
  temperature?: number;
  maxTokens?: number;
  keepContext?: boolean;      // 是否保留上下文
  contextWindow?: number;     // 上下文窗口大小
}

interface LocalLLMConfig {
  serviceType: 'ollama' | 'lmstudio' | 'textgen';
  serviceUrl: string;         // 默认 http://localhost:11434
  defaultModel: string;
  timeout: number;            // 请求超时(ms)
  enableStreaming: boolean;   // 是否启用流式
  autoFallback: boolean;      // 失败时自动降级到云端
}
```

### 6.6 AIChatService 接口（AI对话服务抽象，v1.3新增）

```typescript
interface AIChatService {
  // 会话管理
  createSession(title?: string): Promise<ChatSession>;
  getSession(sessionId: string): Promise<ChatSession | null>;
  listSessions(filter?: SessionFilter): Promise<ChatSession[]>;
  deleteSession(sessionId: string): Promise<void>;
  updateSessionTitle(sessionId: string, title: string): Promise<ChatSession>;

  // 消息管理
  sendMessage(sessionId: string, message: ChatInput): Promise<AsyncIterable<ChatChunk>>;
  getMessages(sessionId: string): Promise<ChatMessage[]>;
  deleteMessage(sessionId: string, messageId: string): Promise<void>;
  regenerateMessage(sessionId: string, messageId: string): Promise<AsyncIterable<ChatChunk>>;

  // 引擎切换
  setSessionEngine(sessionId: string, engineId: string): Promise<void>;
  getSessionEngine(sessionId: string): Promise<string>;

  // 文件处理
  attachFile(sessionId: string, file: File): Promise<FileAttachment>;
  processFile(sessionId: string, fileId: string): Promise<FileAnalysisResult>;

  // 导出
  exportSession(sessionId: string, format: ExportFormat): Promise<ExportResult>;

  // 学习集成
  addToVocabulary(sessionId: string, messageId: string): Promise<void>;
  getLearningStats(sessionId?: string): Promise<LearningStats>;
}

interface ChatSession {
  sessionId: string;
  title: string;
  engineId: string;           // 当前使用的引擎
  createdAt: number;
  updatedAt: number;
  messageCount: number;
}

interface ChatInput {
  content: string;
  files?: FileAttachment[];   // 附加文件
  command?: string;           // 快捷指令
}

interface ChatMessage {
  messageId: string;
  sessionId: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  files?: FileAttachment[];
  engineUsed?: string;        // 使用哪个引擎回复的
  createdAt: number;
  isRegenerated?: boolean;
}

interface ChatChunk {
  messageId: string;
  delta: string;              // 增量文本（流式）
  done: boolean;              // 是否完成
  usage?: UsageStats;         // token使用情况
}

interface FileAttachment {
  fileId: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  processedText?: string;     // 处理后的文本内容
}

interface FileAnalysisResult {
  text: string;               // 提取的文本
  pageCount?: number;         // PDF页数
  imageUrl?: string;          // OCR后的图片(如果有)
  error?: string;
}

interface SessionFilter {
  keyword?: string;           // 搜索关键词
  engineId?: string;          // 按引擎筛选
  dateRange?: { start: number; end: number };
  limit?: number;
}

interface LearningStats {
  wordsAdded: number;         // 对话中添加的生词数
  sessionsCount: number;      // 会话总数
  totalMessages: number;      // 总消息数
  enginesUsed: Record<string, number>;  // 各引擎使用次数
}
```

---

## 七、开发优先级与里程碑

### 7.1 总体时间规划

| 阶段 | 时间 | 目标 | 交付物 |
|------|------|------|--------|
| **Phase 0** | 第1-2周 | 基础架构搭建 | 项目脚手架、CI/CD、代码规范 |
| **Phase 1** | 第3-6周 | 核心能力MVP | 浏览器内DOM翻译 + Tooltip渲染 |
| **Phase 2** | 第7-10周 | 多引擎与OCR | 引擎路由器 + Tesseract.js OCR |
| **Phase 3** | 第11-14周 | 浏览器外能力 | Native Messaging + Rust壳程序 |
| **Phase 4** | 第15-18周 | 高级功能+UI完善 | 视频字幕、PDF翻译、术语库、UI设计 |
| **Phase 5** | 第19-20周 | 优化与发布 | 性能优化、测试、上架商店 |
| **Phase 6** | 第21-26周 | 学习模块 | 历史记录、生词本、复习引擎、导出 |

### 7.2 Phase 0：基础架构搭建（第1-2周）

| 任务 | 负责人 | 预估工时 | 依赖 |
|------|--------|---------|------|
| 项目仓库初始化（Monorepo结构） | 架构师 | 1天 | - |
| 构建工具链配置（Vite + TypeScript） | 前端工程师 | 1天 | - |
| Chrome Extension Manifest V3 基础模板 | 前端工程师 | 1天 | - |
| Service Worker 基础通信框架 | 前端工程师 | 2天 | Manifest模板 |
| **Rust本地壳项目脚手架** | 后端工程师 | 2天 | - |
| **Cargo.toml配置（serde/onnxruntime/winapi/winit）** | 后端工程师 | 1天 | Rust脚手架 |
| Native Messaging Host 注册脚本 | 后端工程师 | 1天 | Rust脚手架 |
| ESLint/Prettier/Commitlint配置 | 全员 | 1天 | - |
| **Clippy + Rustfmt代码规范** | 全员 | 1天 | - |
| GitHub Actions CI/CD流水线 | 运维 | 2天 | - |
| 单元测试框架搭建 | 测试工程师 | 2天 | - |

### 7.3 Phase 1：核心能力MVP（第3-6周）

| 任务 | 负责人 | 预估工时 | 依赖 |
|------|--------|---------|------|
| M2 DOM内容采集器（基础遍历） | 前端工程师 | 3天 | Phase 0 |
| M2 DOM内容采集器（智能识别+过滤） | 前端工程师 | 3天 | DOM基础 |
| M2 MutationObserver动态监听 | 前端工程师 | 2天 | DOM基础 |
| M3悬停翻译器（基础版） | 前端工程师 | 3天 | DOM采集器 |
| M8结果渲染引擎（双语对照模式） | 前端工程师 | 4天 | 悬停翻译器 |
| M8结果渲染引擎（Tooltip模式） | 前端工程师 | 3天 | 双语对照 |
| M7翻译引擎路由器（Google引擎） | 前端工程师 | 3天 | 渲染引擎 |
| M7翻译引擎路由器（Bing引擎） | 前端工程师 | 2天 | Google引擎 |
| M12设置与配置中心（基础版） | 前端工程师 | 3天 | 路由器 |
| M1用户交互管理器（快捷键+Popup） | 前端工程师 | 3天 | 配置中心 |
| MVP内部测试与调试 | 全员 | 3天 | 全部模块 |

**MVP里程碑交付物**：安装插件后可在网页上实现悬停翻译和全页翻译，支持Google和Bing两种引擎。

### 7.4 Phase 2：多引擎与OCR（第7-10周）

| 任务 | 负责人 | 预估工时 | 依赖 |
|------|--------|---------|------|
| M7引擎路由器（SiliconFlow引擎集成） | 前端工程师 | 3天 | Phase 1 |
| M7引擎路由器（Edge Translator API集成） | 前端工程师 | 4天 | SiliconFlow引擎 |
| M7引擎路由器（MyMemory免Key引擎） | 前端工程师 | 2天 | Edge引擎 |
| M7智能路由策略实现 | 前端工程师 | 3天 | 所有引擎 |
| M4屏幕截图OCR引擎（Tesseract.js集成） | 前端工程师 | 5天 | Edge引擎 |
| M4语言包懒加载机制 | 前端工程师 | 2天 | Tesseract集成 |
| M10 PDF翻译模块（基础版） | 前端工程师 | 5天 | OCR引擎 |
| M11术语库管理器（基础版） | 前端工程师 | 3天 | 路由器 |
| M8渲染引擎增强（CSS变量配置） | 前端工程师 | 2天 | 基础渲染 |
| 请求缓存机制（IndexedDB） | 前端工程师 | 3天 | 路由器 |
| 失败自动降级与并发请求优化 | 前端工程师 | 3天 | 路由器 |
| Phase 2测试与调试 | 全员 | 3天 | 全部模块 |

**Phase 2里程碑交付物**：支持6+翻译引擎智能路由、浏览器内图片OCR翻译、PDF文档翻译、术语库管理。

### 7.5 Phase 3：浏览器外能力 — Rust壳开发（第11-14周）

| 任务 | 负责人 | 预估工时 | 依赖 |
|------|--------|---------|------|
| M5 Native Messaging通信桥（插件端） | 前端工程师 | 3天 | Phase 2 |
| M5 Native Messaging通信桥（Rust壳端） | 后端工程师 | 3天 | 插件端 |
| **M6 Rust壳：截图模块（DXGI+BitBlt）** | 后端工程师 | 5天 | Phase 0 Rust脚手架 |
| **M6 Rust壳：PP-OCRv6 ONNX Runtime集成** | 后端工程师 | 7天 | 截图模块 |
| **M6 Rust壳：三档模型管理（Tiny/Small/Medium）** | 后端工程师 | 3天 | OCR集成 |
| **M6 Rust壳：winit浮窗+GDI绘制** | 后端工程师 | 5天 | OCR模块 |
| **M6 Rust壳：全局热键管理（含冲突回退）** | 后端工程师 | 4天 | 绘制模块 |
| **M6 Rust壳：JSON序列化/反序列化** | 后端工程师 | 2天 | 通信桥 |
| **M6 Rust壳：单实例保护+多实例名册** | 后端工程师 | 3天 | 热键模块 |
| **M6 Rust壳：配置管理（winocr_config.json）** | 后端工程师 | 2天 | 通信桥 |
| 端到端联调（插件<->Rust壳） | 前后端协作 | 5天 | 全部子模块 |
| 多显示器支持 | 后端工程师 | 2天 | 联调完成 |
| 内存管理与异常处理 | 后端工程师 | 3天 | 联调完成 |
| Phase 3测试与调试 | 全员 | 4天 | 全部模块 |

**Phase 3里程碑交付物**：Rust壳程序编译为~100-200KB可执行文件，通过全局快捷键在任何界面实现截图翻译，译文原位覆盖显示。启动时间<50ms，内存占用<30MB。

### 7.6 Phase 4：高级功能与UI完善（第15-18周）

| 任务 | 负责人 | 预估工时 | 依赖 |
|------|--------|---------|------|
| M9视频字幕模块（YouTube） | 前端工程师 | 5天 | Phase 2 |
| M9视频字幕模块（Netflix） | 前端工程师 | 4天 | YouTube |
| M10 PDF翻译模块（扫描件OCR） | 前端工程师 | 4天 | Phase 2 PDF基础 |
| M11术语库管理器（高级版） | 前端工程师 | 3天 | Phase 2术语库 |
| M12设置中心（高级配置+快捷键系统） | 前端工程师 | 5天 | Phase 1设置中心 |
| **UI设计系统实现（Design Tokens+组件库）** | 前端工程师 | 5天 | Phase 1设置中心 |
| TTS语音朗读集成 | 前端工程师 | 3天 | Phase 2 |
| 输入框实时翻译 | 前端工程师 | 3天 | Phase 1 |
| 暗色模式支持 | 前端工程师 | 2天 | Phase 2渲染 |
| 多语言UI（i18n） | 前端工程师 | 4天 | Phase 1 |
| 无障碍访问优化 | 前端工程师 | 3天 | 全部功能 |
| Phase 4测试与调试 | 全员 | 4天 | 全部模块 |

**Phase 4里程碑交付物**：完整的视频双语字幕、PDF扫描件翻译、TTS语音朗读、多语言UI、完善的快捷键自定义系统、现代化UI组件库。

### 7.7 Phase 5：优化与发布（第19-20周）

| 任务 | 负责人 | 预估工时 | 依赖 |
|------|--------|---------|------|
| 性能优化（启动速度、内存占用） | 全员 | 3天 | Phase 4 |
| 包体积优化（Tree-shaking、代码压缩） | 前端工程师 | 2天 | Phase 4 |
| **Rust壳体积优化（静态链接、strip调试信息）** | 后端工程师 | 2天 | Phase 3 |
| **Rust壳启动时间优化（延迟加载ONNX Runtime）** | 后端工程师 | 2天 | Phase 3 |
| 安全审计（权限最小化、隐私合规） | 安全工程师 | 3天 | Phase 4 |
| 兼容性测试（Chrome/Edge/Firefox） | 测试工程师 | 3天 | Phase 4 |
| 用户文档与帮助页面 | 文档工程师 | 3天 | Phase 4 |
| Chrome Web Store 上架准备 | 运维 | 2天 | 安全审计通过 |
| Microsoft Edge Add-ons 上架 | 运维 | 2天 | Chrome上架 |
| Firefox Add-ons 上架 | 运维 | 2天 | Chrome上架 |
| 正式发布与监控搭建 | 运维 | 2天 | 上架完成 |

**Phase 5里程碑交付物**：正式版发布至Chrome Web Store、Edge Add-ons、Firefox Add-ons，具备完整的用户文档和监控体系。

### 7.8 Phase 6：学习模块（第21-26周）

| 任务 | 负责人 | 预估工时 | 依赖 |
|------|--------|---------|------|
| M13 历史记录服务（基础版） | 前端工程师 | 4天 | Phase 2 |
| M13 历史记录自动入池逻辑 | 前端工程师 | 3天 | 基础版 |
| M14 生词本服务（基础版） | 前端工程师 | 5天 | Phase 2 |
| M14 手动添加/过滤规则 | 前端工程师 | 3天 | 基础版 |
| M15 复习引擎（SM-2 算法） | 前端工程师 | 5天 | 生词本服务 |
| M15 复习队列管理 | 前端工程师 | 3天 | SM-2算法 |
| M15 掌握度衰减与毕业逻辑 | 前端工程师 | 2天 | 复习队列 |
| M16 导出服务（JSON/CSV） | 前端工程师 | 3天 | Phase 2 |
| M16 导出服务（Anki/Markdown/TSV/SRT） | 前端工程师 | 5天 | JSON/CSV |
| M16 导入与验证逻辑 | 前端工程师 | 3天 | 导出服务 |
| 复习面板 UI（闪卡模式） | 前端工程师 | 5天 | 复习引擎 |
| 学习统计仪表盘 | 前端工程师 | 4天 | 复习引擎 |
| 每日学习报告/通知 | 前端工程师 | 3天 | 复习引擎 |
| 增量同步机制 | 前端工程师 | 3天 | 导出服务 |
| 学习模块端到端联调 | 前后端协作 | 5天 | 全部子模块 |
| Phase 6 测试与调试 | 全员 | 5天 | 全部模块 |

**Phase 6里程碑交付物**：完整的翻译→学习闭环——每次翻译自动记录、自动进入复习队列、支持四种复习模式、六种格式导出、跨设备数据迁移。

### 7.9 Phase 7：本地大模型与AI对话界面（第27-34周）

| 任务 | 负责人 | 预估工时 | 依赖 |
|------|--------|---------|------|
| M17 本地大模型服务发现模块 | 前端工程师 | 3天 | Phase 2 |
| M17 Ollama API集成（模型列表/健康检查） | 前端工程师 | 3天 | 服务发现 |
| M17 翻译接口实现（普通翻译+流式翻译） | 前端工程师 | 5天 | API集成 |
| M17 Rust壳端本地LLM客户端 | 后端工程师 | 5天 | Phase 3 Rust壳 |
| M17 本地模型管理UI（设置页） | 前端工程师 | 4天 | 翻译接口 |
| M17 降级策略实现（本地→云端自动切换） | 前端工程师 | 3天 | 翻译接口 |
| M18 AI对话界面基础框架 | 前端工程师 | 5天 | Phase 4 UI系统 |
| M18 消息气泡组件（用户/AI消息渲染） | 前端工程师 | 4天 | 基础框架 |
| M18 流式输出/打字机效果 | 前端工程师 | 3天 | 消息组件 |
| M18 会话管理（创建/切换/删除/搜索） | 前端工程师 | 5天 | 基础框架 |
| M18 引擎切换器组件 | 前端工程师 | 3天 | 会话管理 |
| M18 文件上传与处理（图片/PDF） | 前端工程师 | 5天 | 会话管理 |
| M18 快捷指令系统 | 前端工程师 | 3天 | 消息组件 |
| M18 对话导出功能 | 前端工程师 | 4天 | 会话管理 |
| M18 学习模块集成（对话生词→生词本） | 前端工程师 | 4天 | Phase 6学习模块 |
| M18 深色模式适配 | 前端工程师 | 3天 | 全部组件 |
| M18 端到端联调（对话→引擎→学习模块） | 前后端协作 | 5天 | 全部子模块 |
| Phase 7 测试与调试 | 全员 | 5天 | 全部模块 |

**Phase 7里程碑交付物**：完整的AI对话界面——支持多轮对话、引擎切换、文件上传分析、流式输出、对话历史管理、与学习模块无缝集成。本地大模型引擎接口可用，支持Ollama/LM Studio等本地服务，具备自动降级能力。

---

## 八、技术栈总览

### 8.1 前端（浏览器插件）

| 技术 | 用途 | 版本要求 |
|------|------|---------|
| TypeScript | 主要开发语言 | >= 5.0 |
| Vite | 构建工具 | >= 5.0 |
| Chrome Extension API | 扩展能力 | Manifest V3 |
| Tesseract.js | 浏览器端OCR | >= 5.0 |
| PDF.js | PDF解析 | >= 4.0 |
| IndexedDB | 本地缓存 | - |
| Web Worker | OCR后台线程 | - |
| CSS Variables / Tailwind | 样式管理（Design Tokens） | - |
| Highlight.js | 代码高亮（AI对话界面） | >= 11.0 |
| EventSource / ReadableStream | 流式响应处理 | - |

### 8.2 后端（Rust本地壳程序）

| 技术 | 用途 | 版本要求 |
|------|------|---------|
| **Rust 2021** | **主要开发语言** | **>= 1.70** |
| **Cargo** | **构建系统 + 包管理** | **>= 1.70** |
| **onnxruntime** | **PP-OCRv6 ONNX模型推理** | **>= 1.16** |
| **winapi / windows** | **Win32 API绑定（截图/热键/窗口）** | **最新** |
| **winit** | **跨平台窗口管理（浮窗绘制）** | **>= 0.29** |
| **serde + serde_json** | **JSON序列化/反序列化** | **>= 1.0** |
| **tokio** | **异步运行时（NM通信）** | **>= 1.0** |
| **clap** | **命令行参数解析** | **>= 4.0** |
| **anyhow + thiserror** | **错误处理** | **最新** |
| **reqwest** | **HTTP客户端（调用本地Ollama等）** | **>= 0.11** |
| **tokio** | **异步运行时（HTTP流式响应）** | **>= 1.0** |

### 8.3 OCR引擎对比

| 引擎 | 类型 | 速度 | 精度 | 离线 | 体积 | 推荐场景 |
|------|------|------|------|------|------|---------|
| **PP-OCRv6 Tiny** | 本地ONNX | ~100ms | 84.1%检测 | 是 | ~6MB | 默认推荐，快速预览 |
| **PP-OCRv6 Small** | 本地ONNX | ~500ms | 86.2%检测 | 是 | ~30MB | 日常截图翻译 |
| **PP-OCRv6 Medium** | 本地ONNX | ~1.4s | 最高精度 | 是 | ~133MB | 医学文档/复杂版面 |
| **SiliconFlow云端** | 云端API | 103-121s | 有幻觉 | 否 | 无 | 本地不可用时兜底 |

### 8.4 Rust壳 vs Python壳 性能对比

| 指标 | Python壳（旧） | Rust壳（新） | 提升 |
|------|---------------|-------------|------|
| 二进制体积 | ~50MB（含Python解释器） | ~100-200KB | **250-500倍** |
| 启动时间 | 1-2秒 | <50ms | **20-40倍** |
| 截图→OCR延迟 | ~500ms | <100ms | **5倍** |
| 内存占用 | ~200MB | ~20-30MB | **7-10倍** |
| 并发能力 | 单线程（GIL锁） | 多线程无锁 | **质的飞跃** |
| 类型安全 | 动态类型 | 编译期类型检查 | **零空指针** |

### 8.5 翻译引擎

| 引擎 | 类型 | 费用 | 特点 |
|------|------|------|------|
| Edge Translator API | 本地离线 | 免费 | 零延迟、隐私安全、145+语言 |
| Google Translate | 云端 | 免费(限量) | 通用性强、语言覆盖广 |
| Bing Translate | 云端 | 免费 | 微软背书、中文优化 |
| SiliconFlow | 云端 | 免费(带key) | 高质量、国内直连、Qwen模型 |
| MyMemory | 云端 | 免费(免key) | 国内直连、匿名5000字符/天 |
| OpenAI GPT | 云端 | 按量付费 | 长文本/专业领域强 |
| Claude | 云端 | 按量付费 | 上下文理解强 |
| Gemini | 云端 | 按量付费 | Google多模态，代码/图像理解强 |
| DeepL | 云端 | 免费(限量)/付费 | 专业翻译质量高，欧洲语言优势 |
| **Ollama(本地)** | **本地** | **免费** | **完全离线、隐私安全、Qwen/Llama/ChatGLM等** |

### 8.6 开发工具

| 工具 | 用途 |
|------|------|
| Git + GitHub | 版本管理 |
| GitHub Actions | CI/CD |
| ESLint + Prettier | 前端代码规范 |
| **rustfmt + clippy** | **Rust代码规范** |
| Vitest | 单元测试 |
| Playwright | E2E测试 |
| VS Code | 前端开发 |
| **VS Code + rust-analyzer** | **Rust开发（无需Visual Studio）** |
| Wireshark | 网络调试 |
| **Ollama** | **本地大模型运行服务** |
| **LM Studio** | **本地大模型GUI管理工具** |

---

## 九、风险与应对

### 9.1 技术风险

| 风险 | 影响 | 概率 | 应对措施 |
|------|------|------|---------|
| **PP-OCRv6 ONNX Runtime Rust绑定稳定性** | OCR功能不可用 | 中 | 保留SiliconFlow云端兜底；监控onnxruntime crate更新 |
| Tesseract.js OCR准确率不足 | 用户体验差 | 中 | 集成PP-OCRv6作为主力；图像预处理增强 |
| Edge Translator API稳定性 | 离线翻译不可用 | 低 | 自动降级到云端引擎 |
| Native Messaging兼容性 | 部分浏览器不支持 | 中 | Firefox/Edge各有差异，需分别适配测试 |
| **Rust壳被杀毒软件误报** | 用户安装失败 | 中 | 代码签名证书；提供开源源码供审计 |
| 翻译API限流 | 高频使用受限 | 高 | 请求队列+指数退避；多引擎负载均衡 |
| Manifest V3迁移 | 扩展API变更 | 中 | 紧跟Chrome更新；提前适配V3 |
| **Rust编译时间** | 开发效率影响 | 低 | CI缓存依赖；增量编译默认开启 |

### 9.2 合规风险

| 风险 | 影响 | 应对措施 |
|------|------|---------|
| 翻译内容隐私 | 用户数据泄露 | 默认本地OCR；云端翻译可选；明确隐私政策 |
| 版权合规 | 翻译文本版权 | 不存储用户翻译内容；引用翻译引擎服务条款 |
| 商店审核 | 上架被拒 | 权限最小化声明；提供清晰的功能说明 |

### 9.3 运维风险

| 风险 | 影响 | 应对措施 |
|------|------|---------|
| 翻译API变更 | 功能中断 | 抽象引擎接口；快速适配新API |
| 浏览器更新 | 扩展不兼容 | 自动化测试覆盖主流浏览器版本 |
| 用户反馈处理 | 口碑影响 | 建立反馈渠道；定期发布更新 |
| **ONNX Runtime版本兼容性** | 模型推理失败 | 锁定ONNX Runtime版本；模型格式版本声明 |

---

## 十、项目目录结构

```
screen-translator/
|-- browser-extension/          # 浏览器插件（TypeScript）
|   |-- src/
|   |   |-- background/         # Service Worker（后台脚本）
|   |   |   |-- engine-router.ts    # 翻译引擎路由器
|   |   |   |-- native-bridge.ts    # Native Messaging桥
|   |   |   |-- cache.ts            # 请求缓存
|   |   |   |-- hotkey-manager.ts   # 快捷键管理器
|   |   |-- content/            # Content Script
|   |   |   |-- dom-capture.ts      # DOM内容采集
|   |   |   |-- hover-translator.ts # 悬停翻译
|   |   |   |-- renderer.ts         # 结果渲染
|   |   |   |-- ui-components.ts    # UI组件（Design Tokens）
|   |   |   |-- pdf-translator.ts   # PDF翻译
|   |   |   |-- video-subtitles.ts  # 视频字幕
|   |   |-- worker/             # Web Worker
|   |   |   |-- ocr-worker.ts       # Tesseract.js OCR
|   |   |-- popup/              # 弹窗页面
|   |   |   |-- popup.html
|   |   |   |-- popup.ts
|   |   |   |-- popup.css         # 样式（Design Tokens）
|   |   |-- options/            # 选项页面
|   |   |   |-- options.html
|   |   |   |-- options.ts
|   |   |   |-- options.css       # 样式（Design Tokens）
|   |   |-- types/              # TypeScript类型定义
|   |   |   |-- engine.ts
|   |   |   |-- message.ts
|   |   |   |-- config.ts
|   |   |   |-- hotkey.ts         # 快捷键类型
|   |   |   |-- ui.ts             # UI类型
|   |   |-- utils/              # 公共工具函数
|   |       |-- language.ts
|   |       |-- debounce.ts
|   |       |-- storage.ts
|   |-- public/                 # 静态资源
|   |   |-- icons/              # 扩展图标
|   |-- manifest.json           # Manifest V3配置
|   |-- vite.config.ts
|   |-- package.json

|-- learning-module/              # 学习模块（历史记录 + 生词本 + 复习 + 导出）
|   |-- src/
|   |   |-- history/              # 历史记录服务
|   |   |   |-- history-service.ts
|   |   |   |-- history-store.ts
|   |   |   |-- history-model.ts
|   |   |   |-- history-filter.ts
|   |   |-- vocabulary/           # 生词本服务
|   |   |   |-- vocab-service.ts
|   |   |   |-- vocab-store.ts
|   |   |   |-- vocab-model.ts
|   |   |   |-- vocab-merge.ts
|   |   |-- review/               # 复习引擎
|   |   |   |-- review-engine.ts
|   |   |   |-- sm2-algorithm.ts
|   |   |   |-- review-scheduler.ts
|   |   |   |-- review-queue.ts
|   |   |   |-- decay.ts
|   |   |   |-- graduation.ts
|   |   |-- export/               # 导出服务
|   |   |   |-- export-service.ts
|   |   |   |-- export-json.ts
|   |   |   |-- export-csv.ts
|   |   |   |-- export-anki.ts
|   |   |   |-- export-md.ts
|   |   |   |-- export-tsv.ts
|   |   |   |-- export-srt.ts
|   |   |   |-- import.ts
|   |   |   |-- validator.ts
|   |   |-- ui/                   # 学习模块 UI 组件
|   |   |   |-- review-panel.ts
|   |   |   |-- vocab-manager.ts
|   |   |   |-- stats-dashboard.ts
|   |   |   |-- export-dialog.ts
|   |   |-- types/                # 类型定义
|   |   |   |-- learning.ts
|   |   |   |-- export.ts
|   |   |-- utils/                # 工具函数
|   |       |-- date-formatter.ts
|   |       |-- notification.ts
|   |       |-- download.ts

|-- local-llm/                  # 本地大模型引擎接口（v1.3新增）
|   |-- src/
|   |   |-- discovery/          # 服务发现
|   |   |   |-- service-discover.ts   # 本地服务自动探测
|   |   |   |-- ollama-client.ts      # Ollama API客户端
|   |   |   |-- lmstudio-client.ts    # LM Studio API客户端
|   |   |   |-- textgen-client.ts     # text-generation-webui客户端
|   |   |-- models/               # 模型管理
|   |   |   |-- model-list.ts       # 模型列表获取
|   |   |   |-- model-switcher.ts   # 模型切换
|   |   |   |-- model-cache.ts      # 模型信息缓存
|   |   |-- translation/          # 翻译功能
|   |   |   |-- llm-translator.ts   # 本地LLM翻译主类
|   |   |   |-- stream-handler.ts   # 流式响应处理
|   |   |   |-- batch-translate.ts  # 批量翻译
|   |   |   |-- prompt-templates.ts # 翻译prompt模板
|   |   |-- chat/                 # 聊天功能
|   |   |   |-- llm-chat.ts         # 本地LLM聊天
|   |   |   |-- context-manager.ts  # 上下文窗口管理
|   |   |   |-- message-formatter.ts # 消息格式化
|   |   |-- config/               # 配置管理
|   |   |   |-- llm-config.ts       # 本地LLM配置
|   |   |   |-- fallback.ts         # 降级策略
|   |   |-- types/                # 类型定义
|   |   |   |-- llm-service.ts
|   |   |   |-- ollama.ts
|   |   |   |-- chat.ts
|   |-- tests/
|       |-- service-discover.test.ts
|       |-- ollama-client.test.ts
|       |-- stream-handler.test.ts

|-- ai-chat/                      # AI对话界面（v1.3新增）
|   |-- src/
|   |   |-- session/              # 会话管理
|   |   |   |-- session-manager.ts  # 会话CRUD操作
|   |   |   |-- session-store.ts    # IndexedDB存储
|   |   |   |-- session-search.ts   # 会话搜索
|   |   |-- messages/             # 消息管理
|   |   |   |-- message-manager.ts  # 消息CRUD操作
|   |   |   |-- message-renderer.ts # 消息渲染(气泡样式)
|   |   |   |-- stream-reader.ts    # 流式读取器
|   |   |   |-- typing-effect.ts    # 打字机效果
|   |   |-- components/           # UI组件
|   |   |   |-- chat-input.ts       # 输入框组件
|   |   |   |-- message-bubble.ts   # 消息气泡组件
|   |   |   |-- engine-switcher.ts  # 引擎选择器
|   |   |   |-- quick-commands.ts   # 快捷指令栏
|   |   |   |-- file-uploader.ts    # 文件上传组件
|   |   |   |-- loading-indicator.ts # 加载指示器
|   |   |   |-- chat-panel.ts       # 对话面板主组件
|   |   |-- files/                # 文件处理
|   |   |   |-- file-processor.ts   # 文件处理主类
|   |   |   |-- image-ocr.ts        # 图片OCR
|   |   |   |-- pdf-reader.ts       # PDF读取
|   |   |   |-- text-reader.ts      # 文本文件读取
|   |   |-- export/               # 对话导出
|   |   |   |-- chat-export.ts      # 导出主类
|   |   |   |-- export-md.ts        # Markdown导出
|   |   |   |-- export-pdf.ts       # PDF导出
|   |   |   |-- export-text.ts      # 纯文本导出
|   |   |-- learning/             # 学习模块集成
|   |   |   |-- vocab-saver.ts      # 对话生词保存
|   |   |   |-- learning-stats.ts   # 学习统计
|   |   |-- utils/                # 工具函数
|   |   |   |-- markdown-render.ts  # Markdown渲染
|   |   |   |-- code-highlight.ts   # 代码高亮
|   |   |   |-- theme-manager.ts    # 主题管理
|   |   |-- types/                # 类型定义
|   |   |   |-- ai-chat.ts
|   |   |   |-- file-attachment.ts
|   |   |-- styles/               # 样式
|   |       |-- chat-theme.css      # 主题变量
|   |       |-- chat-components.css # 组件样式
|   |-- tests/
|       |-- session-manager.test.ts
|       |-- message-renderer.test.ts
|       |-- stream-reader.test.ts

|-- native-host/                # Rust本地壳程序
|   |-- src/
|   |   |-- main.rs               # 入口（多实例管理+模式判断）
|   |   |-- screenshot.rs         # 截图模块（DXGI优先+BitBlt兜底）
|   |   |-- ocr.rs                # OCR引擎调度（PP-OCRv6 + SiliconFlow兜底）
|   |   |-- ocr_models.rs         # 三档模型管理（Tiny/Small/Medium）
|   |   |-- draw.rs               # 浮窗绘制（winit+GDI）
|   |   |-- ipc.rs                # Native Messaging通信（stdin/stdout）
|   |   |-- hotkey.rs             # 全局热键管理（RegisterHotKey）
|   |   |-- config.rs             # 配置管理（serde序列化）
|   |   |-- instance.rs           # 单实例保护+多实例名册
|   |   |-- error.rs              # 错误处理（thiserror）
|   |   |-- types.rs              # 共享类型定义
|   |   |-- llm_client.rs         # 本地大模型HTTP客户端（reqwest）[v1.3新增]
|   |   |-- llm_translate.rs      # 本地LLM翻译调度 [v1.3新增]
|   |-- Cargo.toml                # Rust依赖配置
|   |-- Cargo.lock
|   |-- models/                   # PP-OCRv6模型文件
|   |   |-- ocr/
|   |       |-- v6_tiny/          # Tiny档（6.6MB，随项目内置）
|   |       |-- v6_small/         # Small档（用户自行下载）
|   |       |-- v6_medium/        # Medium档（用户自行下载）
|   |-- scripts/
|   |   |-- install.bat           # Windows安装脚本
|   |   |-- uninstall.bat         # Windows卸载脚本
|   |   |-- install_deps.bat      # 依赖安装（ONNX Runtime等）

|-- docs/                       # 文档
|   |-- api.md                  # 接口文档
|   |-- setup.md                # 搭建指南
|   |-- user-guide.md           # 用户手册
|   |-- ui-guide.md             # UI设计规范
|-- scripts/                    # 构建/部署脚本
|   |-- build-all.sh
|   |-- build-rust.sh
|   |-- package-extension.sh
|   |-- sign-binary.ps1
|-- .github/
|   |-- workflows/
|   |   |-- ci.yml              # CI流水线（含Rust + TS）
|   |   |-- release.yml         # 发布流水线
|-- .eslintrc.json
|-- .prettierrc
|-- README.md
|-- package.json                # 根包管理
```

---

## 十一、验收标准

### 12.1 功能验收

| 编号 | 功能点 | 验收标准 |
|------|--------|---------|
| F1 | 网页悬停翻译 | 鼠标悬停文本0.5秒内显示翻译Tooltip |
| F2 | 全页翻译 | 一键翻译整页，支持双语对照/仅译文切换 |
| F3 | 图片OCR翻译 | 截图后自动OCR识别并翻译，准确率>=85% |
| F4 | 任意界面翻译 | 全局快捷键触发，Rust壳截图OCR翻译后浮窗显示 |
| F5 | 多引擎切换 | 支持6+引擎，智能路由自动选择最优 |
| F6 | 离线翻译 | Edge引擎可用时完全离线翻译 |
| F7 | 视频字幕 | YouTube视频双语字幕实时叠加 |
| F8 | PDF翻译 | PDF文档双语对照显示，保留排版 |
| F9 | 术语库 | 自定义术语正确匹配并优先使用 |
| F10 | **快捷键自定义** | **用户可自由录入/修改所有快捷键，冲突自动回退，即时生效** |
| F11 | 翻译历史记录 | 每次翻译自动记录，支持按领域/日期筛选，记录含来源溯源 |
| F12 | 生词本管理 | 自动采集+手动添加，支持掌握度追踪与毕业归档 |
| F13 | 间隔重复复习 | SM-2算法调度复习，支持四种复习模式（英中/中英/填空/听写） |
| F14 | 学习数据导出 | 支持JSON/CSV/Anki/Markdown/TSV/SRT六种格式导出，保留学习元数据 |
| F15 | 跨设备数据迁移 | 导出文件可完整恢复学习状态，支持增量同步 |
| F16 | **现代UI设计** | **Design Tokens统一、暗色模式、按钮交互反馈、动效符合规范** |
| F17 | **本地大模型翻译引擎** | **可自动发现本地Ollama/LM Studio服务，支持Qwen/Llama/ChatGLM等模型切换，翻译质量可接受，本地不可用时自动降级到云端引擎** |
| F18 | **AI对话界面** | **提供类ChatGPT对话式UI，支持多轮对话上下文、引擎切换、文件上传分析、流式打字机效果、对话历史管理、深色模式** |
| F19 | **对话与学习模块集成** | **对话中用户标记的词汇自动加入生词本，对话历史可导出，对话数据统计可用** |
| F20 | **智能路由增强** | **根据文本类型/长度/网络状况/成本自动选择最优引擎（含本地大模型），路由决策准确率高，降级策略可靠** |

### 12.2 性能验收

| 指标 | 目标值 | 测试条件 |
|------|--------|---------|
| 插件启动时间 | < 2秒 | 冷启动 |
| 悬停翻译延迟 | < 500ms | 网络正常 |
| **Rust壳启动时间** | **< 50ms** | **冷启动** |
| **截图→OCR→译文（本地）** | **< 100ms** | **Tiny模型，本地OCR** |
| 截图→OCR→译文（云端兜底） | < 3秒 | SiliconFlow OCR |
| **Rust壳二进制体积** | **< 200KB** | **release构建+strip** |
| **Rust壳内存占用** | **< 30MB** | **正常运行** |
| 插件包体积 | < 1MB | 生产构建 |
| 内存占用 | < 50MB | 正常使用场景 |
| OCR准确率 | >= 90% | 清晰文本 |
| 翻译准确率 | >= 95% | 常用语言对 |

### 12.3 兼容性验收

| 浏览器 | 版本要求 | 状态 |
|--------|---------|------|
| Chrome | >= 120 | 必须支持 |
| Edge | >= 120 | 必须支持 |
| Firefox | >= 120 | 应该支持 |
| Opera | >= 105 | 最好支持 |

---


## 十二、开发策略：复制 vs AI写 vs 自研

### 13.1 策略总览

本项目采用**三种策略混合使用**的开发模式，根据模块复杂度、技术栈匹配度、代码复用价值三个维度决定每个模块的实现方式：

| 策略 | 适用场景 | 预估效率提升 | 代码质量保障 |
|------|---------|-------------|-------------|
| **直接复制开源代码** | 技术栈完全一致、代码经过验证、模块边界清晰 | 省3-4周 | 社区验证，bug少 |
| **AI从零写** | 小模块、一次性代码、需求高度定制化 | 省60-80%时间 | 需逐行审查 |
| **复制骨架+AI填充** | 架构参考开源、细节让AI实现 | 省50%时间 | 架构可控，细节AI辅助 |
| **完全自研** | 项目独创功能、无参考项目 | 基准速度 | 完全自主可控 |

**核心原则**：成熟的轮子直接复制（省3-4周），小模块让AI写（省60-80%时间），核心架构复制骨架让AI填充（省50%时间但保证质量）。算法和架构决策你自己定，重复性的代码生成和文档编写全部交给AI。AI是执行者，你是架构师和审查员。

### 13.2 参考开源项目清单

| 优先级 | 项目 | GitHub | 技术栈 | 可复用核心价值 |
|--------|------|--------|--------|---------------|
| 必下 | Prism | prism-app/prism | Rust + Tauri | Rust壳架构、AI大模型接口、SQLite存储 |
| 必下 | 飞舟OCR | docvelo-ai/velocr | Rust + Tauri + MNN | PP-OCRv6三档模型集成、MNN桥接层 |
| 必下 | STranslate | STranslate/STranslate | C# WPF | 多引擎路由设计、划词翻译、插件系统 |
| 强烈建议 | Pot Desktop | pot-app/pot-desktop | TypeScript + Tauri | 插件扩展系统、剪贴板监听 |
| 强烈建议 | Crow Translate | Shatur95/Crow-Translate | C++17 + Qt 6 | 全局热键钩子、内存优化 |
| 强烈建议 | Translumo | Translumo/Translumo | C# .NET | 多OCR引擎择优机制 |
| 按需下载 | Argos Translate | argosopentech/argos-translate | Python | 离线翻译降级方案 |
| 按需下载 | BabelDOC | BabelDOC/BabelDOC | Python | PDF排版保持技术 |

> **实际下载核实结论（2026-09-25）**：清单中部分技术栈描述与仓库实况不符，已纠正；仓库已下载到 `rust-references/`，详细分析见 `rust-references/README.md`、`plan_ocr_langdetect.md`、`engines_reference.md`。**协议红线**：各仓库许可证多为 GPL/MIT/AGPL，仅参考思路与 API 结构，禁止直接复制代码。

| 项目 | 计划标注 | 实际核实 | 下载状态 | 备注 |
|------|---------|---------|---------|------|
| Pot Desktop | TypeScript + Tauri | **Rust + Tauri**（含 `src-tauri/src` Rust 后端） | ✅ 已下载 | 技术栈纠正；Rust 后端与本项目最贴近，重点参考 `system_ocr.rs`/`lang_detect.rs` |
| 飞舟OCR (velocr) | Rust + Tauri + MNN | **Python**（文档级 OCR 流水线） | ✅ 已下载 | 技术栈严重不符（非 Rust/非 MNN）；参考其 OCR 布局/阅读顺序思路 |
| STranslate | C# WPF | C# WPF（插件式） | ✅ 已下载 | 一致；引擎清单最全（OCR 7 + 翻译 11） |
| Crow Translate | C++17 + Qt 6 | C++ / Qt | ✅ 已下载 | 一致；参考抓屏选区 + 翻译抽象层 |
| Prism | Rust + Tauri | — | ❌ 地址 404（`prism-app/prism` 不存在） | 未找到正确仓库，暂缺 |
| Translumo | C# .NET | — | ❌ 克隆失败（空 `.git`） | 代理下克隆失败，需用国内镜像重试 |
| Argos / BabelDOC | Python | — | ❌ 未下载 | 按需，未纳入本轮 |

### 13.3 逐模块开发策略矩阵

#### 模块 M1 — 用户交互管理器

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **直接复制** | Pot Desktop | chrome.storage管理、popup/options页面结构 | 功能名/图标替换 |
| **AI写** | — | — | 项目特定交互逻辑 |

**预估**：复制60% + AI写40% = 约2天完成

#### 模块 M2 — DOM内容采集器

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **直接复制** | STranslate | DOM遍历逻辑、MutationObserver监听、文本清洗 | 过滤规则适配项目需求 |
| **AI写** | — | — | 长文本分块策略 |

**预估**：复制70% + AI写30% = 约3天完成

#### 模块 M3 — 悬停翻译器

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **直接复制** | STranslate | mousemove/mouseup事件监听、getSelection捕获、防抖处理 | Tooltip定位逻辑适配 |
| **AI写** | — | — | 特定场景优化 |

**预估**：复制80% + AI写20% = 约2天完成

#### 模块 M4 — 屏幕截图OCR引擎

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **直接复制** | Prism | Canvas截图API、Tesseract.js集成 | 语言包管理适配 |
| **参考重写** | STranslate | 离线模型下载管理流程 | Rust端实现 |

**预估**：复制50% + 参考重写50% = 约5天完成

#### 模块 M5 — Native Messaging通信桥

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **直接复制** | Pot Desktop | chrome.runtime.connectNative、port.postMessage/onMessage | 消息schema适配 |
| **直接复制** | 飞舟OCR | Rust端stdin/stdout JSON序列化 | 协议字段适配 |

**预估**：复制90% + AI写10% = 约2天完成

#### 模块 M6 — 本地壳程序（Rust）

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **直接复制** | Prism | Tauri项目结构、main.rs/lib.rs入口、tauri.conf.json、capabilities权限声明 | 项目名/配置微调 |
| **直接复制** | Pot Desktop | src-tauri/src/下模块划分(hotkey.rs/screenshot.rs/clipboard.rs/tray.rs/config.rs/server.rs/window.rs) | 功能适配 |
| **直接复制** | 飞舟OCR | Rust HTTP Proxy实现(reqwest绕过CORS)、Per-provider配置隔离 | 引擎适配 |
| **直接复制** | 飞舟OCR | MNN推理桥接层(Rust FFI调用C++ MNN)、PP-OCRv6三档模型加载逻辑 | ONNX Runtime适配 |
| **参考重写** | Crow Translate | 全局键盘钩子机制(WinAPI RegisterHotKey) | Rust实现 |
| **参考重写** | STranslate | 离线模型下载/管理流程 | Rust实现 |

**预估**：复制60% + 参考重写30% + AI写10% = 约4周完成

#### 模块 M7 — 翻译引擎路由器

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **参考重写** | STranslate | 多引擎抽象接口设计(TranslationEngine trait)、19种引擎适配器接口规范、三级调度策略 | Rust重写(约400行) |
| **参考重写** | Pot Desktop | 20+翻译引擎HTTP API调用模式、统一参数签名、结果缓存策略 | Rust重写 |
| **参考重写** | Crow Translate | QOnlineTranslator统一引擎抽象层设计思路 | 设计思路参考 |
| **参考重写** | Translumo | 多引擎负载均衡、TranslatorFactory动态选择模式 | 设计思路参考 |
| **AI写** | — | — | 项目特定路由策略 |

**预估**：参考设计 + AI写 = 约2周完成（接口设计1:1迁移，Rust重写约400行）

#### 模块 M8 — 结果渲染引擎

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **参考设计** | STranslate | 悬浮窗翻译结果UI交互设计、设置页面布局 | React重写 |
| **参考设计** | Translumo | 实时翻译悬浮窗OverlayWindow交互设计 | React重写 |
| **AI写** | — | — | Design Tokens定义后批量生成CSS |

**预估**：参考设计 + AI写 = 约3天完成

#### 模块 M9 — 视频字幕模块

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **参考设计** | STranslate | 批量文件翻译处理流程 | YouTube/Netflix API适配 |
| **AI写** | — | — | 具体平台集成 |

**预估**：参考设计 + AI写 = 约4天完成

#### 模块 M10 — PDF翻译模块

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **直接复制** | Prism | PDF.js文本层解析基础 | 排版保留逻辑 |
| **参考设计** | BabelDOC | PDF智能布局重建技术、表格/公式处理 | Rust/TS实现 |

**预估**：复制40% + 参考设计60% = 约5天完成

#### 模块 M11 — 术语库管理器

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **参考设计** | Pot Desktop | 术语库版本更新机制 | IndexedDB实现 |
| **AI写** | — | — | 匹配算法 |

**预估**：参考设计 + AI写 = 约3天完成

#### 模块 M12 — 设置与配置中心

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **直接复制** | Pot Desktop | chrome.storage.sync管理、配置导入导出 | UI适配 |
| **AI写** | — | — | 快捷键配置文件(JSON格式)、项目特定配置项 |

**预估**：复制60% + AI写40% = 约3天完成

#### 模块 M13 — 历史记录服务（学习模块）

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **参考设计** | Pot Desktop | Anki导出工作流、生词保存流程 | SM-2算法核心实现 |
| **AI写** | — | — | 掌握度追踪、复习调度逻辑 |

**预估**：参考设计 + AI写 = 约4天完成（完全自研为主，这是项目独创功能）

#### 模块 M14 — 生词本服务（学习模块）

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **参考设计** | Pot Desktop | Anki导出流程 | 间隔重复算法核心 |
| **AI写** | — | — | 自动采集/过滤规则/掌握度管理 |

**预估**：参考设计 + AI写 = 约5天完成（完全自研为主）

#### 模块 M15 — 复习引擎（学习模块）

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **完全自研** | — | — | SM-2算法实现、掌握度衰减、复习队列管理 |

**预估**：完全自研 = 约5天完成（项目独创核心功能）

#### 模块 M16 — 导出服务（学习模块）

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **AI写** | — | — | 模式固定的格式转换代码(JSON->CSV、JSON->Anki) |
| **参考设计** | Pot Desktop | Anki导出工作流 | 具体实现 |

**预估**：AI写 = 约3天完成（模式固定，AI擅长）

#### 模块 M17 — 本地大模型引擎接口

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **直接复制** | Prism | AI大模型接口对接(OpenAI/腾讯混元/Qwen)、流式输出实现、SQLite存储对话记录 | 适配本地服务 |
| **直接复制** | 飞舟OCR | Ollama/LM Studio本地大模型对接、OpenAI Compatible接口适配 | 项目集成 |

**预估**：复制80% + AI写20% = 约2周完成

#### 模块 M18 — AI对话界面

| 策略 | 来源 | 可复用内容 | 需重写内容 |
|------|------|-----------|-----------|
| **直接复制** | Prism | 对话式UI基础框架、流式输出 | 气泡样式适配 |
| **参考设计** | STranslate | 设置页面布局、多引擎并行翻译界面 | React重写 |
| **AI写** | — | — | Design Tokens定义后批量生成CSS/组件样式 |

**预估**：复制50% + 参考设计30% + AI写20% = 约3周完成

### 13.4 代码复用总表

| 模块 | 直接复制 | 参考重写 | 参考设计 | 完全自研/AI写 | 预估节省时间 |
|------|---------|---------|---------|--------------|-------------|
| M1 用户交互管理器 | Prism + Pot Desktop | — | — | AI写 | ~1周 |
| M2 DOM内容采集器 | STranslate | — | — | AI写 | ~2天 |
| M3 悬停翻译器 | STranslate | — | — | AI写 | ~2天 |
| M4 屏幕截图OCR | Prism | STranslate | — | AI写 | ~3天 |
| M5 Native Messaging桥 | Pot Desktop + 飞舟OCR | — | — | AI写 | ~1天 |
| M6 Rust壳程序 | Prism + Pot Desktop + 飞舟OCR | Crow + STranslate | — | AI写 | ~3-4周 |
| M7 翻译引擎路由器 | — | STranslate + Pot Desktop | Crow + Translumo | AI写 | ~1-2周 |
| M8 结果渲染引擎 | — | — | STranslate + Translumo | AI写 | ~2天 |
| M9 视频字幕 | — | — | STranslate | AI写 | ~3天 |
| M10 PDF翻译 | Prism | — | BabelDOC | AI写 | ~3天 |
| M11 术语库管理 | — | — | Pot Desktop | AI写 | ~2天 |
| M12 设置配置中心 | Pot Desktop | — | — | AI写 | ~2天 |
| M13 历史记录服务 | — | — | Pot Desktop | AI写 | ~3天 |
| M14 生词本服务 | — | — | Pot Desktop | AI写 | ~4天 |
| M15 复习引擎 | — | — | — | 完全自研 | 基准 |
| M16 导出服务 | — | — | Pot Desktop | AI写 | ~2天 |
| M17 本地大模型接口 | Prism + 飞舟OCR | — | — | AI写 | ~1-2周 |
| M18 AI对话界面 | Prism | — | STranslate | AI写 | ~2-3周 |

### 13.5 AI辅助开发工作流

#### 第一步：用 WorkBuddy 生成项目骨架文档

- 让 WorkBuddy 根据技术规格文档，生成每个文件夹的 README.md
- 生成 UI 设计规范文档（按钮/面板/弹窗的 CSS 变量和 HTML 原型）
- 生成快捷键配置 JSON 模板
- 生成测试用例清单

#### 第二步：用 Trae CN 写核心代码

- 打开 Trae CN，用 Builder 模式输入需求描述，让它生成 Rust 代码骨架
- 逐模块实现：Rust壳 -> OCR集成 -> 翻译路由 -> 本地大模型 -> AI对话界面 -> 学习模块
- 每写完一个模块，让 Trae CN 的 Chat 模式帮你 review 和补单测

#### 第三步：用 WorkBuddy 生成配套材料

- 让 WorkBuddy 根据 Trae CN 写好的代码，自动生成 API 文档
- 生成用户手册/使用说明
- 生成项目周报和进度报告

### 13.6 AI写代码质量保障

Karpathy 七步法（适用于所有AI生成代码）：

1. **上下文拉满**：把项目目录结构、接口定义、依赖关系完整喂给AI
2. **策略先行**：先让AI输出设计文档/接口定义，确认后再写实现代码
3. **获取初稿**：让AI生成代码初稿
4. **逐行审查**：逐行审查AI生成的代码，重点关注边界条件和错误处理
5. **测试验证**：编写单元测试验证核心逻辑
6. **提交**：通过审查后提交
7. **循环**：重复以上步骤

**关键提醒**：

- AI生成的代码表面完整，但可能包含细微逻辑错误，排查时间远超手写
- AI不了解项目上下文，会重新实现已有功能（实测：不喂上下文AI写1800行，喂了上下文只写400行）
- AI倾向于"新增"而非"复用"，导致代码重复率从3.3%飙升到7.1%
- **正确姿势**：不是"复制粘贴"，而是"AI写，你审"。AI是执行者，你是架构师和审查员

### 13.7 工具分工总结

| 工作类型 | 工具 | 适用场景 |
|---------|------|---------|
| **写代码** | Trae CN | 核心代码、算法实现、系统编程 |
| **写文档/设计** | WorkBuddy | 技术文档、README、UI设计规范、测试用例 |
| **造轮子（核心）** | 你自己 + Trae CN | 算法和架构决策你自己定 |
| **造轮子（重复）** | Trae CN Builder | UI组件CSS、格式转换代码、配置文件解析 |
| **代码审查** | 你自己 | 所有AI生成的代码必须逐行审查 |

### 13.8 预估总工期

| 策略 | 模块数 | 预估时间 | 说明 |
|------|--------|---------|------|
| 直接复制为主 | M1,M5,M17 | ~3周 | 技术栈匹配度高，改动小 |
| 复制+AI混合 | M2,M3,M4,M6,M8,M10,M12,M18 | ~8-10周 | 架构参考+AI填充 |
| AI写为主 | M7,M9,M11,M13,M14,M16 | ~5-6周 | 设计参考+AI实现 |
| 完全自研 | M15 | ~1周 | 独创核心功能 |
| **合计** | **18个模块** | **约18-20周** | **对比从零开发34周，节省约40-45%** |

---
## 十三、工程落地基线：范围、排期、角色与流水线（v1.5 新增）

> 第十三章解决了"怎么做、谁来写代码、能省多少时间"，本章解决"怎么把代码变成可交付的产品"：范围基线、可判定的里程碑、明确的角色分工、可重复的构建与发布流水线。

### 13.1 范围基线与版本分层

#### 13.1.1 版本列车（Release Train）

| 版本 | 定位 | 目标用户 | 质量标准 | 发布渠道 | 范围原则 |
|------|------|---------|---------|---------|---------|
| **Alpha (v0.x-internal)** | 功能可跑通，界面粗糙 | 开发本人 / 内部 | 主流程可走通，允许崩溃 | 本地构建 / Actions Artifacts | 只做 Must，不做打磨 |
| **Beta (v0.9.x)** | MVP 完整，可用可反馈 | 内测群（10-50人） | 无 P0/P1，P2 已知并登记 | GitHub Release（预发布标记） | Must 全交付 + 部分 Should |
| **RC (v1.0.0-rc.N)** | 发布候选，仅修缺陷 | 早期用户（自愿） | 无 P0/P1，P2 < 5，性能达标 | GitHub Release + 商店 Beta 通道 | 功能冻结，只修不改 |
| **GA (v1.0.x)** | 正式版 | 全部用户 | 通过 14.8 发布准入清单 | Chrome/Edge/Firefox 商店 | Must + Should 全交付 |
| **Post-GA (v1.x)** | 增强与学习模块 | 全部用户 | 每 Sprint 回归通过 | 商店自动更新 | 按 MoSCoW 滚动排期 |

版本号语义化（SemVer）：`主版本.次版本.修订`，破坏性配置变更（含 `winocr_config.json` schema 不兼容）必须升主版本或提供自动迁移。

#### 13.1.2 MVP（v0.9）范围：MoSCoW 分层

| 优先级 | 含义 | 本 MVP 包含的能力 |
|--------|------|------------------|
| **M — Must（必须有）** | 缺了就不发布 | 区域截图翻译（Rust壳：截图→OCR→译文浮窗）；浏览器内划词/悬停翻译；至少 2 个可用翻译引擎（SiliconFlow + MyMemory 免费兜底）；**壳的 GUI 最小可用版（托盘图标与菜单 + 设置窗口的通用/引擎/快捷键三页，见 18.9 的 8a）**；扩展设置页（引擎/键位/语言）；Native Messaging 注册与自愈；托盘退出与暂停；一键自检 |
| **S — Should（应该有）** | 影响体验但不阻断 | 全屏截图翻译；浏览器内全页双语对照；PP-OCRv6 三档模型按需下载；译文浮窗可复制/重译；历史记录；快捷键全量自定义与冲突回退 |
| **C — Could（可以有）** | 有余力再做 | TTS 朗读；术语库基础版；PDF 翻译；导出 JSON/CSV |
| **W — Won't（本期不做）** | 明确排除 | 见 14.1.3 |

#### 13.1.3 本期明确不做（Out of Scope）

| 不做项 | 原因 | 何时再评估 |
|--------|------|-----------|
| 账号体系 / 云同步 | 与"隐私优先、纯本地"定位冲突，且带来巨大合规与运维成本 | 用户量 > 10万 且出现强需求 |
| 移动端 / macOS / Linux 版本 | Windows + Chromium 已覆盖核心场景，跨平台需重写截图与窗口层 | GA 后 6 个月 |
| 自研翻译模型训练 | 成本与周期不可控，云端/本地开源模型已足够 | 永不（除非战略变更） |
| 视频硬字幕烧录 / 视频转写 | 场景窄、实现重 | v2.x |
| 浏览器外"全局实时覆盖"（类似游戏内挂） | 注入第三方进程，杀软误报与合规风险极高 | 永不 |
| 多用户/企业版权限管理 | 当前定位为个人工具 | 有明确商业需求时 |

#### 13.1.4 范围变更控制（Change Control）

```
变更请求（需求/缺陷/技术债）
        |
        v
影响的评估（必答三问）：
  1) 影响哪些 Phase 的哪些任务？
  2) 工期 +几天？是否动到关键路径？
  3) 是否改变 MVP 的 Must 清单？
        |
        +--- Must 变更 / 工期 > 3 天 ----> 记录到风险登记册 + 重新基线（更新 7.x 与 13.2.5）
        |
        +--- Should/Could 变更 ---------> 放入 Backlog，下一个 Sprint 排期
        |
        v
冻结窗口规则：RC 阶段起功能冻结，仅接受 P0/P1 缺陷修复；任何功能变更推迟到下一个次版本
```

#### 13.1.5 指标口径修正（对齐 1.2 节）

1.2 节中"总计 < 2MB"为**纯代码体积**口径，与真实安装体积不一致，易在交付阶段造成预期落差。统一为以下口径：

| 指标 | 口径定义 | 目标值 | 备注 |
|------|---------|--------|------|
| 扩展代码体积 | 打包后 crx/zip | < 1 MB | 与 1.2 一致 |
| Rust 壳可执行体积 | release + strip 后（含静态链接 ONNX Runtime） | < 12 MB | 实测 ~10MB，ONNX Runtime 占大头 |
| OCR 模型体积 | 按需下载，非安装包内置 | tiny 6.6MB / small ~17MB / medium 133MB | 默认 tiny，用户可在设置页切换 |
| **首次安装体积** | 安装包 + tiny 模型 | < 25 MB | 安装包 ~15MB |
| 冷启动到可响应热键 | 进程启动 → 热键注册完成 | < 300ms（不含 OCR 模型加载） | 模型延迟加载 |
| 截图→译文显示（端到端） | 按键 → 浮窗出现 | 本地 OCR+本地翻译 < 1.5s；云端翻译 < 3s | 替代 1.2 中" < 100ms"（该值仅为 IPC 往返，非端到端） |

> 说明：原"截图→译文 < 100ms"属于 IPC 单项指标，作为对外承诺会失真。对外统一使用端到端口径，IPC 指标保留为内部性能项（见 14.5）。

### 13.2 排期工程化：从"任务列表"到"可判定计划"

#### 13.2.1 工时口径与产能假设（必须先统一，否则排期全是幻觉）

| 项 | 约定 |
|----|------|
| 1 人日有效编码时间 | 6 小时（其余为沟通、构建等待、上下文切换） |
| 任务工时含义 | **交付完成工时** = 编码 + 自测 + 联调 + 文档 + 缺陷修复，按编码估算 × 1.6 系数 |
| 并行度假设 | 单人开发时并行度 = 1；前后端协作任务按 1.5 倍计入（等待与对齐成本） |
| 项目缓冲 | 每个 Phase 末尾附加 15% 缓冲；关键路径 Phase（3、5）附加 25% |
| 外部等待不计入工时 | 商店审核（1-7 天）、代码签名证书签发（1-3 天）、模型下载（网络依赖）单列为"等待点" |
| 不可用假设 | 每 10 周含 1 周非项目时间（休假/其他事务） |

#### 13.2.2 关键路径识别

```
Phase0 脚手架 ──> Phase1 DOM/渲染 ──> Phase2 引擎路由 ──┐
                                                        │
Phase0 Rust脚手架 ─> [截图] ─> [PP-OCRv6集成] ─> [浮窗] ─> [热键] ─> 端到端联调  <== 关键路径
                                     │                                    │
                                     └─ 模型下载/转换（外部依赖，等待点） ──┘
                                                                          │
                                                        Phase5 上架审核（外部等待点）
```

**关键路径 = Rust 壳链路（Phase 0 → Phase 3 → Phase 5）**，理由：
1. 技术不确定性最高（ONNX Runtime Rust 绑定、DXGI 截图、全局热键抢占）；
2. 一旦失败会同时作废浏览器外全部场景；
3. 外部依赖（模型下载、杀软误报、代码签名）不可控。

**排期第一原则**：关键路径上的任务优先于浏览器内功能；浏览器内功能（Phase 1/2）即使延期，也不影响壳先跑通 Standalone 模式。

#### 13.2.3 三个必须显式管理的"等待点"

| 等待点 | 预估 | 前置动作 | 超时预案 |
|--------|------|---------|---------|
| 代码签名证书签发 | 1-3 天（OV）/ 1-3 周（EV） | Phase 3 启动时即申请，不等待 | 未获证书前发布"未签名版 + 明确说明 + 开源可审计"，并在 README 提供 SHA256 |
| 应用商店审核 | Chrome 1-3 天 / Edge 1-7 天 / Firefox 1-5 天 | 提前准备隐私政策、权限说明、演示视频 | 被拒则按 15.10 的审核应对清单 48h 内整改重提 |
| OCR 模型下载与校验 | 网络强相关（国内需镜像/代理） | 提供 hf-mirror 与代理配置（README 已有） | 内置 tiny 模型随安装包分发 + 首次运行校验 SHA256 |

#### 13.2.4 里程碑准出 Gate（Definition of Done，可判定）

> 每个 Phase 只有**全部**满足才允许进入下一 Phase；不满足则列缺陷并走 13.1.4 变更控制。

| Phase | 准出条件（Exit Criteria） |
|-------|--------------------------|
| **Phase 0** | ① `cargo build --release` 与扩展构建在干净环境一键成功；② CI 全绿（lint/clippy/test/build）；③ 一次提交可产出可运行的 exe + 可加载的扩展；④ 代码规范文档落库 |
| **Phase 1** | ① 在 ≥ 5 个真实网站（含 SPA）悬停翻译成功；② 双语对照不破坏原页面布局（截图对比通过）；③ 引擎切换可用；④ 单元测试覆盖 DOM 采集与渲染核心分支 ≥ 60% |
| **Phase 2** | ① ≥ 4 个引擎可用且失败可自动降级；② 缓存命中率在重复文本场景 ≥ 80%；③ OCR 在标准测试图集上准确率达标（见 14.5）；④ 无 P0/P1 未修复 |
| **Phase 3** | ① Standalone 模式截图→OCR→浮窗全流程在 ≥ 3 台机器（含不同 DPI/多显示器）跑通；② 热键冲突回退可用；③ 24 小时 soak 无崩溃、内存增长 < 10MB；④ 单实例保护生效；⑤ 杀软误报已处理或已有明确缓解 |
| **Phase 4** | ① 视频字幕在 YouTube/Netflix 各 ≥ 3 个样本可用；② 设置页全量功能可用且键位录入即时生效；③ 暗色模式与 i18n 无缺字；④ 无障碍基本可达（键盘可完成主流程） |
| **Phase 5** | ① 通过 14.8 发布准入清单；② 三端商店已提交或已上架；③ 用户文档与 FAQ 上线；④ 崩溃上报与自检工具可用；⑤ 版本号、升级与回滚路径验证通过 |
| **Phase 8a** | ① 托盘图标与菜单可用（暂停/退出/设置/截图项）；② 设置窗口可完成"改引擎、改键位、改语言对"三件高频操作且即时生效；③ 不需要手工编辑 `winocr_config.json` 即可完成日常配置；④ 自检诊断可一键复制报告 |
| **Phase 6** | ① 翻译→生词→复习闭环可用；② 导出格式可被 Anki 正确导入（实测）；③ 数据量 1 万条时列表与复习无卡顿；④ 历史/生词本窗口（8c）可用 |
| **Phase 7** | ① 本地模型（Ollama）可用且失败可降级到云端；② 流式输出稳定、可中断；③ 对话生词入本闭环可用；④ 长对话（> 50 轮）无内存异常 |

**任务准出（单个任务的 DoD）**：代码合入主干 + 自测通过 + 必要的单元测试 + 更新相关文档/配置说明 + 在目标环境实测一次（不是"编译通过"就算完）。

**任务准入（DoR）**：需求描述清晰 + 接口定义已定（见第六章）+ 依赖已就绪 + 验收标准可判定。

#### 13.2.5 重排后的时间轴（含缓冲与等待点）

| 阶段 | 原计划 | 重排后 | 调整说明 |
|------|--------|--------|---------|
| Phase 0 基础架构 | 第1-2周 | 第1-2周 | 不变；同步启动签名证书申请 |
| **Phase 3 关键路径前置** | 第11-14周 | **第3-8周（提前）** | 关键路径前移，先跑通 Standalone，降低最大不确定性 |
| Phase 1 浏览器内 MVP | 第3-6周 | 第6-10周 | 与壳并行（单人时串行，顺序为 壳先） |
| Phase 2 多引擎与 OCR | 第7-10周 | 第11-14周 | 不变 |
| Phase 4 高级功能 UI | 第15-18周 | 第15-19周 | +1 周缓冲（无障碍与 i18n 常被低估） |
| **Phase 8 壳 GUI** | 无 | **8a 第8-11周 / 8b 第12-14周 / 8d GA前 / 8c 随 Phase 6** | **v1.5 新增**，见第十八章；8a（托盘+设置窗口）为 MVP 必做，优先级高于任何新的浏览器内功能 |
| Phase 5 优化与发布 | 第19-20周 | 第20-23周 | +3 周：含商店审核等待点与 RC 修复窗口 |
| Phase 6 学习模块 | 第21-26周 | 第24-29周 | 顺延 |
| Phase 7 本地大模型与AI对话 | 第27-34周 | 第30-37周 | 顺延 |
| 非项目时间/缓冲 | 无 | 第 12、20、28 周 | 每 10 周预留 1 周 |

### 13.3 角色与 RACI

#### 13.3.1 角色定义与单人团队合并方案

| 角色 | 职责 | 单人/小团队时的合并策略 |
|------|------|----------------------|
| 产品负责人（PO） | 需求优先级、范围裁决、验收 | 由开发者本人兼任，但**必须以书面形式**维护 MVP 清单与 Out of Scope，避免自我膨胀 |
| 架构师 | 技术方案、接口定义、技术风险 | 兼任；关键设计需留 ADR（架构决策记录）一页纸 |
| 前端工程师 | 扩展（TS/MV3）、UI | 兼任 |
| 后端/客户端工程师 | Rust 壳、OCR、GUI | 兼任 |
| 测试工程师 | 用例、回归、兼容性 | 兼任；**最低要求**：14.3 的 E2E 场景矩阵每次发布前跑一遍（可脚本化） |
| 运维/发布 | CI、签名、打包、上架 | 兼任；发布流程必须脚本化，禁止手工拷贝文件 |
| 文档/支持 | README、FAQ、商店文案 | 兼任；用户反馈模板化沉淀到 FAQ |

#### 13.3.2 RACI 矩阵（R=负责，A=批准，C=咨询，I=知会）

| 活动 | PO | 架构 | 前端 | 后端 | 测试 | 运维 |
|------|----|------|------|------|------|------|
| 需求优先级与范围变更 | A/R | C | C | C | I | I |
| 接口定义（第六章变更） | C | A/R | C | C | I | I |
| 扩展功能开发 | C | C | R | I | I | I |
| Rust 壳与 GUI 开发 | C | C | I | R | I | I |
| 测试用例与回归执行 | C | I | C | C | R | I |
| 缺陷分级与修复决策 | A | C | R | R | C | I |
| 构建、签名、打包 | I | I | C | C | I | R |
| 商店上架与发布决策 | A | I | I | I | C | R |
| 安全/隐私合规审查 | A | C | C | C | I | C |
| 用户反馈处理与 FAQ | A | I | C | C | C | C |

#### 13.3.3 决策与升级机制

- **日常决策**：单人兼任时无需会议，但需在 Git 提交/文档中留痕（ADR、CHANGELOG）。
- **升级触发**：任一 P0 缺陷 > 24h 未定位、关键路径任务延期 > 3 天、商店审核被拒 → 必须重新基线并更新 13.2.5 时间轴。
- **风险登记册**（第九章的落地形式）：每条风险必须有 `负责人 + 触发信号 + 预案 + 下次复查日期`，随 Sprint 复盘更新，不能只躺在文档里。

### 13.4 分支、版本与 CI/CD 工程规范

#### 13.4.1 分支模型（Trunk-Based + Release Branch）

| 分支 | 来源 | 生命周期 | 用途 | 保护规则 |
|------|------|---------|------|---------|
| `main` | — | 永久 | 始终可发布的最新代码 | 禁止直接 push；PR 需 CI 全绿 + 1 次自检确认 |
| `feat/xxx` | main | 合并后删除 | 功能开发 | 提交需通过 lint/测试 |
| `fix/xxx` | main | 合并后删除 | 缺陷修复 | 同上 |
| `release/vX.Y` | main | 版本发布后保留 6 个月 | 发布分支，只接受修复 | 修复需同时合并回 main（cherry-pick） |
| `hotfix/vX.Y.Z` | release | 合并后删除 | 线上紧急修复 | 合并到 release 与 main |

版本号单一事实来源：**根 `Cargo.toml`（壳）与 `extension/manifest.json`（扩展）必须同源**，由 CI 校验两者主次版本号一致，禁止手工改一处。

#### 13.4.2 提交与 PR 规范

- 提交信息：`type(scope): subject`，type ∈ {feat, fix, perf, refactor, test, docs, build, ci, chore}；中文或英文择一，全库统一。
- 每个 PR 必填：改动目的 / 影响范围 / 自测方式 / 是否需要更新文档或配置 schema / 是否涉及快捷键或 IPC 协议（涉及则必须同步更新第六章）。
- PR 合并检查项：CI 全绿 → 无遗留 `TODO(blocker)` → 涉及 UI 的附截图 → 涉及 IPC/配置的附兼容性说明。

#### 13.4.3 CI 流水线 Job 清单

| Job | 触发 | 内容 | 门禁 |
|-----|------|------|------|
| `lint-web` | 每次 PR | ESLint + Prettier + tsc --noEmit | 0 error |
| `lint-rust` | 每次 PR | `cargo fmt --check` + `cargo clippy -- -D warnings` | 0 warning |
| `test-rust` | 每次 PR | `cargo test`（单元 + NM 协议测试） | 全部通过 |
| `test-web` | 每次 PR | Vitest 单元测试 | 覆盖率 ≥ 阈值（见 15.2） |
| `build-ext` | 每次 PR | 构建扩展 zip，校验体积 < 1MB | 体积不超限 |
| `build-host` | 每次 PR | 交叉/本地构建 release exe，strip 符号 | 构建成功 |
| `e2e-smoke` | 合并到 main | 冒烟：装扩展 → NM 握手 → 截图翻译 → 浮窗出现 | 主流程通过 |
| `perf-baseline` | 每日/每次 release | 跑 15.5 性能基线与 soak 抽样 | 不劣化 > 10% |
| `package` | 打 tag | Inno Setup 打包 + 签名 + 生成 SHA256 + 上传 Release 草稿 | 签名成功 |
| `security-scan` | 每周 | `cargo audit` + `npm audit` + 依赖许可证检查 | 无 High 及以上 |

缓存策略：Rust `target/` 与 `~/.cargo` 用 actions/cache（13.2 中"Rust 编译时间"风险的落地手段）；node_modules 同理。

#### 13.4.4 制品与发布管理

| 制品 | 命名 | 存放 | 校验 |
|------|------|------|------|
| 扩展包 | `winocr-extension-vX.Y.Z.zip` | GitHub Release 附件 | SHA256 + 体积 |
| 安装包 | `WinOCR-Html-Setup-vX.Y.Z.exe` | GitHub Release + 官网 | SHA256 + 签名（Authenticode） |
| 便携版 | `WinOCR-Html-Portable-vX.Y.Z.7z` | GitHub Release | SHA256（未签名，需提供校验值） |
| 调试符号 | `winocr_host.pdb` | 单独归档，不随安装包分发 | 用于崩溃堆栈还原（见 16.6） |
| Release Notes | 自动生成于 CHANGELOG | Release 描述 | 含新增/修复/已知问题/升级提示 |

发布记录必须可追溯：每次发布在 CHANGELOG 记录 `版本号 / 日期 / 变更 / 已知问题 / 回滚方式`。

#### 13.4.5 环境与密钥隔离

| 环境 | 翻译引擎 Key | 遥测/崩溃上报 | 更新通道 |
|------|-------------|--------------|---------|
| dev | 开发者个人 Key（.env.local，不入库） | 关闭或本地日志 | 手动构建 |
| beta | 测试 Key（配额受限，独立账号） | 开启（标记 beta） | GitHub Pre-release |
| prod | 正式 Key（仅 CI Secret，不进仓库） | 开启（用户可选关闭） | 商店 + 应用内更新检查 |

**红线**：任何 Key 不得硬编码进源码或前端产物；Rust 壳中的 Key 存于 `winocr_config.json`，Windows 上用 DPAPI（当前用户上下文）加密存储，见 16.9。

---

## 十四、质量工程与测试策略（v1.5 新增）

### 14.1 测试分层与职责

| 层级 | 占比目标 | 覆盖对象 | 工具 | 运行频率 |
|------|---------|---------|------|---------|
| 单元测试 | 60% | 纯逻辑：路由策略、SM-2 算法、术语匹配、配置解析、NM 协议编解码、快捷键解析 | `cargo test` / Vitest | 每次提交 |
| 组件/集成测试 | 25% | 渲染引擎（DOM 注入）、浮窗绘制、OCR 预处理、翻译引擎适配器（mock HTTP） | Vitest + jsdom / Rust integration test | 每次 PR |
| 端到端（E2E） | 10% | 真实主流程（见 15.3） | Playwright（扩展模式）+ Python 驱动壳 | 每次合并 main / 发布前 |
| 手工探索性测试 | 5% | 兼容性、多显示器、杀软、异常网络 | 人工清单（见 15.4） | 每个 RC 一次 |

原则：**能自动化的不手工，能脚本化的不凭记忆**。发布前的手工测试清单必须是一份可勾选的文档，而不是"我大概试过"。

### 14.2 覆盖率与质量门禁

| 对象 | 门禁阈值 | 说明 |
|------|---------|------|
| Rust 核心逻辑（config/nm/hotkey/ocr 预处理/translate 路由） | 行覆盖 ≥ 70% | 关键分支（失败/降级/冲突）必须有用例 |
| 扩展核心逻辑（engine-router / dom-capture / renderer） | 行覆盖 ≥ 65% | UI 组件不强制 |
| 新增代码 | 增量覆盖 ≥ 60% | PR 级门禁 |
| Clippy / ESLint | 0 warning | 与 14.4.3 一致 |
| IPC 协议测试 | 100% 字段兼容用例 | 协议变更必须双向兼容测试（旧壳↔新扩展、新壳↔旧扩展） |

**兼容性特别门禁**：NM 协议与 `winocr_config.json` 的 schema 变更，必须附带"旧版本读新配置""新版本读旧配置"两组用例，避免用户升级后配置失效（见 16.5）。

### 14.3 E2E 关键场景矩阵（发布前必跑）

| # | 场景 | 步骤要点 | 判定标准 |
|---|------|---------|---------|
| E1 | 浏览器内划词翻译 | 选中段落 → 触发 → 查看译文 | 译文出现，原页面布局无破坏，可复制 |
| E2 | 浏览器内悬停翻译 | 鼠标悬停英文单词 → Tooltip | < 800ms 出现，移开自动隐藏，不遮挡阅读位置 |
| E3 | 全页双语对照 | 一键全页 → 滚动 → 切回原文 | 双语行内对齐，可一键还原，SPA 路由切换后仍生效 |
| E4 | **区域截图翻译（壳）** | `Ctrl+Shift+M` → 框选 → 松开 | 截图→OCR→译文浮窗全流程 < 1.5s（本地）/ < 3s（云端） |
| E5 | 全屏截图翻译 | `Ctrl+Shift+F` | 覆盖主显示器，多显示器时取当前焦点屏 |
| E6 | 多显示器与 DPI | 在 125%/150% 缩放、副屏上执行 E4 | 选区坐标正确，无偏移、无模糊 |
| E7 | 热键冲突回退 | 人为占用默认键 → 重启壳 | 自动切换备选键并提示，功能仍可用 |
| E8 | 引擎降级 | 断网 / Key 失效 | 自动降级到可用引擎，给出明确提示，不白屏 |
| E9 | 视频字幕 | YouTube/B站 播放 → 双语字幕 | 字幕同步，切换全屏/倍速后跟随 |
| E10 | PDF 翻译 | 打开文本型 PDF / 扫描件 | 文本型保留排版；扫描件走 OCR 不出空白 |
| E11 | 学习闭环 | 翻译 → 入生词本 → 复习 → 导出 Anki | Anki 实际可导入，字段不错位 |
| E12 | AI 对话（Phase 7） | 多轮对话 → 切换引擎 → 流式中断 | 上下文不丢，中断不残留状态 |
| E13 | 升级与回滚 | 装旧版 → 升级新版 → 回滚 | 配置与数据不丢，版本回退可用 |
| E14 | 卸载 | 控制面板卸载 → 检查残留 | 注册表项、托盘、开机自启、模型目录清理符合预期（用户可选保留数据） |

### 14.4 兼容性矩阵

| 维度 | 覆盖范围 | 最低要求 |
|------|---------|---------|
| 浏览器 | Chrome 最新稳定版及前 2 个版本；Edge 同源；Firefox ESR 与最新版 | 主流程 E1/E3 全通过 |
| 操作系统 | Windows 10 21H2+ / Windows 11 全版本 | 壳在两者均可注册热键与截图 |
| 架构 | x64（优先）；ARM64 评估 | x64 必须 |
| 显示 | 100% / 125% / 150% / 200% 缩放；单屏 / 双屏 / 三屏；不同 DPI 混插 | E6 通过 |
| 权限 | 标准用户 / 管理员安装 | 标准用户可完成 HKCU 注册（免管理员路径见 16.1） |
| 主题 | 浅色 / 深色 / 高对比度 | UI 可读、浮窗可读 |
| 环境 | 杀软（Defender/360/火绒）；远程桌面；游戏全屏（独占） | 明确记录已知限制并写入 FAQ |

### 14.5 性能基线与自动化

| 指标 | 基线值 | 采集方式 | 回归阈值 |
|------|--------|---------|---------|
| 壳冷启动 → 热键可响应 | < 300ms | 进程内埋点 + 外部计时脚本 | 劣化 > 20% 阻断 |
| IPC 单次往返（NM） | < 1ms（P50） | 1000 次往返统计 | 劣化 > 30% 阻断 |
| 截图（DXGI / GDI） | 50ms / 100ms @1080p | 内建 benchmark 命令 | 劣化 > 20% 阻断 |
| 本地 OCR（tiny） | ~1.5s | 固定测试图集 | 劣化 > 25% 阻断 |
| 端到端 截图→译文 | 见 14.1.5 | E2E 计时 | 劣化 > 20% 阻断 |
| 常驻内存（空闲） | < 30MB | 任务管理器/性能计数器采样 | 增长 > 50% 阻断 |
| 扩展注入开销 | 页面加载增加 < 100ms | Lighthouse 对比 | 劣化 > 30% 阻断 |
| OCR 准确率 | 印刷体英文 ≥ 95%，中文 ≥ 92%（标准图集） | 固定测试集比对 | 下降 > 3pp 阻断 |

性能预算写入 CI：每日跑 `perf-baseline`，结果落库成折线，避免"悄悄变慢"。

### 14.6 稳定性与 Soak 测试

| 测试项 | 方法 | 通过标准 |
|--------|------|---------|
| 24h 常驻 | 壳常驻 24h，每 5 分钟触发一次截图翻译 | 无崩溃，内存增长 < 10MB，句柄数稳定 |
| 休眠/唤醒 | 系统休眠 30 分钟后唤醒 | 热键仍有效，无需重启（或自动自愈重启并提示） |
| 高频触发 | 1 秒内连按 10 次热键 | 不重复弹窗、不卡死，请求队列正确去重 |
| 异常网络 | 断网/高延迟/HTTP 500/超时 | 有超时与重试上限，不无限等待，UI 有明确状态 |
| 模型缺失/损坏 | 删除或篡改模型文件 | 给出可操作的修复指引（重新下载），不崩溃 |
| 卸载残留后重装 | 卸载不清理数据 → 重装 | 正常识别旧配置并提示迁移 |

### 14.7 缺陷分级与修复 SLA

| 级别 | 定义 | 响应 | 修复 | 发布影响 |
|------|------|------|------|---------|
| **P0** | 崩溃/无法启动/主流程完全不可用/数据丢失/安全漏洞 | 立即（当天） | 24h 内修复或回滚 | 阻断发布；已发布则紧急版本 |
| **P1** | 主要功能严重受损（OCR 失败、翻译全失败、热键全部失效）无替代路径 | 24h | 3 天内 | 阻断发布 |
| **P2** | 功能可用但有明显缺陷（某站点双语错乱、某引擎失败、浮窗遮挡） | 3 天 | 本迭代内 | 记录为已知问题，可带病发布（需写在 Release Notes） |
| **P3** | 体验/文案/边缘场景 | 下次迭代评估 | 排期处理 | 不阻断 |

每个 P0/P1 必须有**根因分析与防复发措施**（补测试或加门禁），而非仅修现象。

### 14.8 发布准入清单（Release Checklist，逐项勾选）

**功能与质量**
- [ ] 15.3 的 E2E 场景矩阵（当期适用项）全部通过
- [ ] 15.4 兼容性矩阵当期范围通过，未通过项已写入已知问题
- [ ] 15.5 性能基线无劣化超阈值
- [ ] 15.6 Soak 测试通过
- [ ] 无未修复 P0/P1；P2 已登记且写入 Release Notes

**工程与合规**
- [ ] 版本号在三处一致（Cargo.toml / manifest.json / installer.iss）
- [ ] 安装包已签名；SHA256 已发布；便携版提供校验值
- [ ] `cargo audit` / `npm audit` 无 High 及以上
- [ ] 权限最小化核对（扩展权限 vs 实际使用）
- [ ] 隐私政策、许可证文件随包分发；SBOM 已生成
- [ ] 崩溃上报与自检工具已验证可用

**交付与运营**
- [ ] CHANGELOG / Release Notes 完成（含升级提示与已知问题）
- [ ] 用户文档、FAQ、商店文案已更新
- [ ] 回滚方案已验证（旧版本可正常安装并读取现有配置）
- [ ] 灰度计划与监控指标已就绪（见 16.7）
- [ ] 反馈渠道可用，值班人明确（单人即本人，需设置响应预期）

---

## 十五、安装、分发、升级与运维运营（v1.5 新增）

> 本章的用户视角部分（16.1）与第十七章互补：16.1 讲"装得上"，17.x 讲"用得顺"。

### 15.1 用户视角的极简安装（目标：3 步、1 分钟、不查文档）

```
下载 WinOCR-Html-Setup-vX.Y.Z.exe
        |
        v  双击（UAC 仅在需要写 Program Files 时弹出）
[1] 安装向导：语言 → 许可 → 路径 → 安装（默认勾选"注册浏览器宿主""开机自启"）
        |
        v  安装结束自动执行 install_host.bat（HKCU 注册，优先免管理员）
[2] 首次运行引导（17.3）：选翻译引擎（默认免费兜底）→ 确认快捷键 → 下载 tiny 模型（可选跳过）
        |
        v
[3] 试一次向导会主动提示："现在按 Ctrl+Shift+M 框选一段英文试试"
        |
        v  成功 → 引导结束，壳最小化到托盘；失败 → 直接给出自检与修复按钮
```

| 设计约束 | 要求 |
|---------|------|
| 步骤数 | 从下载到第一次成功翻译 ≤ 3 步 |
| 默认可用 | 不填任何 API Key 也能翻译（MyMemory/浏览器内置兜底） |
| 免管理员路径 | 默认安装到 `%LOCALAPPDATA%\Programs\WinOCR-Html`，注册表写 HKCU，`install_host.bat` 优先 HKCU；仅当用户选择"为所有用户安装"才提权 |
| 离线可用 | 安装包内置 tiny 模型（6.6MB），离线环境首次运行即可 OCR；medium 模型按需下载 |
| 失败可见 | 任何一步失败都给出具体原因 + 一键修复/一键复制诊断信息，禁止只弹"安装失败" |
| 反向操作 | 卸载入口在：控制面板、开始菜单、设置窗口"关于"页；托盘菜单提供"退出并卸载宿主" |

### 15.2 打包与签名规范

| 项 | 规范 |
|----|------|
| 打包工具 | Inno Setup（现有 `installer.iss`），输出 `WinOCR-Html-Setup-vX.Y.Z.exe` |
| 版本来源 | 与 `Cargo.toml`/`manifest.json` 同源，CI 校验（见 13.4.3） |
| 静默安装 | `Setup.exe /VERYSILENT /NORESTART /LOG=install.log /DIR="path"`；退出码 0 成功 |
| 静默卸载 | `unins000.exe /VERYSILENT`；保留用户数据选项 `/KEEPDATA` |
| 代码签名 | Authenticode（OV 起步，条件允许升级 EV）；签名服务放 CI，私钥不上开发机 |
| 校验值 | 每次发布在 Release 页公布 SHA256（签名版与便携版分别列出） |
| 杀软误报 | ① 必须签名；② 上市前用 VirusTotal 自检；③ 提供开源源码与构建可复现说明；④ 被报时走 24h 内申诉 + 公告渠道（见 15.10） |
| 安装包内容 | exe + 扩展目录 + `com.winocr_host.json` + tiny 模型 + LICENSE + 隐私政策 + 卸载脚本 |
| 体积控制 | 安装包 < 25MB；模型按需下载；禁止把 `target/` 调试产物打进包 |

`installer.iss` 现有问题（需修复）：`[Files]` 源路径硬编码为 `D:\AI\WinOCR-Html0.3 - 副本\...`，必须改为相对路径或 CI 变量，否则只能在特定机器打包。

### 15.3 Native Messaging Host 注册、注销与自愈

| 操作 | 实现方式 | 关键细节 |
|------|---------|---------|
| 注册 | 写注册表 `HKCU\Software\Google\Chrome\NativeMessagingHosts\com.winocr_host` 与 Edge 对应项，值为 manifest 绝对路径 | manifest 中 `path` 必须是安装后的真实 exe 路径（安装后重写，现有脚本已做）；`allowed_origins` 上架后应收敛为**具体扩展 ID**，不用通配符 `chrome-extension://*` |
| 注销 | `uninstall_host.bat`（管理员或当前用户上下文均可）删除注册表项 | 卸载程序必须调用，否则残留导致扩展反复报错 |
| **自愈** | 扩展每次启动/每隔 N 次调用失败时执行 `selfCheck()`：<br>① 注册表项是否存在且路径可访问；② exe 是否存在且可执行；③ 握手一次 ping；④ 失败则在设置页显示"修复"按钮 | 这是降低"装完不能用"类差评的核心手段，MVP 必须做 |
| 多浏览器 | Chrome / Edge 各自注册；Firefox 使用不同的 manifest 键（`allowed_extensions`）与注册表路径，需单独适配测试 |
| 手动安装场景 | 提供"仅扩展模式"：未装壳时浏览器内功能照常可用，只是不提供截图 OCR，不报错打扰 |

### 15.4 启动、常驻与关闭（用户可理解的三态模型）

| 状态 | 表现 | 触发方式 | 资源占用 |
|------|------|---------|---------|
| **运行中（常驻）** | 托盘图标常亮，全局热键生效 | 开机自启 / 手动启动 / 浏览器唤起 | 内存 < 30MB，CPU 近 0 |
| **暂停** | 托盘图标灰显，热键释放，进程仍在（快速恢复） | 托盘菜单"暂停" / 设置页开关 | 内存 < 15MB |
| **退出** | 进程结束，释放全部资源 | 托盘"退出" / 退出热键 `Ctrl+Alt+Q` / 命令行 `--quit` | 0 |

| 启动方式 | 说明 |
|---------|------|
| 开机自启 | 安装时默认开启（HKCU Run 或计划任务），可在设置页关闭；首次启动延迟 10s 错开开机高峰 |
| 浏览器唤起 | 扩展通过 Native Messaging 唤起（NM 由浏览器拉起进程，无需常驻）；**推荐默认**，省资源、免自启争议 |
| 手动启动 | 开始菜单/桌面快捷方式（参数 `--standalone`） |
| 命令行 | `winocr_host.exe --standalone` / `--nm` / `--self-check` / `--quit` / `--version` |

| 关闭与应急 | 说明 |
|-----------|------|
| 优雅退出 | 托盘右键 → 退出；或 `Ctrl+Alt+Q`；日志 flush、配置落盘、热键注销后再退出 |
| **强制关闭** | 托盘无响应时：任务管理器结束 `winocr_host.exe`；或 `taskkill /im winocr_host.exe /f`；写进 FAQ |
| 自愈重启 | 看门狗检测（可选）：主循环心跳超时 → 自动重启并弹一次提示；需在设置页可关闭 |
| 单实例 | 互斥量保证单实例，二次启动把参数转发给已有实例后退出（第七章已有"单实例保护"任务，需与 GUI 托盘联动） |

### 15.5 升级、回滚与数据迁移

| 项 | 规范 |
|----|------|
| 更新检查 | 启动时与每 24h 检查一次 GitHub Release（或自建 version.json），只返回版本号与下载 URL，不上报用户身份 |
| 更新策略 | 默认提示 + 用户确认；设置页可选"自动下载并提示安装"；禁止静默强制安装 |
| 升级流程 | 下载 → 校验签名与 SHA256 → 关闭当前壳（优雅退出）→ 安装 → 迁移配置 → 重启 → 显示"更新成功 + 变更摘要" |
| 配置迁移 | `winocr_config.json` 增加 `"config_version": N`；启动时若版本低于当前，按内置迁移函数逐级升级并**先备份**为 `winocr_config.json.bak` |
| 数据保全 | 用户数据（历史、生词本、术语库）独立于安装目录（存 `%APPDATA%\WinOCR-Html\`），卸载默认保留，可勾选清除 |
| 回滚 | 保留上一个版本的安装包于本地缓存；设置页"关于"提供"回退到上一版本"；回滚必须能正确读取**新版本写过的配置**（向下兼容或提供反向迁移） |
| 失败兜底 | 升级中断（断电/杀软拦截）→ 下次启动检测到半安装状态 → 提示"修复安装"并重新校验文件完整性 |

### 15.6 可观测性：日志、崩溃、遥测与自检

| 能力 | 规范 |
|------|------|
| 日志 | 路径 `%LOCALAPPDATA%\WinOCR-Html\logs\winocr-host-YYYYMMDD.log`；级别 ERROR/WARN/INFO/DEBUG（默认 INFO，设置页可开 DEBUG）；按天滚动，保留 7 天、单文件 5MB；**默认不记录原文与译文内容**，仅在 DEBUG 且用户明确开启时记录（并脱敏） |
| 崩溃上报 | Release 构建生成 PDB（不随包分发，归档保存）；崩溃时生成 minidump，用户确认后上传（含版本号、模块、堆栈、OS 版本），不含用户内容 |
| 匿名遥测 | **默认关闭**，首次引导明确询问；仅采集：版本号、OS/浏览器版本、功能使用次数（不含文本）、错误码、性能耗时；设置页可随时关闭并有"删除已上报数据"说明 |
| **一键自检（Doctor）** | 设置页与托盘菜单入口，输出一份可复制的诊断报告：<br>① 版本信息与安装路径；② NM 注册状态与握手结果；③ 热键注册结果与冲突键；④ 模型文件存在性与 SHA256；⑤ 引擎连通性（各引擎一次轻量探测）；⑥ 日志尾部 20 行（脱敏）<br>每项给出"正常 / 异常 + 修复建议 + 一键修复按钮" |
| 指标监控（发布后） | 崩溃率 < 0.5%、主流程成功率 > 98%、P50 端到端耗时、活跃用户数、各引擎失败率；超阈值触发告警 |

### 15.7 灰度发布与渠道

| 通道 | 受众 | 更新频率 | 门槛 |
|------|------|---------|------|
| Dev / CI 产物 | 开发者 | 每次合并 | 无 |
| Beta（GitHub Pre-release） | 内测群 | 每 1-2 周 | 无 P0/P1 |
| Stable（商店） | 全部用户 | 每 4-8 周 | 通过 15.8 清单 |

灰度步骤：Beta 通道 1-2 周 → 商店发布时若平台支持按比例放量（Chrome 支持分阶段推出）先 10% → 观察 48h（崩溃率、差评、P0）→ 全量；异常则暂停放量并回滚（16.5）。

### 15.8 成本与配额账

| 成本项 | 说明 | 控制手段 |
|--------|------|---------|
| 云端翻译 API | 默认引擎 SiliconFlow / MyMemory；用户自填 Key 时成本由用户承担 | ① 默认走免费额度引擎；② 内置用量统计与月度上限（可设）；③ 超限时提示并降级，不静默扣费 |
| 内置兜底额度 | 若产品自带 Key，需设全局配额与单用户日限额 | 配额告警阈值 80%；耗尽后引导用户填自己的 Key |
| 模型分发 | 模型走对象存储或 GitHub Release，产生流量成本 | tiny 随包；大模型用 CDN/镜像；提供种子/离线包 |
| 签名证书 | OV/EV 年费 | 列入年度预算；EV 可降低 SmartScreen 拦截 |
| 崩溃/遥测服务 | 自建或第三方 | MVP 阶段用 GitHub Release + 日志文件即可，避免过早引入 SaaS |

对外表述红线：**任何涉及费用、配额、价格的承诺必须由负责人确认**，文档中不写具体价格数字（会过期）。

### 15.9 安全与合规落地清单

| 项 | 落地要求 |
|----|---------|
| 密钥存储 | 用户 API Key 存 `winocr_config.json`，Windows 用 DPAPI（`CryptProtectData`，当前用户上下文）加密字段；内存中使用后及时清零；禁止写日志 |
| 扩展权限最小化 | manifest 只声明必需权限（storage、activeTab、scripting、nativeMessaging 等）；上架时逐项说明理由；不用 `<all_urls>` 除非必要，必要则给出解释 |
| 内容安全策略 | 扩展页面 CSP 禁止 `unsafe-eval` 与远程脚本；所有第三方资源本地化 |
| 数据最小化 | 默认不上传原文/译文；OCR 本地；云端翻译需用户显式启用；提供"清除全部本地数据" |
| 开源合规 | 生成 SBOM（CycloneDX）；核对依赖许可证（尤其 ONNX Runtime、Tesseract.js、PP-OCRv6 模型的许可条款）；LICENSE 随包分发 |
| 隐私政策 | 发布前上线，说明采集项、用途、存储期限、关闭方式；商店提交必填 |
| 漏洞响应 | 提供安全邮箱/issue 模板；P0 安全漏洞 24h 内响应、72h 内修复或给出缓解方案并公告 |
| 供应链 | 依赖锁定（Cargo.lock / package-lock 入库）；`cargo audit` 每周；构建环境可复现 |

### 15.10 运营与用户成功闭环

| 环节 | 做法 |
|------|------|
| 商店资产 | 名称/简介/截图（含中文）/演示视频（< 30s 展示截图翻译）/权限说明/隐私政策链接/更新日志 |
| 帮助中心 | README + FAQ（安装、热键、壳未启动、翻译失败、模型下载、卸载残留、杀软误报）+ 快捷键速查表（可打印） |
| 反馈渠道 | GitHub Issues（模板化：版本/OS/浏览器/复现步骤/日志）+ 商店评论监控 |
| 反馈 SLA | Bug 48h 内确认、P1 3 天内给结论；需求进入 Backlog 并回复预期（不承诺未确认排期） |
| 版本节奏 | GA 前每 1-2 周 Beta；GA 后每 4-8 周次版本；紧急修复随时发修订版 |
| 已知问题公示 | Release Notes 与 FAQ 同步更新，避免重复提问与差评 |
| 数据迁移/EOL | 停止支持某 Windows/浏览器版本前 ≥ 3 个月公告；主版本升级必须提供配置与数据迁移路径 |
| 复盘沉淀 | 每次发布后记录：缺陷分布、延期原因、用户反馈TOP3 → 更新风险登记册与测试用例库 |

---

## 十六、用户使用视角与第一性原理（v1.5 新增）

### 16.1 第一性原理：用户到底要什么

把需求还原到不可再拆的事实：

| 事实（不可再拆） | 推导出的设计约束 |
|-----------------|-----------------|
| 用户是在**做别的事**（读文档/看视频/写邮件）时遇到外文 | 翻译不能打断主任务：不切窗、不抢焦点、不弹模态框 |
| 用户的**眼睛和注意力**在原文的那一小块区域 | 译文必须出现在**视线焦点附近**（原位/就近），而不是屏幕中央或另一个窗口 |
| 用户要的是"**理解**"，不是"得到一段译文" | 一次只解决一个问题；给译文 + 必要的原文对照即可，不要塞满功能 |
| 用户**不想先配置**再用 | 零配置可用（免费兜底引擎 + 默认键位 + 内置小模型），配置是可选的进阶项 |
| 用户会**忘记**自己改过的键位和设置 | 键位必须随时可查（托盘/设置页/速查表），且有一键恢复默认 |
| 用户**害怕装了卸不干净**的程序 | 退出/暂停/卸载入口清晰，卸载可保留数据，注册表与自启项可查可清 |
| 用户不理解"壳""宿主""Native Messaging" | 界面里不出现这些词；用"后台翻译服务"代替，只在高级区给出技术名词 |

**判据（每个功能需求都过这三关，过不了就不做或改造）**：
1. 是否让用户少做一步？
2. 是否让译文更靠近视线焦点？
3. 是否让首次使用更少配置？

反例（明确不做）：翻译时弹出居中对话框、打开新标签页看结果、翻译前强制要求填 API Key、每次触发都问"用哪个引擎"。

### 16.2 视野集中原则（Focus Conservation）

> **用户眼睛停在哪里，译文就出现在哪里；用户的手不需要离开正在做的事。**

| 规则 | 具体要求 | 落地位置 |
|------|---------|---------|
| 就近呈现 | 译文出现在被翻译内容的位置或紧邻位置（≤ 200px 视距内） | 浏览器内行内双语（M8）；壳的浮窗锚定选区（5.6 / 18.5） |
| 原位优先 | 浏览器外优先原位覆盖绘制（盖住原文位置），其次是就近浮窗 | M6 浮窗绘制 |
| 不遮挡 | 浮窗默认放在选区下方或侧面，若遮挡则自动翻转方向；浏览器内 Tooltip 不覆盖被翻译词 | 渲染引擎自动避让逻辑 |
| **不抢焦点** | 浮窗使用 `WS_EX_NOACTIVATE` + `WS_EX_TOOLWINDOW`，绝不 `SetForegroundWindow`；用户当前输入焦点不变 | window.rs |
| 不打断输入 | 用户在输入框打字时，不自动弹出任何东西（除非显式触发） | 交互层抑制策略 |
| 可消失、可固定 | 默认点击外部/按 Esc 消失；需要细读时可"固定"（pin），固定后仍不抢焦点 | 18.5 |
| 一屏一动作 | 单次触发只做一件事，不叠加推荐/统计/引导 | 全局 |
| 状态可见 | 进行中显示轻量加载态（< 200ms 不显示，避免闪烁），失败显示可操作的原因 | 全局 |

### 16.3 首次运行引导（First-Run Wizard）

原则：**5 步以内、每步可跳过、全程不索取 API Key、结束前必须成功一次**。

| 步骤 | 内容 | 默认 | 可跳过 |
|------|------|------|--------|
| 1 选择主场景 | 勾选"网页翻译 / 截图翻译 / 视频字幕" | 全选 | 是 |
| 2 翻译引擎 | 默认"免费引擎（无需 Key）"；高级用户可在此填自己的 Key | 免费兜底 | 是（可后进设置页） |
| 3 快捷键确认 | 展示默认键位并提供"按一下试试"的即时测试 | `Ctrl+Shift+M` 等 | 是 |
| 4 模型与精度 | 下载 tiny 模型（6.6MB，默认）/ 稍后下载（仅云端引擎时可用） | tiny | 是（无网络时自动跳过） |
| 5 试一次 | 主动提示"现在按 Ctrl+Shift+M 框选一段英文"，成功后引导结束 | — | 否（这一步是留存关键） |

引导结束后：壳最小化到托盘，托盘首次气泡提示"我在这里，右键可暂停/退出/打开设置"，且**只提示一次**。

### 16.4 日常使用的三条主路径

**P1 — 任意界面截图翻译（浏览器外，最高频）**

```
按住 Ctrl+Shift+M → 屏幕变暗、出现十字光标 → 拖框选中区域 → 松开
        → [底层：截图 → OCR → 翻译 → 绘制浮窗]
        → 译文出现在刚才框选的位置旁（原地，不跳转）
        → Esc 或点击别处关闭；想细读按 P 固定
```
- 用户感知耗时：本地 OCR 约 1.5s，云端约 2-3s；超过 3s 必须显示进度状态。
- 失败时：在原位显示一行"没识别到文字 / 翻译失败（原因）+ 重试按钮"，不弹错误框。

**P2 — 浏览器内阅读（次高频）**
- 划词 → 就近显示译文（默认）；悬停 → Tooltip（可在设置中关闭，避免误触）。
- 整页看不懂 → 一键双语对照 → 再次触发可还原，滚动与 SPA 跳转后保持状态。

**P3 — 视频字幕**
- 打开视频页 → 侧边栏/图标菜单开启双语字幕 → 字幕叠加在画面下方，可切换"仅译文 / 双语 / 关闭"。

三条路径共享同一套设计令牌与交互习惯（Esc 关闭、P 固定、右键菜单重译/复制），降低学习成本。

### 16.5 快捷键：从用户视角重新组织

#### 16.5.1 默认键位（用户速查表，可直接放进帮助页）

| 我想做什么 | 按什么 | 什么时候用 |
|-----------|--------|-----------|
| 截图翻译（框选） | `Ctrl+Shift+M` | 任意界面看不懂的一段字（PDF、软件界面、图片、游戏） |
| 全屏截图翻译 | `Ctrl+Shift+F` | 整屏内容都要看（少用，误触率高，默认可关） |
| 翻译选中的文字 | `Alt+Shift+Z` | 浏览器里已选中一段文字 |
| 打开插件面板 | `Alt+Shift+W` | 想看历史、生词本、设置 |
| 开关双语对照 | `Ctrl+O` | 网页整页阅读（注意：与浏览器打开文件的 Ctrl+O 冲突风险，见下） |
| 快速收藏生词 | `Ctrl+Shift+A` | 阅读时遇到想记住的词 |
| 开始复习 | `Ctrl+Shift+R` | 每天固定时间复习 |
| 退出后台服务 | `Ctrl+Alt+Q` | 想彻底关掉壳 |

> **已知的键位风险（必须在实现时处理）**：`Ctrl+O` 是浏览器"打开文件"的系统级快捷键，浏览器内扩展快捷键实际由 Chrome 的 commands API 管理且通常不会覆盖，但建议把默认值改为 `Alt+Shift+B` 一类的低冲突组合，并在设置页提示。默认键位定版前需在 Chrome/Edge/Firefox 实测一遍冲突（见 15.3 E7）。

#### 16.5.2 键位设计原则（肌肉记忆优先）

1. **单手可达**：优先左手区组合（Ctrl/Alt/Shift + 字母），避免需要两只手。
2. **语义锚定**：M=Mark（框选）、F=Full（全屏）、Z=翻译、W=Window（面板）、R=Review、A=Add、Q=Quit。
3. **不侵占系统/高频键**：禁用 `Ctrl+C/V/X/A/Z/S/F/W/T/N` 等与系统、编辑器冲突的组合；`Ctrl+Shift+N/T/W` 等浏览器窗口键一律不用。
4. **不与输入法冲突**：避免 `Ctrl+Space`、`Shift` 单键等。
5. **数量克制**：默认只启用 4-6 个高频键，其余默认关闭，用户需要再开（减少冲突概率与认知负担）。

#### 16.5.3 录入交互（用户视角）

```
设置 → 快捷键 → 点击某个功能的输入框（显示"按下新的组合键…"）
        → 用户直接按键（不需要打字，不接受"请输入 Ctrl+Shift+M"这种文本输入）
        → 界面立刻回显："Ctrl + Shift + M"
        → 若冲突：显示"这个组合已被 XX 占用，已自动改用 Ctrl+Alt+M（可点此手动改）"
        → 即时生效：不用重启浏览器、不用重启壳，立刻可以按一次验证
        → 提供"测试"按钮：按下后 2 秒内显示"已收到按键 ✅"
```
补充交互：
- 支持 `Backspace` 清空、`Esc` 取消本次录入；
- 不允许只录修饰键（如只按 Ctrl）；
- 冲突检测覆盖：本程序已注册键、浏览器扩展命令、系统保留键（尽力而为，检测不到时提示"可能被其他软件占用"）；
- 一键"恢复默认键位"；
- 设置页顶部常驻"当前键位速查"，并支持导出为图片/文本。

#### 16.5.4 "我忘了快捷键"的四个补救入口

1. 托盘图标悬停 → 气泡显示 2-3 个主用键位；
2. 托盘右键菜单 → 每个菜单项右侧显示对应快捷键；
3. 设置页 → 快捷键页顶部速查表（可打印/导出）；
4. 帮助页 → 快捷键速查卡片（PDF/图片），随包分发。

### 16.6 壳的启动、暂停、关闭（用户版）

| 用户问题 | 答案（界面里的说法） |
|---------|-------------------|
| 这个程序要一直开着吗？ | **不必。** 装了扩展后，浏览器需要时会自动拉起后台服务；只有"用快捷键截图翻译"才需要它常在后台（建议开机启动）。 |
| 怎么启动？ | 三种都会：① 开机自动启动（默认开）；② 开始菜单/桌面快捷方式；③ 浏览器需要时自动拉起。 |
| 怎么暂停一下？ | 托盘右键 → 暂停（热键失效，进程还在，恢复是秒级的）。适合打游戏/开会投影时。 |
| 怎么彻底关掉？ | 托盘右键 → 退出；或按 `Ctrl+Alt+Q`。 |
| 关不掉/卡住了？ | 任务管理器结束 `winocr_host.exe`；或托盘右键 → 重启服务。仍不行：设置 → 关于 → 复制诊断信息，提交反馈。 |
| 会不会偷偷上传我看的内容？ | 不会。OCR 在本地；只有你主动开启云端翻译时，才会把**被翻译的文本**发给所选引擎；遥测默认关闭（见 16.6）。 |

托盘菜单结构（详见 18.2）：`打开设置 / 暂停（或继续） / 自检诊断 / 关于与更新 / —— / 退出`。

### 16.7 插件常驻：用户需要知道的事

| 项 | 说明（界面/文档表述） |
|----|---------------------|
| 常驻形式 | 扩展随浏览器启动；地址栏固定图标（引导用户固定一次） |
| 后台休眠 | MV3 的 Service Worker 空闲会被浏览器休眠，属于正常现象；触发翻译时会自动唤醒，首次触发可能多出几百毫秒 |
| 用户可见元素 | 地址栏图标（可显示状态角标）、右键菜单（可在设置中关闭）、可选侧边栏面板 |
| 与壳的关系 | 网页翻译只需扩展；截图翻译需要后台服务（壳）。两者都装才全场景覆盖 |
| 资源承诺 | 扩展常驻内存 < 20MB，空闲 CPU ≈ 0；壳空闲内存 < 30MB |
| 可关闭项 | 右键菜单、角标提示、侧边栏自动打开、开机自启（都在设置页，且都有明确说明） |

### 16.8 用户自助故障处理（症状 → 动作）

| 症状 | 最可能原因 | 用户操作（≤ 2 步） | 仍不行 |
|------|-----------|------------------|--------|
| 按快捷键没反应 | 壳未运行 / 热键被占用 | 托盘看图标是否亮 → 设置 → 快捷键查看与重录 | 设置 → 自检诊断 → 复制报告提交 |
| 提示"无法连接后台服务" | NM 注册失效或路径变更 | 设置 → 点"修复宿主注册" | 重新运行安装包选择"修复" |
| 截图成功但没识别到字 | 图片太小/太模糊/模型未下载 | 选区放大些重试；设置 → OCR → 检查模型状态 | 切换更高精度模型档位 |
| 翻译一直失败 | Key 无效/网络不通/额度耗尽 | 设置 → 引擎 → 点"测试连接" | 换免费兜底引擎或填自己的 Key |
| 网页翻译不显示 | 该站点被脚本拦截或双语被站点 CSS 覆盖 | 刷新页面；切换"译文样式"为高对比 | 提交站点 URL 供适配 |
| 装完杀软报警 | 未签名/启发式误报 | 以签名版重装；查看 FAQ 的白名单步骤 | 提交误报样本给我们申诉 |
| 卸载后还有残留 | 注册表/自启项未清 | 运行卸载程序 → 勾选"同时清除宿主注册与数据" | FAQ 提供手动清理步骤 |

---

## 十七、Rust 壳完整 GUI 设计（v1.5 新增）

> **现状缺口**：当前 `native_host_rust/src/window.rs` 只实现了无交互的译文浮窗，托盘图标、设置窗口、模型管理、历史/生词本窗口全部缺失，用户只能手工编辑 `winocr_config.json`。这是从"能跑的原型"到"可交付产品"之间最大的缺口，因此单列一章。

### 17.0 实现状态总览（2026-09-24）

> 本章为 GUI 设计蓝图。下表对照 **实际代码落地**（`native_host_rust/`）。状态：✅ 已实现 / 🟡 部分实现 / ❌ 未实现。技术路线实际为**纯 winapi 自绘**（非 17.1.1 初稿规划的 windows-rs + egui），详见 17.1.1 实现注记。

| 小节 | 设计要点 | 状态 | 实际落地 / 缺口 |
|------|---------|------|----------------|
| 17.1 总体架构 | 五层（托盘/覆盖/浮窗/主窗/Toast） | 🟡 | 架构吻合；实际为纯 winapi 自绘（ADR-003），未引入 egui / WebView2 |
| 17.2 托盘 | 状态机四态 / 深浅图标 / 左键可配 / 气泡仅一次 / 退出等待 | 🟡 | 基础版已实现（图标 + 右键菜单 7 项 + 首次气泡）；**缺**四态图标、深浅色 ICO、左键行为可配、退出等待进行中任务 3s |
| 17.3 设置主窗口 | 8 分区 + 左侧导航 + 即时生效 + 位置记忆 | 🟡 | **6 区块**（通用/引擎/快捷键/外观/高级/关于），非 Tab 导航；「外观」页含主题/字号/不透明度/**界面语言/放大镜/边缘吸附**（本轮新增，ui_lang/magnifier/snap 即时生效）、「高级」页含配置导出/导入/重置；**缺** OCR 与模型页、隐私与数据页、Tab 导航 |
| 17.4 选区增强 | 放大镜 / 8 手柄 / 吸附 / 微调 / 记忆 / 提示条 | ✅ | 方向键微调 + 区域记忆 + **本轮新增**独立放大镜窗口（BitBlt 缩放，可关）、8 缩放手柄拖拽、屏幕边/顶层窗边吸附（可关）、底部提示条 2s 淡出（`selection_window.rs`，config.magnifier/snap 开关） |
| 17.5 译文浮窗 | 收藏生词 / 换引擎重译 / 拖动 / 缩放 / 双击编辑 / 状态机 / 无障碍 | ✅ | 复制/重译/固定/关闭 + 拖动 + 缩放 + 位置记忆 + **本轮新增**收藏生词（写入生词本）、换引擎重译（`RetranslateRequest.engine`，主循环 `translate_with`）、双击编辑原文重译、全屏独占隐藏（`is_fullscreen_exclusive`）、UIA（SetWindowText 暴露译文）、加载/空/错误态 |
| 17.6 历史 / 生词本 | 历史列表 + 导出、生词本 + SM-2 复习 | ✅ | **本轮新增** `history.rs`（JSONL 历史 + 生词本 SM-2 复习状态）+ `history_window.rs`（历史窗口：搜索/筛选/导出 JSON·CSV·MD/清空；生词本窗口：复习/导出 Anki·CSV/删除；复习闪卡：空格翻面/1-3 打分/Esc，SM-2 推进）。托盘菜单新增 历史/生词本/复习 入口 |
| 17.7 Toast | 排队 / 分级时长 / 抑制 / 三段式 + 操作按钮 | ✅ | **本轮新增**全局队列（最多 3 个纵向堆叠 + 上限淘汰）、分级时长（Info 4s / Warn 8s / Error 不自动消失）、同一消息 5 分钟抑制、Error 带「复制诊断 / 打开设置」操作按钮（`show_toast_actions`），诊断经 `globals::set_last_diagnostic` 注入 |
| 17.8 设计规范 | Tokens / 深色主题 / i18n / DPI / 键盘可达 | 🟡 | **本轮新增** i18n 模块（`i18n.rs`：zh/en 静态对照表 + `tr()`，config.ui_lang 即时切换）、深色主题落地（浮窗 `draw_overlay` 按 theme 配色、设置新增「界面语言/放大镜/边缘吸附」）；**仍缺**系统化 Design Tokens、Per-Monitor V2 显式 DPI、完整控件深色重绘 |
| 17.9 落地计划 | G1~G12 共 62 人日 | 🟡 | 8a 部分 + 8b 部分完成；剩余随 P2+ 推进 |

> 详细实现记录与逐轮状态见 `交付.md`。

### 17.1 GUI 总体架构

```
+-----------------------------------------------------------------+
|  托盘层（常驻入口）                                               |
|  图标状态 / 右键菜单 / 气泡提示（只提示一次）                      |
+---------------------------+-------------------------------------+
|  覆盖层（临时）            |  浮窗层（临时，可固定）                |
|  截图选区遮罩 + 放大镜     |  译文显示 + 工具栏（复制/重译/固定）   |
+---------------------------+-------------------------------------+
|  主窗口层（按需）                                                 |
|  设置（8 个分区） / 历史 / 生词本 / 自检诊断 / 关于与更新          |
+-----------------------------------------------------------------+
|  通知层：Toast（右下角，不抢焦点，最多 3 个）                      |
+-----------------------------------------------------------------+
```

各层的窗口属性（决定"是否抢焦点、是否被杀软反感、是否出现在任务栏"）：

| 层 | 窗口样式要点 | 任务栏 | 焦点 |
|----|-------------|--------|------|
| 托盘 | `Shell_NotifyIcon`，隐藏主窗口 | 否 | 否 |
| 覆盖层 | 全屏顶层、半透明、`WS_EX_LAYERED` | 否 | 是（选区交互需要，但退出即还原焦点） |
| 浮窗 | `WS_EX_TOPMOST \| WS_EX_TOOLWINDOW \| WS_EX_NOACTIVATE` | 否 | **永不抢焦点** |
| 主窗口 | 常规可调整窗口、最小化到托盘而非任务栏（可配） | 可配 | 用户主动打开时才有 |
| Toast | `WS_EX_NOACTIVATE` + 上层 | 否 | 否 |

#### 17.1.1 GUI 技术选型

| 方案 | 体积增量 | 启动影响 | 中文/DPI | 与现有代码整合 | 许可 | 结论 |
|------|---------|---------|---------|--------------|------|------|
| **原生 windows-rs 自绘** | 0 | 无 | 需自己处理字体与 DPI，工作量大 | 最好（已用 winapi/winit） | MIT | **必选**：托盘、覆盖层、浮窗、Toast |
| **egui（+ wgpu/glow）** | +3~6MB | 冷启动 +50~100ms | 需内嵌中文字体（子集 ~2-5MB）；DPI 由框架处理 | 中（需接入窗口句柄，或独立窗口） | MIT/Apache-2.0 | **推荐**：设置主窗口、历史/生词本、自检 |
| WebView2（wry/Tauri 精简） | +1.5MB（引导器） | 首次加载 ~200-400ms | 最好（复用第五章 Design Tokens 与扩展 UI 代码） | 中（需 Runtime；Win11 内置，Win10 需联网装 Evergreen） | MIT/Apache | **备选**：当 UI 复杂度继续上升时 |
| Slint | +1~3MB | 小 | 好 | 中 | GPLv3 或商业 | **排除**（与 MIT 项目许可冲突风险） |
| Iced | +3~5MB | 中 | 需内嵌字体 | 中 | MIT | 备选 |

**决策（记为 ADR）**：
1. 托盘 / 选区覆盖层 / 译文浮窗 / Toast —— **原生 windows-rs 实现**（零额外体积、启动快、焦点与层级控制精确）。
2. 设置主窗口 / 历史 / 生词本 / 自检 —— **egui 实现独立窗口**，与原生层通过内部消息通道通信；中文字体内嵌子集。
3. 若 egui 在目标机器上出现 GPU 兼容问题（虚拟机、老旧显卡），降级为"Web 设置页"：egui 窗口不可用时，打开浏览器访问 `http://127.0.0.1:<随机端口>` 的本地设置页（仅本机回环、带一次性 token），保证用户永远有办法配置。

> **实现注记（2026-09-24，对应 ADR-003）**：本章初稿规划"原生 windows-rs + egui 独立窗口"，但**实际落地为纯 `winapi` 自绘**（未引入 egui / WebView2，也未实现 Web 降级通道）。原因：gnu 工具链下引入 egui/wgpu 会显著增大二进制与编译成本，且当前 GUI 规模可由 Win32 控件覆盖（设置窗口即 Win32 控件实现，见 `settings_window.rs`）。egui 仍保留为未来"历史 / 生词本"等复杂窗口的候选方案。选型差异已在 17.0 状态表中标注。

### 17.2 托盘图标与菜单

| 项 | 规范 |
|----|------|
| 图标资源 | 提供 16/20/24/32/64/256 多尺寸 ICO；浅色与深色主题各一套（Windows 11 任务栏自适应） |
| 状态 | 正常（亮）/ 暂停（灰）/ 翻译中（轻动效，≤ 1s）/ 错误（红色角标）；状态变化写日志 |
| 左键单击 | 打开设置窗口（可配置：打开设置 / 触发区域截图翻译 / 无动作） |
| 左键双击 | 触发区域截图翻译（默认） |
| 右键菜单 | 打开设置　`　`<br>暂停 / 继续<br>────────<br>区域截图翻译　`Ctrl+Shift+M`<br>全屏截图翻译　`Ctrl+Shift+F`<br>────────<br>历史记录<br>生词本<br>────────<br>自检诊断<br>关于与更新<br>────────<br>退出　`Ctrl+Alt+Q` |
| 菜单细节 | 每项右侧显示当前快捷键；暂停状态下截图项置灰并提示"当前已暂停" |
| 气泡提示 | 仅三种场景且各只提示一次：首次安装完成、自动回退了快捷键、P0 级错误 |
| 退出确认 | 默认直接退出（不弹确认）；若存在进行中的翻译任务，等待其结束或 3s 超时后退出 |

### 17.3 设置主窗口（Shell Settings）

**窗口规格**：默认 960 × 680；最小 800 × 600；启动居中于鼠标所在显示器；记住位置与大小（含多显示器场景）；`Per-Monitor V2` DPI 感知；标题栏显示版本号；Esc 关闭（有未保存改动时提示）。

**信息架构（左侧导航 + 右侧内容 + 底部操作条）**

| 分区 | 字段/控件 |
|------|----------|
| 通用 | 开机自启 / 随浏览器拉起 / 源语言-目标语言 / 托盘左键行为 / 浮窗默认行为（自动消失时长或手动关闭）/ 提示音（默认关） |
| 翻译引擎 | 引擎列表（启用开关、拖拽排序）/ 每个引擎的 Key 与模型参数 / "测试连接"按钮（显示耗时与失败原因）/ 路由策略（自动/手动优先）/ 超时与重试次数 / 月度用量统计与上限 |
| 快捷键 | 见 17.5：录入控件 + 冲突提示 + 测试按钮 + 速查表 + 恢复默认 |
| OCR 与模型 | 精度档位（tiny/small/medium）/ 模型状态（已下载/缺失/损坏，显示 SHA256 校验结果）/ 下载、切换、删除 / 识别语言 / 预处理开关（二值化、放大、去噪）/ 上次 OCR 耗时与准确率自检 |
| 外观 | 主题（浅色/深色/跟随系统）/ 字号（小/标准/大）/ 浮窗不透明度 / 译文样式（仅译文/双语/高对比）/ 浮窗位置记忆 |
| 隐私与数据 | 遥测开关（默认关）/ 日志级别 / **默认不记录原文译文**（开启需二次确认）/ 清除全部数据 / 导出诊断包 / 数据目录打开 |
| 高级 | 单实例与端口设置 / 调试模式 / 配置导入导出（`winocr_config.json`）/ 手动重注册宿主 / 重置到出厂设置 |
| 关于 | 版本号与构建号 / 检查更新（显示当前通道 dev/beta/stable）/ 许可证与第三方许可（SBOM 链接）/ 自检诊断入口 / 反馈链接 |

**行为约定**：
- 所有改动**即时生效**（改快捷键立刻重注册、改主题立刻重绘浮窗），不要求重启；只有"语言对默认值"等少数项需要提示。
- 保存时先写临时文件再原子替换，并保留一份 `.bak`；写失败要提示具体原因（文件被占用/只读/磁盘满）。
- 键盘可达：`Ctrl+S` 保存、`Esc` 关闭、`Tab` 顺序与视觉顺序一致、焦点环始终可见。
- 每个分区右下角提供帮助入口（跳转到对应 FAQ 锚点）。

### 17.4 截图选区覆盖层（交互增强）

| 能力 | 规范 |
|------|------|
| 遮罩 | 每个显示器一个全屏顶层半透明窗口（遮罩 40% 黑），选区区域不遮罩、保持原亮度 |
| 选区 | 拖拽创建；8 个缩放手柄；拖动移动；显示实时尺寸（px） |
| 精确微调 | 方向键 1px、`Shift+方向键` 10px、`Enter` 确认、`Esc` 取消 —— 保证无鼠标也能用 |
| 放大镜 | 光标附近 3-5 倍放大（含坐标与像素提示），可关闭 |
| 智能吸附 | 对明显的文本块/窗口边界做边缘吸附（可关闭，避免"吸不准"的挫败感） |
| 区域记忆 | 记住上次选区，提供"重复上次区域"快捷键 |
| 多显示器 | 默认取鼠标所在显示器；支持切换显示器；DPI 换算必须准确（125%/150% 下坐标不偏移） |
| 性能 | 拖动过程 ≥ 60fps；松手后遮罩立即销毁，焦点还原到原窗口 |
| 提示条 | 屏幕底部居中轻量提示"拖框选择要翻译的区域，Esc 取消"，不抢焦点、2s 后淡出 |

### 17.5 译文浮窗（可交互升级，替代 5.6 的只读浮窗）

在 5.6 规范之上增加：

| 元素 | 规范 |
|------|------|
| 工具栏 | 复制译文 / 重新翻译 / 换引擎重译 / 收藏为生词 / 固定（pin）/ 关闭；图标 16px，带 tooltip |
| 内容区 | 原文（可折叠，小字灰）/ 译文（主文本，可滚动）/ 引擎与耗时（右下角小字） |
| 交互 | 可拖动标题栏移动；右下角可缩放；支持 `Ctrl+滚轮` 或 `Ctrl +/-` 改字号；双击译文进入编辑态（改词后重译，可选） |
| 位置 | 默认就近选区；自动避让屏幕边缘与任务栏；记住上次位置（可关） |
| 关闭 | `Esc` / 点击外部 / 工具栏关闭；默认 15s 自动消失（可改为手动关闭）；固定后不自动消失 |
| 层级 | 置顶但不抢焦点；检测到全屏独占应用（游戏/播放器全屏）时自动隐藏，退出全屏后恢复 |
| 状态 | 加载态（< 200ms 不显示，避免闪烁）/ 空态（"没识别到文字" + 重试按钮）/ 错误态（原因 + 重试 / 打开设置） |
| 无障碍 | 暴露 UIA `Name` 与文本，供屏幕阅读器读取；支持系统字号缩放与高对比度 |

### 17.6 历史与生词本窗口

| 窗口 | 内容 |
|------|------|
| 历史记录 | 时间倒序列表；搜索（原文/译文全文）；筛选（时间范围、语言对、引擎、是否收藏）；详情侧栏（原文、译文、引擎、耗时、来源）；批量导出（JSON/CSV/Markdown/SRT）；删除与清空；分页或虚拟滚动（1 万条不卡） |
| 生词本 | 单词列表 + 掌握度（SM-2 状态）；筛选（掌握度、标签、来源）；批量操作（加入复习、移除、导出 Anki）；统计卡片（总数、今日新增、待复习、已掌握） |
| 复习面板 | 闪卡模式（认识/模糊/忘记）；键盘操作（`Space` 翻面、`1/2/3` 打分、`Esc` 退出）；每日目标与完成度 |

两个窗口复用设置主窗口的同一套框架、主题与导航样式，避免"两个程序拼在一起"的观感。

### 17.7 Toast 与错误提示

| 规则 | 规范 |
|------|------|
| 位置 | 主显示器右下角、托盘上方，系统通知区内不占用 |
| 数量与时长 | 同时最多 3 个；提示 4s、警告 8s 自动消失；错误不自动消失，需用户关闭或处理 |
| 焦点 | `WS_EX_NOACTIVATE`，永不抢焦点、不打断输入 |
| 文案 | 三段式：**发生了什么 / 为什么 / 怎么办**；错误必须带操作按钮（重试 / 打开设置 / 复制诊断） |
| 示例 | "翻译失败：云端引擎超时（3s）。已自动改用本地引擎。—— [重试] [打开设置]" |
| 抑制 | 同一错误 5 分钟内不重复弹；高频操作只提示一次汇总结果 |

### 17.8 GUI 设计规范（与第五章对齐）

| 项 | 规范 |
|----|------|
| Design Tokens | 直接复用 5.2（颜色、圆角、阴影、间距、动效时长）；原生层实现为常量表，egui 层实现为同值主题 |
| 栅格 | 8pt 网格；控件高度 32（紧凑）/ 40（标准）；按钮最小点击区 32×32 |
| 字体 | 中文优先"微软雅黑 / 思源黑体 / 系统默认"，英文与数字用等宽或界面字体；egui 需内嵌字体子集保证跨机一致 |
| 主题 | 浅色 / 深色 / 跟随系统；浮窗与覆盖层同样支持 |
| 高 DPI | `Per-Monitor V2`；100/125/150/200% 四种缩放实测（见 15.4） |
| 动效 | 与 5.5 一致（120-200ms、缓动标准曲线）；可全局关闭动效（无障碍选项） |
| 键盘可达性 | 所有功能键盘可达；Tab 顺序合理；焦点环可见；支持系统"减少动效"与"高对比度" |
| 文案 | 不出现技术黑话（用"后台翻译服务"而非"宿主/Native Messaging"）；错误文案三段式；术语表与扩展侧一致 |
| i18n | UI 字符串外置（`i18n/*.ftl` 或等价方案），与扩展共用词条表；MVP 至少支持简体中文与英文 |

### 17.9 GUI 落地计划（Phase 8）

| 批次 | 任务 | 编码估算 | 交付工时（×1.6） | 时间窗 | 说明 |
|------|------|---------|-----------------|--------|------|
| **8a（Beta 前必须完成）** | G1 托盘图标、状态与菜单 | 2 天 | 3.2 | 第8周 | 含深浅两套图标与状态机 |
| | G2 设置窗口框架 + 通用页 + 引擎页 | 5 天 | 8 | 第8-9周 | 含配置读写、备份、即时生效 |
| | G3 快捷键页与录入控件 | 3 天 | 4.8 | 第9-10周 | 含冲突检测与测试按钮 |
| | G4 OCR 与模型管理页 | 3 天 | 4.8 | 第10-11周 | 含下载、校验、档位切换 |
| | G5 自检诊断 UI（复用 16.6 Doctor） | 2 天 | 3.2 | 第11周 | 一键复制报告 |
| **8b（GA 前完成）** | G6 选区覆盖层增强（放大镜/手柄/吸附/区域记忆） | 3 天 | 4.8 | 第12-13周 | 含多显示器与 DPI |
| | G7 可交互译文浮窗（工具栏/拖动/固定/状态） | 4 天 | 6.4 | 第13-14周 | 替代当前只读浮窗 |
| | G8 Toast 与错误提示体系 | 2 天 | 3.2 | 第14周 | 含抑制与分级 |
| **8c（随 Phase 6）** | G9 历史记录窗口 | 4 天 | 6.4 | Phase 6 内 | 虚拟滚动 + 导出 |
| | G10 生词本与复习面板窗口 | 4 天 | 6.4 | Phase 6 内 | 键盘操作优先 |
| **8d（收尾）** | G11 主题、DPI、无障碍、i18n 打磨 | 4 天 | 6.4 | GA 前 | 与 15.4 兼容性矩阵同步验证 |
| | G12 GUI 端到端联调与修复 | 3 天 | 4.8 | GA 前 | 含 24h soak |
| **合计** | | **39 天** | **约 62 人日** | 单人约 11-12 周（分 8a~8d 穿插） | 见 14.2.5 排期 |

> 排期修正：8a 为 MVP 必做（否则用户必须手改 JSON），8b 为 GA 必做，8c 随学习模块交付，8d 贯穿打磨。若人力紧张，**8a 的最小可用版本**（托盘 + 设置窗口的通用/引擎/快捷键三页）优先级高于一切新的浏览器内功能。

---

## 十八、附录

### 17.1 术语表

| 术语 | 英文 | 说明 |
|------|------|------|
| Native Messaging | 原生消息传递 | Chrome/Edge官方IPC机制 |
| Content Script | 内容脚本 | 注入网页的扩展脚本 |
| Service Worker | 服务工作者 | 扩展后台脚本（Manifest V3） |
| Manifest V3 | 清单V3 | Chrome扩展最新规范 |
| OCR | 光学字符识别 | 将图片文字转为可编辑文本 |
| IPC | 进程间通信 | 不同进程间的通信机制 |
| DOM | 文档对象模型 | 网页的树形结构表示 |
| SPA | 单页应用 | 现代前端框架构建的应用 |
| MutationObserver | 变异观察者 | 监听DOM变化的API |
| PP-OCRv6 | PaddlePaddle OCR v6 | 百度飞桨第六版OCR引擎 |
| ONNX Runtime | 开放神经网络交换运行时 | 微软开源跨平台ML推理引擎 |
| Rust | Rust | Mozilla开发的系统级编程语言 |
| FFI | 外部函数接口 | 跨语言调用机制 |
| GIL | 全局解释器锁 | Python多线程限制 |
| DXGI | 直接图形交换接口 | Windows图形捕获API |
| Web Worker | Web工作线程 | 浏览器后台线程 |
| Design Token | 设计令牌 | 设计系统的可复用变量 |
| Shadow DOM | 阴影DOM | Web组件封装DOM/CSS |

### 17.2 参考资源

- Chrome Extension Manifest V3 文档
- Native Messaging 文档
- PP-OCRv6 官方文档（PaddlePaddle）
- ONNX Runtime Rust 文档
- Rust winapi crate 文档
- winit 窗口管理 crate 文档
- Edge Translator API 文档
- PDF.js 文档
- SiliconFlow API 文档

### 17.3 版本历史

| 版本 | 日期 | 说明 |
|------|------|------|
| v1.0 | 2026-09-22 | 初始版本，完整开发计划 |
| v1.1 | 2026-09-22 | 补充学习模块（M13-M16）接口定义、数据流、目录结构、里程碑 |
| **v1.2** | **2026-09-22** | **架构切换：C++→Rust + PP-OCRv6 ONNX Runtime；新增快捷键自定义系统；新增现代UI设计规范** |
| **v1.5** | **2026-09-24** | **补齐工程落地与产品交付视角**：新增第十四章 工程落地基线（版本列车与 MVP MoSCoW 范围基线、Out of Scope、变更控制、指标口径修正、工时口径与关键路径、里程碑准出 Gate、RACI、分支/CI/制品规范）；新增第十五章 质量工程与测试策略（测试金字塔、覆盖率门禁、E2E 场景矩阵、兼容性矩阵、性能基线、Soak、缺陷分级 SLA、发布准入清单）；新增第十六章 安装分发升级与运维运营（3 步极简安装、打包签名、NM Host 注册/自愈、启动三态、升级回滚与配置迁移、日志崩溃遥测与自检 Doctor、灰度、成本配额、安全合规落地、运营闭环）；新增第十七章 用户使用视角与第一性原理（视野集中原则、首次引导、三条主路径、快捷键用户视角与录入交互、壳的启停、插件常驻、自助故障表）；新增第十八章 Rust 壳完整 GUI 设计（技术选型 ADR、托盘菜单、设置窗口 8 分区、选区覆盖层增强、可交互译文浮窗、历史/生词本窗口、Toast 规范、GUI 设计规范与 Phase 8 落地计划）；修正 1.2 节体积与端到端耗时口径；重排时间轴（关键路径 Rust 壳与 GUI 前移） |
| **v1.4** | **2026-09-22** | **新增第十三章"开发策略：复制vs AI写"，含逐模块策略矩阵、参考项目清单、代码复用总表、AI辅助开发工作流、工具分工总结、预估工期**；新增M17本地大模型引擎接口（Ollama/LM Studio/text-generation-webui，支持Qwen/Llama/ChatGLM）；新增M18 AI对话界面（类ChatGPT多轮对话/引擎切换/文件上传/流式输出）；翻译引擎路由器升级（新增OpenAI GPT/Claude/Gemini/DeepL引擎及智能路由策略表）；新增Phase 7开发计划（第27-34周）；新增LocalLLMService/AIChatService接口定义；新增AI对话界面UI设计规范；更新项目目录结构** |
