# WinOCR v1.0.0 - 版本说明

> 发布日期：2026-09-30
> 平台：Windows 10/11 (x64)

## 新增功能

### 多主题支持
- 三套主题：A 清晰高效 / B 高饱和醒目 / C 舒适阅读（默认）
- 运行时切换（设置 → 外观主题），重启保留

### 界面统一
- 设计令牌全链路贯通（bg/surface/border/text/accent）
- 圆角三档体系（6px / 8px / 10px）
- 字号四档规范（12 / 13 / 14 / 16px）
- 字重三档（400 / 600 / 700）

### 安全
- 密钥 DPAPI 加密落盘（4 个 API Key 字段）
- 旧版明文自动迁移

## 修复
- E0624: Slint property 可见性（set_xxx 私有方法不可调）
- RailItem 组件内颜色属性 root.xxx 指向错误
- Pill 组件无法引用 text-2 令牌

## 已知限制
- 气泡窗口未接入主题联动（v1.1）
- 生词本/历史/导出/设置页部分功能待完善（P1-2 / P3 / P2-3）
- 翻译引擎仅 Argos 离线（其余引擎待接入）

## 冒烟测试清单

### 启动
- [ ] 双击 winocr.exe 启动（首次 1-2s 预热 OCR）
- [ ] 主窗口 1100×660，标题 "WinOCR"（无版本号）
- [ ] 顶栏 [蒙图翻译][文件][在线图片] 左对齐，语言对居中，设置齿轮右对齐

### 截图翻译
- [ ] Alt+Q 进入截图模式
- [ ] 拖选区域，松手后 OCR 文本进左栏，译文进右栏
- [ ] 左栏 [重新识别][复制]，右栏 [朗读][复制][收藏][交换]
- [ ] Esc 取消截图

### 主题切换
- [ ] 导航轨 → 设置 → 外观主题 → 点击 A/B/C
- [ ] 切换后所有元素颜色即时更新
- [ ] 重启后主题保留

### 配置持久化
- [ ] 设置 → 翻译 → 修改 API Key → 保存设置
- [ ] 重启后 Key 仍在
- [ ] %APPDATA%/WinOCR/config.json 中 Key 已加密（非明文）

### 托盘
- [ ] 关闭主窗口 → 隐藏到托盘
- [ ] 双击托盘图标 → 恢复主窗口
- [ ] 托盘菜单 → 退出 → 进程结束

### 历史 / 生词
- [ ] 翻译后历史记录新增一行
- [ ] 收藏生词后生词本新增一条
- [ ] 生词复习（掌握/模糊/忘记）功能正常

## 目录结构

```
WinOCR-Portable-v1.0.0/
├── winocr.exe              # 主程序
├── winocr-argos.exe        # Argos 离线翻译旁路进程
├── tray.ico                # 托盘图标
├── assets/
│   ├── models/ocr/         # PP-OCR 模型 (det_tiny.onnx + rec_tiny.onnx + ppocr_dict.txt)
│   ├── onnxruntime.dll     # ONNX Runtime
│   ├── argos_packages/     # Argos 离线翻译包 (en≈zh, 164MB)
│   └── ...
├── extension/              # Chrome/Edge 扩展
├── build.bat               # 构建助手（debug/release）
├── pack.bat                # 一键打包
└── README.txt              # 本文件
```
