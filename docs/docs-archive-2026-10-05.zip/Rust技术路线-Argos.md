# Rust 技术路线：Argos 本地离线翻译（CTranslate2 + SentencePiece）

> 目的：把 `reference/argos/argos.py`（Python：CTranslate2 + SentencePiece，无 torch）**用纯 Rust 复刻**，
> 直接消费 `assets/argos_packages/`（en↔zh，≈164MB，Argos 官方 v1.9），作为**默认首选翻译引擎**。
> 结论：**可行，有两条路线**，各有取舍。

---

## 一、结论速览

| 路线 | 依赖 | 复用现有 Argos 包 | 构建复杂度 | 体积 | 推荐度 |
|---|---|---|---|---|---|
| **A. `ct2rs`（CTranslate2 的 Rust 绑定）** | CTranslate2 + CMake + C++ 工具链 | ✅ 直接用（无需转换） | 高（Windows 需 crt-static，随包 dll） | 中（含 CTranslate2 + 后端） | ★★★ 首选（最快打通、与 argos.py 逐字一致） |
| **B. `ort`（ONNX Runtime，项目已有）+ Marian-ONNX 模型** | 仅 `ort` + 纯 Rust tokenizer | ❌ 需换 ONNX 模型（非 ct2 包） | 低（复用现有 ort/onnxruntime.dll） | 小 | ★★☆ 备选（纯 Rust、零 C++ 构建，但要自写解码） |
| C. Python 侧车 | Python 运行时 | ✅ | 低 | 大 | ✗（用户否决：要 Rust） |

---

## 二、路线 A：`ct2rs` + `sentencepiece-rs`（首选）

**原理**：`ct2rs` 是 OpenNMT/CTranslate2 的 Rust 绑定，**已确认支持 Marian-MT** 模型（Argos 的模型族正是 Marian）。

**关键 crate**
```toml
[dependencies]
ct2rs = { version = "0.10", default-features = false, features = ["ruy"] }  # 或 "dnnl"；避开 cuda/mkl 巨型依赖
sentencepiece-rs = "0.2"     # 纯 Rust 的 SentencePiece 实现（读 .model，encode/decode），无需 C++ 绑定/CMake
```

**最小用法（Rust）**
```rust
use ct2rs::{Config, Translator, TranslationOptions};

// 1) 加载模型目录 = assets/argos_packages/translate-en_zh-1_9/model
let translator = Translator::new("assets/argos_packages/translate-en_zh-1_9/model", &Config::default())?;

// 2) 分词（sentencepiece.model）→ translate_batch → 反分词（"▁"→空格）
let sources = vec!["Hello world".to_string()];
let results = translator.translate_batch(&sources, &TranslationOptions::default(), None)?;
```

**注意事项（重要）**
- `ct2rs` 依赖 **CMake 编译 CTranslate2**；**Windows 上需设 `RUSTFLAGS=-C target-feature=+crt-static`**（官方 README 明示）。本机是 `x86_64-pc-windows-gnu`（msys2）工具链，**存在编译摩擦风险**，需先做 PoC 验证。
- 后端特性：选 `ruy` 或 `dnnl`（CPU），**不要开 `cuda`/`mkl`**（会拉入巨型依赖）。`ct2rs-platform` 在 Windows 会默认选 `dnnl/mkl/cuda`，**故用 `ct2rs` 手动选特性**，别用 `ct2rs-platform`。
- 随包分发：`ctranslate2.dll` + 所选后端（如 `ruy` 为静态则更省）；类比现有 `onnxruntime.dll` 的处理方式，用 `build.rs` 自动随包。
- 推理超参对齐 `argos.py`：`beam_size=4, length_penalty=0.2, max_batch_size=32, batch_type="tokens", compute_type="auto"`；句子切分规则（CJK `。！？；` / Latin `.!?;`）也照搬。
- **文本等价性**：`ct2rs` 调的就是同一个 CTranslate2，输出可与 `argos.py` 逐字一致。

---

## 三、路线 B：`ort` + Marian-ONNX（纯 Rust，备选）

**原理**：Argos 的 en↔zh 模型源自 `Helsinki-NLP/opus-mt-*`（Marian）。可改用**同一模型的 ONNX 导出**，用项目**已有的 `ort`**（2.0.0-rc，现用于 OCR）跑 encoder/decoder。

**关键点**
- 模型：从 HF 取 Marian 的 ONNX（如社区已导出的 `opus-mt-en-zh` onnx：`encoder_model.onnx` + `decoder_model_merged.onnx`），或用 `optimum` 导出。
- Tokenizer：`sentencepiece-rs`（纯 Rust）加载**同一套 SentencePiece**；需确认与模型配套的 spm 版本一致。
- **需自写**：Marian 的 **seq2seq 解码循环 + beam search**（ort 无现成 helper）——工作量不小，但可控。
- 优点：**不加任何新的原生库/构建步骤**，复用已随包的 `onnxruntime.dll`，二进制最小，**纯 Rust**。
- 风险：ONNX 模型需另行获取/导出，且要与 tokenizer 严格配套（比路线 A 多一层"配得对不对"的风险）。

---

## 四、推荐与阶段计划

**建议：先 A 后 B（A 打通，B 兜底）**

1. **Phase 0 · PoC（1 天量级）**：最小工程引入 `ct2rs` + `sentencepiece-rs`，在 `x86_64-pc-windows-gnu` 下**先验证能不能编过**、能否加载 `assets/argos_packages/translate-en_zh-1_9` 并译出一句。→ 若编不过/摩擦太大，转 B。
2. **Phase 1 · 引擎实现**：`ArgosEngine` 实现 `TranslateEngine` trait（对齐 `reference/argos/translate_base.py` 的契约）；模型目录解析对齐 `reference/argos/paths.py` 的搜索顺序（`$ARGOS_PACKAGES_DIR` → 用户目录 `models/argos` → 项目 `vendor/argos_packages`）。
3. **Phase 2 · 回退链**：`auto` = `argos → ollama → mymemory → sf`；加**离线模式开关**（只走本地）。
4. **Phase 3 · 随包**：`build.rs` 自动随包 Argos 包 + `ctranslate2.dll`（或 ONNX 模型）。

---

## 五、接口设计（Rust trait，供核心层调用）

```rust
/// 对齐 reference/argos/translate_base.py 的 TranslateEngine 契约
pub trait TranslateEngine: Send + Sync {
    fn name(&self) -> &'static str;          // "argos"
    fn display_name(&self) -> &'static str;  // "Argos 离线"
    fn online(&self) -> bool { false }        // 本地离线
    fn available(&self) -> bool;              // 是否找到语言包
    fn translate(&self, text: &str, src: &str, tgt: &str) -> anyhow::Result<String>;
}
```
- **惰性加载**：`ctranslate2`/tokenizer 在首次 `translate` 时才初始化（对齐 argos.py 的 lazy import，避免拖慢启动/插件扫描）。
- 按 `(from_code, to_code)` 缓存已加载的语言包；`zh-CN→zh` 归一。

---

## 六、模型与资源（已就位）

- 语言包：`assets/argos_packages/translate-en_zh-1_9`、`translate-zh_en-1_9`（`metadata.json` + `model/model.bin` + `sentencepiece.model`）。
- 参考实现：`reference/argos/argos.py`（引擎）、`download_argos.py`（官方源 argos-net.com 下载器，可加更多语言对）、`dispatcher.py`（回退链）、`paths.py`（搜索目录）。

---

## 七、风险清单

| 风险 | 影响 | 缓解 |
|---|---|---|
| `ct2rs` 在 mingw/gnu 下编译失败 | 路线 A 不可行 | PoC 先验；失败转路线 B |
| 随包 `ctranslate2.dll` + 后端体积 | 包体变大 | 选 `ruy`（偏静态/小）；按需按平台裁剪 |
| 路线 B 的 ONNX 与 tokenizer 不配套 | 译文错乱 | 用同源 `opus-mt-*` 的配套 spm；加对照测试 |
| Argos 质量低于云端 LLM | 译文质量下降 | 已定"本地优先"；设置可切 Ollama/SF |
