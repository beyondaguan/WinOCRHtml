# WinOCR v2.0 引擎职责与 AI 对话范围定义

> **版本**：v2.0 · **日期**：2026-10-05
> **驱动文档**：`实施计划.md`、`设计.md`、`交付.md`
> **编码参照**：本文档 → `实施计划.md` Phase 1-4 → 改哪个文件、改什么，一一对应

---

## 一、引擎职责总表（第一性分配）

### 核心原则
> **每个引擎只做一件事，做到最好。跨引擎功能走管线组合，不重复造轮子。**

| 引擎 | 服务文件 | 核心能力 | 负责的场景 | **不做** |
|---|---|---|---|---|
| **PP-OCR** | `ocr.rs` | 图片→文字（本地 ONNX） | 截图识别、文件 OCR、在线图片 OCR | 不翻译、不理解语义 |
| **Argos** | `translate.rs` → ArgosBridge | 文本→译文（离线 CTranslate 2） | 默认翻译引擎（en↔zh 最快最准） | 不联网、不解释、不生成 |
| **Ollama** | `translate.rs` + `ai.rs` | 本地 LLM（翻译+对话双模式） | 翻译回退 + AI 对话（隐私敏感场景） | 不联网、不吃 GPU 也能跑 |
| **SiliconFlow** | `translate.rs` + `ai.rs` | 云端 LLM（OpenAI 兼容） | 高质量翻译 + AI 对话（网络可用时） | 不吃本地 GPU、不限本地内存 |
| **MyMemory** | `translate.rs` | 免费在线翻译 | 兜底翻译（无需 Key） | 翻译质量一般，仅兜底 |
| **有道智云** | `translate.rs` | 专业翻译 API | 中日/中韩等专业语言对（配置后） | 需要 AppKey，非默认 |
| **术语库** | `terms.rs` | 专业术语保护（占位→还原） | 医学/技术翻译中固定术语 | 不翻译整句 |
| **AI 对话** | `ai.rs` | 多轮上下文对话 | 术语解释、段落理解、上下文问答 | **不背单词、不生成例句、不做闪卡** |
| **TTS 朗读** | `tts.rs` | 文本→语音（OneCore + edge-tts） | 译文/原文朗读、采集词听读 | **不评测发音、不做字幕** |

### 引擎矩阵（场景 × 引擎）

| 用户场景 | 主引擎 | 回备引擎 | AI 介入 |
|---|---|---|---|
| Alt+Q 截图翻译 | Argos | Ollama → MyMemory → SF | 可选（"解释此术语"） |
| 文件/图片 OCR | PP-OCR | Windows.Media.Ocr | 无 |
| 划词翻译 | Argos | 回退链 | 可选（"这词在这句啥意思"） |
| 整段翻译 | SF/Ollama | 回退链 | 可选（"帮我理解这段"） |
| 术语解释 | — | — | **必用** AI（Ollama/SF） |
| 段落总结 | — | — | **必用** AI |
| 上下文问答 | — | — | **必用** AI |
| 译文朗读 | OneCore（离线） | edge-tts（在线） | — |
| 采集词朗读 | OneCore / edge-tts | — | — |
| AI 回复朗读 | OneCore / edge-tts | — | — |
| 生成例句 | — | — | **不做**（Anki/欧路做） |
| 单词复习 | — | — | **不做**（Anki/欧路做） |
| 发音训练 | — | — | **不做**（仅朗读，不评测） |

---

## 二、AI 对话范围（重点澄清）

### 2.1 AI 对话在 WinOCR 里的定位

```
第一性问题：用户读完一段英文文献，AI 帮他做什么？

不是"在 WinOCR 里背单词"，而是：
  "我读懂了这段文字，但有几个概念不理解，AI 帮我理解"
```

### 2.2 AI 对话 **做什么**（v2.0 实现范围）

| 功能 | 触发方式 | AI 引擎 | 实现状态 |
|---|---|---|---|
| **术语解释** | 用户在 AI 对话输入"prostate adenocarcinoma 是什么" | Ollama/SF | 需新增按钮（工作台→送原文上下文到 AI） |
| **段落理解** | 用户在 AI 对话输入"帮我理解这段" | Ollama/SF | 需新增上下文携带 |
| **上下文问答** | 多轮对话：用户问"那 Gleason score 呢" | Ollama/SF | ✅ 已有（`chat_stream` 带 context） |
| **翻译润色** | "这段译文读起来不自然，能改改吗" | Ollama/SF | 需新增（当前 AI 对话不带原文上下文） |
| **提取关键信息** | "这段报告的主要发现是什么" | Ollama/SF | 需新增 |

### 2.3 AI 对话 **不做**（明确排除）

| 排除项 | 原因 | 由谁做 |
|---|---|---|
| 生成例句 | WinOCR 的句子来自真实截图/文献，不需要 AI 生成的假例句 | 用户自己从真实文献中采集 |
| 闪卡复习 | 这是 Anki/欧路的核心能力，WinOCR 不重复 | Anki / 欧路 |
| 间隔重复调度 | SM-2 交给专业工具 | Anki / 欧路 |
| 掌握度追踪 | 学习是外部工具的事 | Anki / 欧路 |
| 单词测试/测验 | 不做题库 | Anki |
| 发音训练 | 不做 TTS 发音评测 | 系统 TTS / 欧路 |
| 全文翻译网页 | 浏览器扩展可做，但不在桌面端 WinOCR 里做 | 浏览器扩展（沉浸式翻译做更好） |
| 视频字幕 | 不做视频处理 | 其他工具（如 yt-dlp + Whisper） |

### 2.4 AI 对话的输入上下文

当前 AI 对话 **只传用户输入的一句话**。v2.0 改进：

```rust
// 当前（v1.0）：只传用户输入
ai.chat_stream(user_msg, on_chunk).await;

// 目标（v2.0）：附带当前 OCR 上下文
ai.chat_stream_with_context(
    user_msg,
    ChatContext {
        current_src: Option<String>,    // 当前工作台原文
        current_tgt: Option<String>,    // 当前译文
        selection: Option<String>,      // 用户选中的片段
    },
    on_chunk
).await;
```

**效果**：用户选中一个术语后问"这是什么"，AI 能看到上下文，给出更准确的解释。

### 2.5 AI 对话的数据流

```
工作台原文/译文 ──┐
                  ├─► AI 对话上下文（chat_stream_with_context）
用户输入 ─────────┘         │
                            ▼
                    Ollama / SiliconFlow
                            │
                            ▼
                    流式响应 → UI 渲染
                            │
                            ▼
                    历史记录（可选保存对话到 history.ai_messages）
```

---

## 三、文档到代码的映射表

> 编码时按本表找到要改的文件，避免遗漏。

| 要做什么 | 参考文档 | 要改的文件 | 改动摘要 |
|---|---|---|---|
| **导航轨改名** | `实施计划.md` 1.1 | `main_window.slint` | 4 处 RailItem：`☆ 生词`→`📌 采集`，`⇩ 导出`→`📤 导出` |
| **历史页表格化** | `实施计划.md` 1.2 | `main_window.slint` | history 段：`ScrollView` → `TableView`，新增搜索/筛选 |
| | | `mod.rs` | `on_load_history` → 填充 `Vec<HistoryRow>` 而非 `Vec<String>` |
| | | `core/types.rs` | 新增 `HistoryRow` 结构体（含 `ts_display/collected` 等 UI 字段） |
| | | `persist.rs` | `list_history` → 分页+筛选（或 SQLite 版） |
| **采集队列页** | `实施计划.md` 1.3 | `main_window.slint` | `vocab` → `collect`：移除 SM-2/忽略词，新增标签筛选 |
| | | `mod.rs` | `load-vocab` → `load-collect`，`grade-vocab` 移除，`remove-vocab` → `remove-collect` |
| | | `services/collect.rs` | **新建**：采集管理服务 |
| **导出页扩展** | `实施计划.md` 1.4 | `main_window.slint` | export 段：格式 ComboBox 加 Anki/欧路，新增范围+字段映射+预览 |
| | | `services/export.rs` | 新增 `AnkiTsv` 和 `EudicXml` 格式实现 |
| **TTS 朗读按钮** | — | `main_window.slint` | 译文栏"朗读"按钮 → tts.rs |
| | | `bubble.slint` | 气泡新增"朗读"按钮 → tts.rs |
| | | `services/tts.rs` | **新建**：OneCore 离线 + edge-tts 在线回退 |
| **设置页文案** | `实施计划.md` 1.5 | `main_window.slint` | "生词本" → "采集队列" |
| **mod.rs 回调** | `实施计划.md` 1.6 | `mod.rs` | 所有 vocab→collect 重命名，`grade-vocab` 移除 |
| **persist.rs SQLite** | `实施计划.md` 2.1 | `persist.rs` | JSONL → SQLite 全量重写 |
| | | `core/types.rs` | `HistoryItem` 增加 `screenshot/project/collected/note/tags/exported` |
| **collect.rs 新建** | `实施计划.md` 2.2 | `services/collect.rs` | 新建：toggle/add/list/update/mark_exported |
| **export.rs 扩展** | `实施计划.md` 2.3 | `services/export.rs` | 新增 `AnkiTsv` 和 `EudicXml` 实现 |
| **旧数据迁移** | `实施计划.md` 2.4 | `services/migrate.rs` | 新建：JSONL → SQLite，vocab.jsonl → history 表 collected=true |
| **翻译预热** | `实施计划.md` 3.1 | `mod.rs` | 启动后 spawn_blocking 预热 Argos |
| **OCR 缓存** | `实施计划.md` 3.2 | `ocr.rs` | 新增 `ocr_cache` 表，detect_and_recognize 入口查缓存 |
| **工作台采集按钮** | `实施计划.md` 3.3 | `main_window.slint` + `mod.rs` | "加入生词"→"采集"，回调改 `on_collect_current` |
| **气泡采集按钮** | `实施计划.md` 3.4 | `bubble.slint` + `mod.rs` | "收藏生词"→"采集"，回调改 `collect.add` |
| **浏览器扩展骨架** | `实施计划.md` 4.1 | `browser-extension/*` | 新建：manifest.json + content.js + background.js + popup.html |
| **Native Messaging 主机** | `实施计划.md` 4.2 | `src/bin/winocr-host.rs` | 新建：stdin/stdout JSON 行协议 |
| **扩展连接检测** | `实施计划.md` 4.3-4.4 | `browser-extension/background.js` | ping 桌面端 + 连接状态标记 |
| **清理 vocab.rs SM-2** | `实施计划.md` Phase 5 | `services/vocab.rs` | **删除**（或归档到 `rust-reference/`） |
| | | `services/mod.rs` | `mod.rs` 移除 `pub mod vocab` |
| | | `ui/mod.rs` | 移除 `use crate::services::vocab::Vocab` 及相关代码 |
| **AI 对话上下文** | 本文档 §2.4 | `ai.rs` | 新增 `chat_stream_with_context` 方法 |
| | | `main_window.slint` | AI 对话页新增"发送原文到 AI"按钮 |
| | | `mod.rs` | `on_send_ai` → 携带当前 ocr-src 上下文 |

---

## 四、管线组合示例（端到端）

### 场景 1：Alt+Q 截图 → 翻译 → 采集 → 导出

```
[截图] capture.rs GDI → CaptureResult.rgb
  ↓
[OCR] ocr.rs PP-OCR → "prostate adenocarcinoma"
  ↓
[术语保护] terms.rs → 占位符替换（如有术语库命中）
  ↓
[翻译] translate.rs Argos → "前列腺腺癌"
  ↓
[术语还原] terms.rs → 占位符还原
  ↓
[历史写入] persist.rs → history 表 INSERT（collected=false）
  ↓
[采集] 用户点击"采集" → collect.rs toggle(id, true)
  ↓
[导出] 用户到导出页选 Anki TSV → export.rs → .tsv 文件
  ↓
[外部] 用户导入 Anki → 在 Anki 里复习
```

### 场景 2：AI 解释术语

```
[工作台] 用户选中 "prostate adenocarcinoma"（原文上下文 = 整段 OCR 文本）
  ↓
[AI 对话] 用户输入"这个术语是什么"
  ↓
[上下文携带] ai.rs chat_stream_with_context(msg, {current_src: ..., selection: ...})
  ↓
[LLM 推理] Ollama/SiliconFlow → 流式返回解释
  ↓
[UI 渲染] ai-messages 追加 AI 回复
  ↓
[可选采集] 用户觉得重要 → 采集按钮 → collect.rs
```

### 场景 3：浏览器扩展 → 桌面端采集

```
[浏览器] 用户在 PubMed 选中文本 → 气泡翻译
  ↓
[Native Messaging] background.js → winocr-host.exe stdin JSON
  ↓
[桌面端推理] winocr-host.exe 调 translate.rs（复用桌面端引擎）
  ↓
[采集] 用户点"采集" → winocr-host.exe 调 collect.rs → SQLite
  ↓
[同步] 桌面端主窗口 history 表已更新 → UI 刷新
```

---

## 五、引擎选型决策树

```
用户输入文本需要翻译？
  ├─ 是 → 术语库启用？
  │        ├─ 是 → terms.rs 占位保护 → 翻译 → terms.rs 还原
  │        └─ 否 → 直接翻译
  │
  └─ 选哪个翻译引擎？
       ├─ config.engine == "argos" → Argos 子进程
       │    └─ 失败 → 回退链：Ollama → MyMemory → SF
       ├─ config.engine == "ollama" → Ollama 本地
       ├─ config.engine == "sf" → SiliconFlow 云端
       ├─ config.engine == "mymemory"→ MyMemory 免费
       ├─ config.engine == "youdao" → 有道专业
       └─ 默认 → Argos → 回退链

用户输入文本需要 AI 理解？
  ├─ config.ai_backend == "siliconflow" → SF LLM
  ├─ config.ai_backend == "ollama" → Ollama LLM
  └─ 当前工作台有 OCR 上下文？→ 携带上下文一起发送
```

---

## 六、实施优先级（修订版）

| 优先级 | 任务 | 原因 |
|---|---|---|
| **P0** | 导航轨改名 + 采集队列页 | GUI 先行，建立正确心智 |
| **P0** | 工作台"采集"按钮 | 核心交互打通 |
| **P0** | 导出格式扩展（Anki TSV） | 医生最需要的导出格式 |
| **P1** | persist.rs SQLite + 旧数据迁移 | 数据层基础 |
| **P1** | collect.rs 新建 + vocab.rs 移除 | 逻辑层切换 |
| **P1** | 历史页表格化 | 管理体验核心 |
| **P2** | AI 对话上下文携带 | 提升 AI 解释准确度 |
| **P2** | 翻译预热 + OCR 缓存 | 性能优化 |
| **P3** | 浏览器扩展 | 扩大采集场景 |
| **P3** | 欧路 XML 导出 | 第二导出格式 |
| **P4** | DXGI 抓屏 | 可选优化 |

---

## 七、TTS 朗读能力详细设计

### 7.1 定位

> **TTS = 独立能力**，既服务桌面端，也服务浏览器扩展端。两端各自调用本地 TTS 引擎，不跨进程。

### 7.2 引擎选型

| 引擎 | 类型 | 语言支持 | 离线 | 优先级 | 调用方式 |
|---|---|---|---|---|---|
| **OneCore** | 系统内置 | zh/en/ja（Win10+） | ✅ 离线 | P1 | Windows.Media.Synthesis (WinRT) |
| **edge-tts** | 在线（Edge TTS） | zh/en/ja/ko 等 | ❌ 联网 | P2 | HTTP API（`speech.platform.bing.com`） |

**注意**：用户系统是 Win10 Home 19045，**OneCore Neural 不可用**（无 Speech FoD），只能用 OneCore 内置语音（Microsoft Huihui/Kangkang 等）。edge-tts 作为回退（联网时音质更好）。

### 7.3 桌面端实现（Rust）

**文件**：`app/src/services/tts.rs`

```rust
pub enum TtsEngine {
    OneCore,     // Windows.Media.Synthesis (离线)
    EdgeTts,     // Edge TTS 在线
}

pub struct Tts;

impl Tts {
    pub fn new() -> Self;

    /// 朗读文本（非阻塞：后台线程播放）
    pub fn speak(&self, text: &str, lang: Lang, on_complete: impl FnOnce() + Send + 'static);

    /// 停止当前朗读
    pub fn stop(&self);

    /// 是否正在朗读
    pub fn is_speaking(&self) -> bool;

    /// 可用引擎列表（OneCore Neural 不可用时只有内置语音）
    pub fn available_engines(&self) -> Vec<TtsEngine>;

    /// 回退链：OneCore → EdgeTts
    pub fn speak_with_fallback(&self, text: &str, lang: Lang);
}
```

**依赖**：
- OneCore：`windows-sys` + WinRT bindings（或 `windows crate`）
- Edge-tts：直接 HTTP 调用（无需 crate），GET `speech.platform.bing.com/consumer/speech/synthesize/readaloud/...`

### 7.4 桌面端调用点

| 调用位置 | UI 元素 | 文件 |
|---|---|---|
| 工作台译文栏 | "🔊 朗读" 按钮 | `main_window.slint` |
| 划词气泡 | "朗读" 按钮（新增） | `bubble.slint` |
| AI 对话回复 | "朗读回复" 按钮（新增） | `main_window.slint` |
| 采集队列 | 每个词项 "听发音" 按钮（新增） | `main_window.slint` |

### 7.5 浏览器扩展端实现（JavaScript）

**文件**：`browser-extension/tts.js`

浏览器扩展端 TTS 完全独立，使用浏览器内置 **Web Speech API**（`window.speechSynthesis`），无需调用桌面端。

```javascript
// browser-extension/tts.js
const TTS = {
    synth: window.speechSynthesis,
    
    // 可用语音列表
    getVoices() {
        return this.synth.getVoices().filter(v => 
            v.lang.startsWith('zh') || v.lang.startsWith('en')
        );
    },
    
    // 朗读
    speak(text, lang = 'zh-CN') {
        this.synth.cancel();
        const utter = new SpeechSynthesisUtterance(text);
        utter.lang = lang;
        utter.rate = 1.0;
        utter.pitch = 1.0;
        // 匹配语音
        const voices = this.getVoices();
        const match = voices.find(v => v.lang === lang) || voices[0];
        if (match) utter.voice = match;
        this.synth.speak(utter);
    },
    
    stop() {
        this.synth.cancel();
    },
    
    // 浏览器扩展端无 OneCore 也无 edge-tts
    // 浏览器端就用 Web Speech API（Chrome/Edge 内置）
    available: () => 'speechSynthesis' in window,
};
```

**调用点**：

| 调用位置 | UI 元素 |
|---|---|
| 气泡翻译 | "朗读" 按钮 |
| 采集队列（popup 页） | 每个词项 "听发音" 按钮 |

### 7.6 桌面端 vs 浏览器端 TTS 对比

| 维度 | 桌面端 | 浏览器端 |
|---|---|---|
| 引擎 | OneCore（离线） + edge-tts（在线回退） | Web Speech API（浏览器内置） |
| 离线能力 | ✅ OneCore 离线可用 | ❌ 浏览器 Speech Synthesis 首次需联网下载语音包 |
| 音质 | OneCore 标准 / edge-tts 较好 | Chrome 内置较好 |
| 延迟 | OneCore <200ms / edge-tts <500ms | 首次 1-2s，后续 <200ms |
| 依赖 | WinRT 绑定 | 无 |
| 独立调用 | ✅ 不依赖扩展 | ✅ 不依赖桌面端 |

### 7.7 互斥约束

| 规则 | 说明 |
|---|---|
| **TTS 不翻译** | TTS 只读文本，不翻译、不生成内容 |
| **TTS 不评测发音** | 仅朗读，不做语音评测 |
| **TTS 不生成字幕** | 不处理视频/字幕 |
| **桌面端 TTS 独立于浏览器** | 两端各自调用，不跨进程 |

---

## 八、关键边界（编码时严格遵守）

| 规则 | 说明 |
|---|---|
| **AI 不生成例句** | WinOCR 的例句来自真实截图，不编造 |
| **翻译引擎不解释** | 遇到"这是啥意思"→ 转 AI 对话，翻译只输出译文 |
| **OCR 不翻译** | OCR 只输出原文文本，翻译由 translate.rs 独立做 |
| **浏览器端无存储** | 所有数据经 Native Messaging 回写桌面端 |
| **采集 = 历史子集** | 不建独立表，collected=true 过滤 |
| **术语库不翻译** | 术语库只做占位保护/还原，翻译由引擎做 |
| **托盘不处理业务** | 托盘只发事件（capture/navigate/quit），业务在 Services 层 |
| **TTS 不翻译** | TTS 只朗读已翻译的文本，不翻译、不生成 |
| **TTS 不评测** | 仅朗读，不做发音评测 |

---

> **文档维护**：本文档与 `实施计划.md`、`设计.md`、`交付.md` 互补。编码前先看 §三 映射表找到要改的文件，再看本文档确认引擎职责边界。
